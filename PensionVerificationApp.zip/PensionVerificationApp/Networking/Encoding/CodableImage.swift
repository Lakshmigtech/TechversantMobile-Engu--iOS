//
//  CodableImage.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation
import UIKit

public struct CodableImage {
    public let image: UIImage
    public let filename: String
    public let key: String

    init(image: UIImage, filename: String, key: String) {
        self.image = image
        self.filename = filename
        self.key = key
    }

}
