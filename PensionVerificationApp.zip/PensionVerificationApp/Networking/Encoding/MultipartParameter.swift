//
//  MultipartParameter.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

enum MultipartParameter: Decodable {
    case string(String)
    case bool(Bool)
    case int(Int)
    case double(Double)
    case image(CodableImage)
    

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()

        if let string = try? container.decode(String.self) {
            self = .string(string)
        } else if let bool = try? container.decode(Bool.self) {
            self = .bool(bool)
        } else if let int = try? container.decode(Int.self) {
            self = .int(int)
        } else if let double = try? container.decode(Double.self) {
            self = .double(double)
        }  else {
            throw APIError.decoding
        }
    }
    
//    func data(with key:String, boundary: String) -> Data {
//        var data = Data()
//        switch self {
//        case .image(let value):
//            data.append("\r\n--\(boundary)\r\n".data(using: .utf8)!)
//            data.append("Content-Disposition: form-data; name=\"\(key)\"; filename=\"\(value.filename)\"\r\n".data(using: .utf8)!)
//            data.append("Content-Type: image/png\r\n\r\n".data(using: .utf8)!)
//            data.append(value.imageData)
//        default:
//            data.append("\r\n--\(boundary)\r\n".data(using: .utf8)!)
//            data.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
//            data.append("\(self.description)".data(using: .utf8)!)
//        }
//        return data
//    }
    
    func data(with key:String, boundary: String) -> String {
        var data = ""
        switch self {
        case .image(let value):
            data += "\r\n--\(boundary)\r\n"
            data += "Content-Disposition: form-data; name=\"\(key)\"; filename=\"\(value.filename)\"\r\n"
            data += "Content-Type: image/png\r\n\r\n"
        default:
            data += "\r\n--\(boundary)\r\n"
            data += "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n"
            data += "\(self.description)"
        }
        return data
    }

    var description: String {
        switch self {
        case .string(let string):
            return string
        case .bool(let bool):
            return String(describing: bool)
        case .int(let int):
            return String(describing: int)
        case .double(let double):
            return String(describing: double)
        case .image (_):
            return ""
        }
    }
}
