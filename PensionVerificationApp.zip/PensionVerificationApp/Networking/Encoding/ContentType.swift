//
//  ContentType.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

public enum ContentType {
    
    case json
    case multipart(String)
    case formData
  
    
    var value: String {
        switch self {
        case .json:
            return "application/json"
        case let .multipart(value):
            return "multipart/form-data; boundary=\(value)"
        case .formData:
                   return "multipart/form-data"
               }
        }
    
    public func encode<Params: Encodable>(_ data: Params) throws -> Data{
        switch self {
        case .json:
            return try JSONEncoder().encode(data)
        case .multipart(let value):
            return try MultipartEncoder.encode(data, boundary: value)
            
        case .formData:
                    guard let parameters = data as? [String: Any] else {
                        throw EncodingError.invalidValue(data, EncodingError.Context(codingPath: [], debugDescription: "Data is not a dictionary of parameters"))
                    }
                    let parameterString = parameters.map { "\($0)=\($1)" }.joined(separator: "&")
                    guard let formData = parameterString.data(using: .utf8) else {
                        throw EncodingError.invalidValue(parameterString, EncodingError.Context(codingPath: [], debugDescription: "Failed to convert parameter string to data"))
                    }
                    return formData
        }
    }
}
