//
//  MultipartEncoder.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

enum MultipartEncoder {
    static func encode<T: Encodable>(_ encodable: T, boundary: String) throws -> Data {
        let parametersData = try JSONEncoder().encode(encodable)
        let parameters = try JSONDecoder().decode([String: MultipartParameter].self, from: parametersData)
        //var data = Data()
        //parameters.forEach { data.append($1.data(with: $0, boundary: boundary)) }
        return parameters.map { $1.data(with: $0, boundary: boundary) }.joined().data(using: .utf8)!
        //return data
    }
}
