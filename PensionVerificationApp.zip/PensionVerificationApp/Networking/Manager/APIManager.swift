//
//  APIManager.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

public typealias ResultCallback<Value> = (Swift.Result<Value, Error>) -> Void

public class APIManager {
    
    static let shared = APIManager()
    
    private let session = URLSession(configuration: .default)
    public init() {}
    
    /// Sends a request to server, calling the completion method when finished
    func perform<T: APIRequest>(_ request: T, completion: @escaping ResultCallback<T.SuccessResponseType>) {
        let urlRequest = request.urlRequest
        NetworkLogger.log(request: urlRequest)
        let task = session.dataTask(with: urlRequest) { data, response, error in
            if let err = error {
                completion (.failure(err))
            }
            guard let data = data, data.count > 0 else{
                completion (.failure(APIError.emptyResponse))
                return
            }
            self.decode(request, data: data, completion: completion)
        }
        task.resume()
    }
    
    /// Decode data based on the given request
    private func decode<T: APIRequest>(_ request: T, data: Data, completion: @escaping ResultCallback<T.SuccessResponseType>) {
        print(String(data: data, encoding: .utf8) ?? "")
        let decoder = JSONDecoder()
        let apiResponse = Swift.Result{ try decoder.decode(T.SuccessResponseType.self, from: data) }
        completion(apiResponse)
    }
   
}
