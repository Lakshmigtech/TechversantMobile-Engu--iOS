//
//  NetworkEnvironment.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

fileprivate var production = "http://pension-distributor.demoserver.work/api/v1/"
fileprivate var development = "https://pension-distributor.demoserver.work/api/v1/"

enum NetworkEnvironment {
    
    static let baseURL: URL = {
        guard let url = URL(string: development) else {
            fatalError("Base URL is invalid")
        }
        return url
    }()
}
