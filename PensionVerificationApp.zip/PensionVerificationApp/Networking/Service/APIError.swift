//
//  APIError.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

public enum APIError: Error {
    case encoding
    case decoding
    case badURL
    case emptyResponse
    case server(message: String)
    case otpVarification(otpUuid: String, message: String)
    case dataNotSaved
    case unableToFetch
}
extension APIError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .decoding:
            return "JSON Decode Error"
        case .encoding:
            return "JSON Encode Error"
        case .server(let message):
            return message
        case .badURL:
            return "Bad URL"
        case .emptyResponse:
            return "No data found"
        case .dataNotSaved:
            return NSLocalizedString("Unable to save data", comment: "Data not saved")
        case .unableToFetch:
            return NSLocalizedString("Unabale to fetch data", comment: "Fetch data failed")
        case .otpVarification(_ , let message):
            return message
        }
    }
    
    
}
