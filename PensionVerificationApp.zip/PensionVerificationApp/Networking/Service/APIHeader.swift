//
//  APIHeader.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

public struct APIHeader: Encodable {
    
    public enum AuthorizationKey: String {
        case bearer = "Bearer"
        case basic = "Basic"
    }
    
    let authorization: String?
    let authorizationKey: String?
    let contentType: ContentType
    let acceptType: ContentType?
    let acceptEncoding: String?
    let apiKey: String?
    let secret: String?
    
    enum CodingKeys: String, CodingKey {
        case authorization = "Authorization"
        case contentType = "Content-Type"
        case acceptType = "Accept"
        case acceptEncoding = "Accept-Encoding"
        case apiKey = "apiKey"
        case secret = "secret"
    }
    
    public init(authorization: String? = nil,
                authorizationKey: AuthorizationKey? = nil,
                contentType: ContentType = .json,
                acceptType: ContentType? = nil,
                acceptEncoding: String? = nil,
                apiKey: String? = nil,
                secret: String? = nil) {
        self.authorization = authorization
        self.contentType = contentType
        self.acceptType = acceptType
        self.acceptEncoding = acceptEncoding
        self.authorizationKey = authorizationKey?.rawValue
        self.apiKey = apiKey
        self.secret = secret
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        if let authorization = authorization, let key = authorizationKey{
            try container.encodeIfPresent("\(key) \(authorization)", forKey: .authorization)
        }
        try container.encodeIfPresent(contentType.value, forKey: .contentType)
        try container.encodeIfPresent(acceptType?.value, forKey: .acceptType)
        try container.encodeIfPresent(acceptEncoding, forKey: .acceptEncoding)
        try container.encodeIfPresent(apiKey, forKey: .apiKey)
        try container.encodeIfPresent(secret, forKey: .secret)

    }
}
