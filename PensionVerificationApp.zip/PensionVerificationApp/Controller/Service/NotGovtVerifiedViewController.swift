//
//  NotGovtVerifiedViewController.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 14/06/24.
//

import UIKit

class NotGovtVerifiedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
  
}
