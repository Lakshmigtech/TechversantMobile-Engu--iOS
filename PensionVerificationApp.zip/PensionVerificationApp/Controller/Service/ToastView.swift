//
//  ToastView.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 24/05/24.
//

import UIKit

class ToastView: UIView {
    private var textLabel: UILabel!

    init(text: String) {
        super.init(frame: CGRect.zero)
        self.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.layer.cornerRadius = 10
        self.clipsToBounds = true

        textLabel = UILabel()
        textLabel.textColor = UIColor.white
        textLabel.textAlignment = .center
        textLabel.text = text
        textLabel.numberOfLines = 0
        textLabel.font = UIFont.systemFont(ofSize: 14)
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        self.addSubview(textLabel)

        NSLayoutConstraint.activate([
            textLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10),
            textLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10),
            textLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            textLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func show(in view: UIView, duration: TimeInterval) {
        self.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(self)
        NSLayoutConstraint.activate([
            self.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            self.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            self.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50)
        ])
        self.alpha = 0
        UIView.animate(withDuration: 0.5, animations: {
            self.alpha = 1
        }) { _ in
            UIView.animate(withDuration: 0.5, delay: duration, options: .curveEaseOut, animations: {
                self.alpha = 0
            }) { _ in
                self.removeFromSuperview()
            }
        }
    }
}


