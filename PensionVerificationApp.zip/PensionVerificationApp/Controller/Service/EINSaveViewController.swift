//
//  EINSaveViewController.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 29/05/24.
//

import UIKit

class EINSaveViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var einTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        einTextField.delegate = self
        
      
        addTapGestures(to: einTextField)

    }

    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
  
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       textField.resignFirstResponder()
    }
    @IBAction func submitButtonTapped(_ sender: Any) {
        guard let einNumber = einTextField.text,
              !einNumber.isEmpty,
              einNumber.range(of: #"^\d{8}-\d{4}$"#, options: .regularExpression) != nil else {
            alert(message: "Please enter a valid EIN Number in the format 12345678-0001", title: "Invalid Input")
            return
        }
        self.showHUD(message: "")
        APIManager().perform(EINSave(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: EINSave.Body( ein: einNumber))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                // Check if the detail message matches the success message
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        // Show toast message
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: self.view, duration: 3.0)
                        
                        // Navigate to DashBoardViewController after the toast is shown
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in // Delay for the toast duration
                            let signUpVC = UIStoryboard(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "EINProcessingViewController") as! EINProcessingViewController
                            self.navigationController?.pushViewController(signUpVC, animated: true)
                           showAnimate()
                        }
                    }
                }
               else if data.detail.status == "fail" {
                   // if data.detail.tokenStatus == "valid" {
                   DispatchQueue.main.async {
                       let toast = ToastView(text: data.detail.message)
                       toast.show(in: self.view, duration: 3.0)
                   }
                  /*  } else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                    } else if data.detail.tokenStatus == "Invalid" {
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: self.view, duration: 3.0)
                    }
                   else {
                        let toast = ToastView(text: "Failed to refresh token")
                        toast.show(in: self.view, duration: 3.0)*/
                    }
                 else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
                
            case .failure(let error):
                // Handle API call failure
                let toast = ToastView(text: error.localizedDescription)
                toast.show(in: self.view, duration: 3.0)         
            }
        }    }
    @IBAction func cancelButtonTapped(_ sender: Any) {
               removeAnimate()
    }
    func removeAnimate() {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
        }, completion:{(finished : Bool)  in
            if (finished)
            {
                self.view.removeFromSuperview()
            }
        });
    }
    func showAnimate() {
            
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
            UIView.animate(withDuration: 0.25, animations: {
                self.view.alpha = 1.0
                self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            });
        }
   }
