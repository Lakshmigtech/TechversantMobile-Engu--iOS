//
//  RetireeViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit

class RetireeViewController: UIViewController,BasicDetailsDelegateRetiree  ,RetireeDetailsKeyboardDelegate{
    var isDataRetrieved = false // Flag to track data retrieval status
       
       func didRetrieveData(success: Bool) {
           isDataRetrieved = success
       }
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var segments: UISegmentedControl!
    @IBOutlet weak var seg: UISegmentedControl!
    @IBOutlet weak var detailImage: UIImageView!
    @IBOutlet weak var documentImage: UIImageView!
    @IBOutlet weak var bankImage: UIImageView!
    @IBOutlet weak var basicDetails: UIView!
    @IBOutlet weak var document: UIView!
    @IBOutlet weak var bankInfo: UIView!
    @IBOutlet weak var scrollViewHeightConstraint: NSLayoutConstraint!
    
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    var bankInfoViewController: BankInfoViewController? // Reference to BankInfoViewController
    var highestVisitedSegmentIndex = 0 // Track the highest segment index visited by the user

    

    override func viewDidLoad() {
        super.viewDidLoad()
        scrollViewHeightConstraint.constant = 2360
        mainView.bringSubviewToFront(basicDetails)
        detailImage.alpha = 0.5
        self.seg.frame = CGRect(x: self.seg.frame.minX, y: self.seg.frame.minY, width: seg.frame.width, height: 60)
        topView.applyLinearGradient()
        seg.highlightSelectedSegment()
        
        
        if let basicDetailsVC = children.first(where: { $0 is RetireeBasicDetailsViewController }) as? RetireeBasicDetailsViewController {
                    basicDetailsVC.delegate = self
                }
    }
    @objc func keyboardWillShow(notification: NSNotification) {
            guard let userInfo = notification.userInfo,
                  let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else {
                return
            }
            
            let keyboardSize = keyboardFrame.size
            let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
            
            scrollView.contentInset = contentInsets
            scrollView.scrollIndicatorInsets = contentInsets
        }
        
        @objc func keyboardWillHide(notification: NSNotification) {
            let contentInsets = UIEdgeInsets.zero
            scrollView.contentInset = contentInsets
            scrollView.scrollIndicatorInsets = contentInsets
        }
        
    
    
    
    @IBAction func backAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    @IBAction func segmentSelect(_ sender: Any) {
        guard let segmentedControl = sender as? UISegmentedControl else {
                   return
               }

               let previousIndex = highestVisitedSegmentIndex

               if segmentedControl.selectedSegmentIndex <= highestVisitedSegmentIndex {
                   // Allow selection if moving to a previous segment or the current highest visited
                   updateSegmentControl(selectedIndex: segmentedControl.selectedSegmentIndex)
               } else if isDataRetrieved {
                   // Allow forward selection if data is retrieved
                   updateSegmentControl(selectedIndex: segmentedControl.selectedSegmentIndex)
                   highestVisitedSegmentIndex = segmentedControl.selectedSegmentIndex
               } else {
                   // Reset to previous index if data is not retrieved
                   segmentedControl.selectedSegmentIndex = previousIndex
               }

               seg.underlinePosition()
    }
    @IBAction func segmentSelected(_ sender: Any) {
        
        guard let segmentedControl = sender as? UISegmentedControl else {
                  return
              }

              let previousIndex = highestVisitedSegmentIndex

              if segmentedControl.selectedSegmentIndex <= highestVisitedSegmentIndex {
                  // Allow selection if moving to a previous segment or the current highest visited
                  updateSegmentControl(selectedIndex: segmentedControl.selectedSegmentIndex)
              } else {
                  // Reset to previous index if data is not retrieved
                  segmentedControl.selectedSegmentIndex = previousIndex
              }
         }
    func updateSegmentControl(selectedIndex: Int) {
           switch selectedIndex {
           case 0:
               scrollViewHeightConstraint.constant = 2360
               mainView.bringSubviewToFront(basicDetails)
               detailImage.alpha = 0.5
               documentImage.alpha = 1.0
               bankImage.alpha = 1.0
           case 1:
               scrollViewHeightConstraint.constant = 2400
               mainView.bringSubviewToFront(document)
               documentImage.alpha = 0.5
               detailImage.alpha = 1.0
               bankImage.alpha = 1.0
           case 2:
               if bankInfoViewController == nil {
                   if let vc = storyboard?.instantiateViewController(withIdentifier: "BankInfoViewController") as? BankInfoViewController {
                       addChild(vc)
                       vc.view.frame = bankInfo.bounds
                       bankInfo.addSubview(vc.view)
                       vc.didMove(toParent: self)
                       bankInfoViewController = vc

                       // Pass data to BankInfoViewController
                       bankInfoViewController?.accountHolderName = "\(UserData.shared.firstName ?? "") \(UserData.shared.middleName ?? "") \(UserData.shared.lastName ?? "")"

                       // Set account holder text field
                       bankInfoViewController?.accountHolderNameTextField.text = "\(UserData.shared.firstName ?? "") \(UserData.shared.middleName ?? "") \(UserData.shared.lastName ?? "")"
                   }
               }
               scrollViewHeightConstraint.constant = 1200
               mainView.bringSubviewToFront(bankInfo)
               bankImage.alpha = 0.5
               detailImage.alpha = 1.0
               documentImage.alpha = 1.0
           default:
               break
           }

           if selectedIndex > highestVisitedSegmentIndex {
               highestVisitedSegmentIndex = selectedIndex
           }

           seg.underlinePosition() // Ensure underline is updated
       }
    
   }
