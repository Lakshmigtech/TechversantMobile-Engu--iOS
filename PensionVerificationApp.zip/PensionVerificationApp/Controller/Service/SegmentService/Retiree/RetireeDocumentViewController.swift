//
//  RetireeDocumentViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit
import Alamofire
import WebKit

class RetireeDocumentViewController: UIViewController, UIDocumentPickerDelegate,UIImagePickerControllerDelegate & UINavigationControllerDelegate, WKNavigationDelegate{
    
    
    @IBOutlet weak var retrieeStckview: UIStackView!
    @IBOutlet weak var uploadViewButtton: UIButton!
    @IBOutlet weak var paymentMonthlyArrearsViewButton: UIButton!
    @IBOutlet weak var autherizationPaymentViewButton: UIButton!
    @IBOutlet weak var clearanceViewButton: UIButton!
    @IBOutlet weak var notificationOfPromotionViewButton: UIButton!
    @IBOutlet weak var pensionLifeCertificateViewButton: UIButton!
    @IBOutlet weak var passportPhotoViewButton: UIButton!
    @IBOutlet weak var retirementNoticeViewButton: UIButton!
    @IBOutlet weak var idCardViewButton: UIButton!
    
    
    @IBOutlet weak var uploadApplicationButton: UIButton!
    @IBOutlet weak var appointmentButton: UIButton!
    @IBOutlet weak var autherizationButton: UIButton!
    @IBOutlet weak var clearanceFormButton: UIButton!
    @IBOutlet weak var promotionButton: UIButton!
    @IBOutlet weak var pensionButton: UIButton!
    @IBOutlet weak var passportPhotoButton: UIButton!
    @IBOutlet weak var retirementButton: UIButton!
    @IBOutlet weak var idCardButton: UIButton!
    
    @IBOutlet weak var uploadApplicationView: UIView!
    @IBOutlet weak var uploadApplicationInsideView: UIView!
    @IBOutlet weak var uploadApplicationFileLabel: UILabel!
    @IBOutlet weak var uploadApplicationPercentageLabel: UILabel!
    @IBOutlet weak var uploadApplicationCancelButton: UIButton!
    @IBOutlet weak var uploadApplicationProgressBar: UIProgressView!
    @IBOutlet weak var uploadApplicationUploadView: UIView!
    @IBOutlet weak var uploadApplicationViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var appointmentView: UIView!
    @IBOutlet weak var appointmentInsideView: UIView!
    @IBOutlet weak var appointmentFileLabel: UILabel!
    @IBOutlet weak var appointmentPercentageLabel: UILabel!
    @IBOutlet weak var appointmentClearButton: UIButton!
    @IBOutlet weak var appointmentProgressBar: UIProgressView!
    @IBOutlet weak var appointmentUploadView: UIView!
    @IBOutlet weak var appointmentViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var autherizationView: UIView!
    @IBOutlet weak var autherizationInsideView: UIView!
    @IBOutlet weak var autherizationFileLabel: UILabel!
    @IBOutlet weak var autherizationPercentageLabel: UILabel!
    @IBOutlet weak var autherizationCancelButton: UIButton!
    @IBOutlet weak var autherizationProgressBar: UIProgressView!
    @IBOutlet weak var autherizationUploadView: UIView!
    @IBOutlet weak var autherizationViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var clearanceFormView: UIView!
    @IBOutlet weak var clearanceFormInsideView: UIView!
    @IBOutlet weak var clearanceFormFileLabel: UILabel!
    @IBOutlet weak var clearanceFormPercentageLabel: UILabel!
    @IBOutlet weak var clearanceFormCancelButton: UIButton!
    @IBOutlet weak var clearanceFormProgressBar: UIProgressView!
    @IBOutlet weak var clearanceFormUploadView: UIView!
    @IBOutlet weak var clearanceFormViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var promotionView: UIView!
    @IBOutlet weak var promotionInsideView: UIView!
    @IBOutlet weak var promotionFileLabel: UILabel!
    @IBOutlet weak var promotionPercentageLabel: UILabel!
    @IBOutlet weak var promotionCancelButton: UIButton!
    @IBOutlet weak var promotionProgressBar: UIProgressView!
    @IBOutlet weak var promotionUploadView: UIView!
    @IBOutlet weak var promotionViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var pensionView: UIView!
    @IBOutlet weak var pensionInsideView: UIView!
    @IBOutlet weak var pensionFileLabel: UILabel!
    @IBOutlet weak var pensionPercentageLabel: UILabel!
    @IBOutlet weak var pensionCancelButton: UIButton!
    @IBOutlet weak var pensionProgressBar: UIProgressView!
    @IBOutlet weak var pensionUploadView: UIView!
    @IBOutlet weak var pensionViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var passportPhotoView: UIView!
    @IBOutlet weak var passportPhotoInsideView: UIView!
    @IBOutlet weak var passportPhotoFileLabel: UILabel!
    @IBOutlet weak var passportPhotoPercentageLabel: UILabel!
    @IBOutlet weak var passportPhotoCancelButton: UIButton!
    @IBOutlet weak var passportPhotoProgressBar: UIProgressView!
    @IBOutlet weak var passportPhotoUploadView: UIView!
    @IBOutlet weak var passportPhotoViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var retirementView: UIView!
    @IBOutlet weak var retirementInsideView: UIView!
    @IBOutlet weak var retirementFileLabel: UILabel!
    @IBOutlet weak var retirementPercentageLabel: UILabel!
    @IBOutlet weak var retirementCancelButton: UIButton!
    @IBOutlet weak var retirementProgressBar: UIProgressView!
    @IBOutlet weak var retirementuploadview: UIView!
    @IBOutlet weak var retirementViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var idCardView: UIView!
    @IBOutlet weak var idCardInsideView: UIView!
    @IBOutlet weak var idCardFileLabel: UILabel!
    @IBOutlet weak var idCardPercentageLabel: UILabel!
    @IBOutlet weak var idCardCancelButton: UIButton!
    @IBOutlet weak var idCardProgressBar: UIProgressView!
    @IBOutlet weak var idCardUploadView: UIView!
    @IBOutlet weak var idCardViewHeight: NSLayoutConstraint!
    @IBOutlet weak var clearanceViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var buttonView: UIView!
    
    var fileDataVal1:NSData?
    var fileDataVal2:NSData?
    var fileDataVal3:NSData?
    var fileDataVal4:NSData?
    var fileDataVal5:NSData?
    var fileDataVal6:NSData?
    var fileDataVal7:NSData?
    var fileDataVal8:NSData?
    var fileDataVal9:NSData?
    
    var retreiveData1:String?
    var retreiveData2:String?
    var retreiveData3:String?
    var retreiveData4:String?
    var retreiveData5:String?
    var retreiveData6:String?
    var retreiveData7:String?
    var retreiveData8:String?
    var retreiveData9:String?
    
    var selectedFileURL: URL? // Variable to store the selected file URL
    var selectedFileURL2: URL?
    var selectedFileURL3: URL?
    var selectedFileURL4: URL?
    var selectedFileURL5: URL?
    var selectedFileURL6: URL? // Variable to store the selected file URL
    var selectedFileURL7: URL?
    var selectedFileURL8: URL?
    var selectedFileURL9: URL?
    
    
    
    var selectedButton: Int = 0
    var imagePicker: UIImagePickerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        uploadViewButtton.isHidden = true
        paymentMonthlyArrearsViewButton.isHidden = true
        autherizationPaymentViewButton.isHidden = true
        clearanceViewButton.isHidden = true
        notificationOfPromotionViewButton.isHidden = true
        pensionLifeCertificateViewButton.isHidden = true
        passportPhotoViewButton.isHidden = true
        retirementNoticeViewButton.isHidden = true
        idCardViewButton.isHidden = true
        
        idCardInsideView.isHidden = true
        retirementInsideView.isHidden = true
        passportPhotoInsideView.isHidden = true
        pensionInsideView.isHidden = true
        promotionInsideView.isHidden = true
        clearanceFormInsideView.isHidden = true
        autherizationInsideView.isHidden = true
        uploadApplicationInsideView.isHidden = true
        appointmentInsideView.isHidden = true
        
        
        
        uploadApplicationProgressBar.isHidden = true
        uploadApplicationPercentageLabel . isHidden = true
        uploadApplicationFileLabel.isHidden = true
        
        appointmentProgressBar.isHidden = true
        appointmentPercentageLabel . isHidden = true
        appointmentFileLabel.isHidden = true
        
        autherizationProgressBar.isHidden = true
        autherizationPercentageLabel . isHidden = true
        autherizationFileLabel.isHidden = true
        
        clearanceFormProgressBar.isHidden = true
        clearanceFormPercentageLabel . isHidden = true
        clearanceFormFileLabel.isHidden = true
        
        promotionProgressBar.isHidden = true
        promotionPercentageLabel . isHidden = true
        promotionFileLabel.isHidden = true
        
        pensionProgressBar.isHidden = true
        pensionPercentageLabel . isHidden = true
        pensionFileLabel.isHidden = true
        
        passportPhotoProgressBar.isHidden = true
        passportPhotoPercentageLabel . isHidden = true
        passportPhotoFileLabel.isHidden = true
        
        retirementProgressBar.isHidden = true
        retirementPercentageLabel . isHidden = true
        retirementFileLabel.isHidden = true
        
        idCardProgressBar.isHidden = true
        idCardPercentageLabel . isHidden = true
        idCardFileLabel.isHidden = true
        
        uploadApplicationView.applyShadow()
        uploadApplicationInsideView.applyShadow()
        uploadApplicationView.applyCornerRadius(20)
        uploadApplicationUploadView.addRoundedBottomCorners(radius: 20)
        uploadApplicationInsideView.applyCornerRadius(10)
        
        appointmentView.applyShadow()
        appointmentInsideView.applyShadow()
        appointmentView.applyCornerRadius(20)
        appointmentUploadView.addRoundedBottomCorners(radius: 20)
        appointmentInsideView.applyCornerRadius(10)
        
        autherizationView.applyShadow()
        autherizationInsideView.applyShadow()
        autherizationView.applyCornerRadius(20)
        autherizationUploadView.addRoundedBottomCorners(radius: 20)
        autherizationInsideView.applyCornerRadius(10)
        
        clearanceFormView.applyShadow()
        clearanceFormInsideView.applyShadow()
        clearanceFormView.applyCornerRadius(20)
        clearanceFormUploadView.addRoundedBottomCorners(radius: 20)
        clearanceFormInsideView.applyCornerRadius(10)
        
        promotionView.applyShadow()
        promotionInsideView.applyShadow()
        promotionView.applyCornerRadius(20)
        promotionUploadView.addRoundedBottomCorners(radius: 20)
        promotionInsideView.applyCornerRadius(10)
        
        pensionView.applyShadow()
        pensionInsideView.applyShadow()
        pensionView.applyCornerRadius(20)
        pensionUploadView.addRoundedBottomCorners(radius: 20)
        pensionInsideView.applyCornerRadius(10)
        
        passportPhotoView.applyShadow()
        passportPhotoInsideView.applyShadow()
        passportPhotoView.applyCornerRadius(20)
        passportPhotoUploadView.addRoundedBottomCorners(radius: 20)
        passportPhotoInsideView.applyCornerRadius(10)
        
        retirementView.applyShadow()
        retirementInsideView.applyShadow()
        retirementView.applyCornerRadius(20)
        retirementuploadview.addRoundedBottomCorners(radius: 20)
        retirementInsideView.applyCornerRadius(10)
        
        idCardView.applyShadow()
        idCardInsideView.applyShadow()
        idCardView.applyCornerRadius(20)
        idCardUploadView.addRoundedBottomCorners(radius: 20)
        idCardInsideView.applyCornerRadius(10)
        
        fetchRetreiveActiveDocumentAPI()
        preloadImagePicker()
        
        retrieeStckview.translatesAutoresizingMaskIntoConstraints = false
        // Set the constraints
        NSLayoutConstraint.activate([

            retrieeStckview.topAnchor.constraint(equalTo: view.topAnchor, constant: 44),
        ])
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Load the selected file based on the selected button and update UI
        loadSelectedFile()
    }
    
    func loadSelectedFile() {
        let userDefaults = UserDefaults.standard
        
        if let savedSelectedButton = userDefaults.value(forKey: "selectedButton") as? Int {
            selectedButton = savedSelectedButton
            
            switch selectedButton {
            case 1:
                selectedFileURL = userDefaults.url(forKey: "selectedFileURL")
                fileDataVal1 = userDefaults.data(forKey: "fileDataVal1") as NSData?
                updateUI(fileURL: selectedFileURL, fileData: fileDataVal1, label: uploadApplicationFileLabel, viewHeight: uploadApplicationViewHeight, percentageLabel: uploadApplicationPercentageLabel, progressBar: uploadApplicationProgressBar, uploadButton: uploadViewButtton)
            case 2:
                selectedFileURL2 = userDefaults.url(forKey: "selectedFileURL2")
                fileDataVal2 = userDefaults.data(forKey: "fileDataVal2") as NSData?
                updateUI(fileURL: selectedFileURL2, fileData: fileDataVal2, label: appointmentFileLabel, viewHeight: appointmentViewHeight, percentageLabel: appointmentPercentageLabel, progressBar: appointmentProgressBar, uploadButton: paymentMonthlyArrearsViewButton)
            case 3:
                selectedFileURL3 = userDefaults.url(forKey: "selectedFileURL3")
                fileDataVal3 = userDefaults.data(forKey: "fileDataVal3") as NSData?
                updateUI(fileURL: selectedFileURL3, fileData: fileDataVal3, label: autherizationFileLabel, viewHeight: autherizationViewHeight, percentageLabel: autherizationPercentageLabel, progressBar: autherizationProgressBar, uploadButton: autherizationPaymentViewButton)
            case 4:
                selectedFileURL4 = userDefaults.url(forKey: "selectedFileURL4")
                fileDataVal4 = userDefaults.data(forKey: "fileDataVal4") as NSData?
                updateUI(fileURL: selectedFileURL4, fileData: fileDataVal4, label: clearanceFormFileLabel, viewHeight: clearanceViewHeight, percentageLabel: clearanceFormPercentageLabel, progressBar: clearanceFormProgressBar, uploadButton: clearanceViewButton)
            case 5:
                selectedFileURL5 = userDefaults.url(forKey: "selectedFileURL5")
                fileDataVal5 = userDefaults.data(forKey: "fileDataVal5") as NSData?
                updateUI(fileURL: selectedFileURL5, fileData: fileDataVal5, label: promotionFileLabel, viewHeight: promotionViewHeight, percentageLabel: promotionPercentageLabel, progressBar: promotionProgressBar, uploadButton: notificationOfPromotionViewButton)
                
            case 6:
                selectedFileURL6 = userDefaults.url(forKey: "selectedFileURL")
                fileDataVal6 = userDefaults.data(forKey: "fileDataVal6") as NSData?
                updateUI(fileURL: selectedFileURL6, fileData: fileDataVal6, label: pensionFileLabel, viewHeight: pensionViewHeight, percentageLabel: pensionPercentageLabel, progressBar: pensionProgressBar, uploadButton: pensionLifeCertificateViewButton)
            case 7:
                selectedFileURL7 = userDefaults.url(forKey: "selectedFileURL7")
                fileDataVal7 = userDefaults.data(forKey: "fileDataVal7") as NSData?
                updateUI(fileURL: selectedFileURL7, fileData: fileDataVal7, label: passportPhotoFileLabel, viewHeight: passportPhotoViewHeight, percentageLabel: passportPhotoPercentageLabel, progressBar: passportPhotoProgressBar, uploadButton: passportPhotoViewButton)
            case 8:
                selectedFileURL8 = userDefaults.url(forKey: "selectedFileURL8")
                fileDataVal8 = userDefaults.data(forKey: "fileDataVal8") as NSData?
                updateUI(fileURL: selectedFileURL8, fileData: fileDataVal8, label: retirementFileLabel, viewHeight: retirementViewHeight, percentageLabel: retirementPercentageLabel, progressBar: retirementProgressBar, uploadButton: retirementNoticeViewButton)
            case 9:
                selectedFileURL9 = userDefaults.url(forKey: "selectedFileURL9")
                fileDataVal9 = userDefaults.data(forKey: "fileDataVal9") as NSData?
                updateUI(fileURL: selectedFileURL9, fileData: fileDataVal9, label: idCardFileLabel, viewHeight: idCardViewHeight, percentageLabel: idCardPercentageLabel, progressBar: idCardProgressBar, uploadButton: idCardViewButton)
                
            default:
                break
            }
        }
    }
    func saveSelectedFile() {
        let userDefaults = UserDefaults.standard
        
        userDefaults.set(selectedButton, forKey: "selectedButton")
        switch selectedButton {
        case 1:
            userDefaults.set(selectedFileURL, forKey: "selectedFileURL")
            userDefaults.set(fileDataVal1, forKey: "fileDataVal1")
        case 2:
            userDefaults.set(selectedFileURL2, forKey: "selectedFileURL2")
            userDefaults.set(fileDataVal2, forKey: "fileDataVal2")
        case 3:
            userDefaults.set(selectedFileURL3, forKey: "selectedFileURL3")
            userDefaults.set(fileDataVal3, forKey: "fileDataVal3")
        case 4:
            userDefaults.set(selectedFileURL4, forKey: "selectedFileURL4")
            userDefaults.set(fileDataVal4, forKey: "fileDataVal4")
        case 5:
            userDefaults.set(selectedFileURL5, forKey: "selectedFileURL5")
            userDefaults.set(fileDataVal5, forKey: "fileDataVal5")
            
        case 6:
            userDefaults.set(selectedFileURL6, forKey: "selectedFileURL6")
            userDefaults.set(fileDataVal6, forKey: "fileDataVal6")
        case 7:
            userDefaults.set(selectedFileURL7, forKey: "selectedFileURL7")
            userDefaults.set(fileDataVal7, forKey: "fileDataVal7")
        case 8:
            userDefaults.set(selectedFileURL8, forKey: "selectedFileURL8")
            userDefaults.set(fileDataVal8, forKey: "fileDataVal8")
        case 9:
            userDefaults.set(selectedFileURL9, forKey: "selectedFileURL9")
            userDefaults.set(fileDataVal9, forKey: "fileDataVal9")
        default:
            break
        }
    }
    func updateUI(fileURL: URL?, fileData: NSData?, label: UILabel, viewHeight: NSLayoutConstraint, percentageLabel: UILabel, progressBar: UIProgressView, uploadButton: UIButton) {
        guard let fileURL = fileURL, let fileData = fileData else { return }
        label.text = fileURL.lastPathComponent
        viewHeight.constant = 200
        label.isHidden = false
        percentageLabel.isHidden = false
        progressBar.isHidden = true
        uploadButton.isHidden = false
        let fileSize = fileData.length
        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
        percentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
    }
    func preloadImagePicker() {
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
    }
    func fetchRetreiveActiveDocumentAPI() {
        
  
        showHUD(message: "")
        APIManager().perform(DocumentRetreiveRetiree(bearerToken: UserDefaults.standard.accessToken)) { [self] result in
            DispatchQueue.main.async { [self] in
                self.hideHUD()
                switch result {
                case .success(let data):
                    if data.detail.status == "success" {
                        // Always show mandatory fields
                        
                        idCardViewButton.isHidden = false
                        idCardViewHeight.constant = 200
                        idCardCancelButton.isHidden = false
                        idCardPercentageLabel.isHidden = false
                        idCardFileLabel.isHidden = false
                        
                        // Conditionally show optional fields
                        if !data.detail.fileURLResponse.passportPhotoFileURL.isEmpty {
                            passportPhotoViewButton.isHidden = false
                            passportPhotoViewHeight.constant = 200
                            passportPhotoCancelButton.isHidden = false
                            passportPhotoPercentageLabel.isHidden = false
                            passportPhotoFileLabel.isHidden = false
                        }
                        
                        
                        if !data.detail.fileURLResponse.applicationFormFileURL.isEmpty {
                            uploadViewButtton.isHidden = false
                            uploadApplicationViewHeight.constant = 200
                            uploadApplicationCancelButton.isHidden = false
                            uploadApplicationPercentageLabel.isHidden = false
                            uploadApplicationFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.monthlyArrearsPaymentAppointmentFileURL.isEmpty {
                            paymentMonthlyArrearsViewButton.isHidden = false
                            appointmentViewHeight.constant = 200
                            appointmentClearButton.isHidden = false
                            appointmentPercentageLabel.isHidden = false
                            appointmentFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.paymentAuthorizationRetirementOrDeathFileURL.isEmpty {
                            autherizationPaymentViewButton.isHidden = false
                            autherizationViewHeight.constant = 200
                            autherizationCancelButton.isHidden = false
                            autherizationPercentageLabel.isHidden = false
                            autherizationFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.clearanceFormFileURL.isEmpty {
                            clearanceViewButton.isHidden = false
                            clearanceViewHeight.constant = 200
                            clearanceFormCancelButton.isHidden = false
                            clearanceFormPercentageLabel.isHidden = false
                            clearanceFormFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.promotionNotificationFileURL.isEmpty {
                            notificationOfPromotionViewButton.isHidden = false
                            promotionViewHeight.constant = 200
                            promotionCancelButton.isHidden = false
                            promotionPercentageLabel.isHidden = false
                            promotionFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.pensionLifeCertificateFileURL.isEmpty {
                            pensionLifeCertificateViewButton.isHidden = false
                            pensionViewHeight.constant = 200
                            pensionCancelButton.isHidden = false
                            pensionPercentageLabel.isHidden = false
                            pensionFileLabel.isHidden = false
                        }
                        
                        if !data.detail.fileURLResponse.retirementNoticeFileURL.isEmpty {
                            retirementNoticeViewButton.isHidden = false
                            retirementViewHeight.constant = 200
                            retirementCancelButton.isHidden = false
                            retirementPercentageLabel.isHidden = false
                            retirementFileLabel.isHidden = false
                        }
                        
                        
                        
                        // Store URLs
                        self.retreiveData1 = data.detail.fileURLResponse.applicationFormFileURL
                        self.retreiveData2 = data.detail.fileURLResponse.monthlyArrearsPaymentAppointmentFileURL
                        self.retreiveData3 = data.detail.fileURLResponse.paymentAuthorizationRetirementOrDeathFileURL
                        self.retreiveData4 = data.detail.fileURLResponse.clearanceFormFileURL
                        self.retreiveData5 = data.detail.fileURLResponse.promotionNotificationFileURL
                        self.retreiveData6 = data.detail.fileURLResponse.pensionLifeCertificateFileURL
                        self.retreiveData7 = data.detail.fileURLResponse.passportPhotoFileURL
                        self.retreiveData8 = data.detail.fileURLResponse.retirementNoticeFileURL
                        self.retreiveData9 = data.detail.fileURLResponse.idCardFileURL
                    } else if data.detail.status == "fail" {
                        if data.detail.tokenStatus == "valid" {
                            self.alert(message: data.detail.message, title: "Failed")
                        } else if data.detail.tokenStatus == "expired" {
                            self.callRefreshToken()
                        } else if data.detail.tokenStatus == "Invalid" {
                            self.alert(message: data.detail.message, title: "Failed")
                        } else {
                            self.alert(message: "Failed to refresh token", title: "Session Expired")
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        }
                    }
                case .failure(let error):
                    print("error", error)
                    // Handle failure
                }
            }
        }
    }
    func displayFile(at url: URL) {
        let webView = WKWebView(frame: view.bounds)
        let request = URLRequest(url: url)
        webView.load(request)

        // Embed the webView in a navigation controller
        let navController = UINavigationController(rootViewController: UIViewController())
        navController.viewControllers.first?.view = webView
        
        // Add a back button
        let backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backButtonPressed))
        webView.navigationDelegate = self // Make sure your view controller conforms to WKNavigationDelegate
        navController.navigationBar.topItem?.leftBarButtonItem = backButton
        
        present(navController, animated: false, completion: nil)
    }
    @objc func backButtonPressed() {
        dismiss(animated: true, completion: nil)
    }
    func handleViewButtonAction(urlString: String?, selectedButton: Int) {
        if let urlString = urlString, !urlString.isEmpty {
            // Display the document in a web view
            let cmsVC = UIStoryboard(name: "Services", bundle: nil).instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
            cmsVC.URLString = urlString
            let navVC = UINavigationController(rootViewController: cmsVC)
            navVC.modalPresentationStyle = .fullScreen
            present(navVC, animated: true, completion: nil)
        } else {
            // Determine the selected file URL based on the selected button
            let fileURL: URL?
            switch selectedButton {
            case 1:
                fileURL = selectedFileURL
            case 2:
                fileURL = selectedFileURL2
            case 3:
                fileURL = selectedFileURL3
            case 4:
                fileURL = selectedFileURL4
            case 5:
                fileURL = selectedFileURL5
                
            case 6:
                fileURL = selectedFileURL6
            case 7:
                fileURL = selectedFileURL7
            case 8:
                fileURL = selectedFileURL8
            case 9:
                fileURL = selectedFileURL9
                
                
            default:
                fileURL = nil
            }
            
            // Prompt the user to pick a file from their phone
            if let fileURL = fileURL {
                displayFile(at: fileURL)
            } else {
                print("No file selected")
                // Show an alert or handle the case where no file is selected
                showAlertNoFileSelected()
            }
        }
    }
    func showAlertNoFileSelected() {
        let alert = UIAlertController(title: "Error", message: "No file selected", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    func showDocumentPicker() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.data"], in: .import)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .fullScreen
        present(documentPicker, animated: true, completion: nil)
    }
    
    @IBAction func applicationFormViewAction(_ sender: Any) {
        handleViewButtonAction(urlString: retreiveData1, selectedButton: 1)
    }
    
    @IBAction func appointmentPaymentViewAction(_ sender: Any) {
        handleViewButtonAction(urlString: retreiveData2, selectedButton: 2)
    }
    
    @IBAction func autherizationPaymentViewAction(_ sender: Any) {
        handleViewButtonAction(urlString: retreiveData3, selectedButton: 3)
        
    }
    
    
    @IBAction func clearanceFormViewAction(_ sender: Any) {
        handleViewButtonAction(urlString: retreiveData4, selectedButton: 4)
        
    }
    
    
    @IBAction func promotionViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData5, selectedButton: 5)
    }
    
    @IBAction func pensionViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData6, selectedButton: 6)
    }
    
    @IBAction func passportPhotoViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData7, selectedButton: 7)
    }
    
    @IBAction func retirementNoticeViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData8, selectedButton: 8)
    }
    
    @IBAction func idcardViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData9, selectedButton: 9)
    }
    
    @IBAction func nextAction(_ sender: Any) {
        
        guard let idCardFileData = fileDataVal9 else {
            // Handle the case when the mandatory file data is nil
            print("Upload mandatory files")
            DispatchQueue.main.async {
                self.alert(message: "Please upload the mandatory file (ID Card)", title: "Alert")
            }
            return
        }
        
        // Optional file data handling
        let passportPhotoFileData = fileDataVal7
        let applicationFormFileData = fileDataVal1
        let monthlyArrearsFileData = fileDataVal2
        let paymentAuthorizationFileData = fileDataVal3
        let clearanceFormFileData = fileDataVal4
        let promotionNotificationFileData = fileDataVal5
        let pensionLifeCertificateFileData = fileDataVal6
        let retirementNoticeFileData = fileDataVal8
        
        uploadFiles(application_form_file: applicationFormFileData as Data?,
                    monthly_arrears_payment_appointment_file: monthlyArrearsFileData as Data?,
                    payment_authorization_retirement_or_death_file: paymentAuthorizationFileData as Data?,
                    clearance_form_file: clearanceFormFileData as Data?,
                    promotion_notification_file: promotionNotificationFileData as Data?,
                    pension_life_certificate_file: pensionLifeCertificateFileData as Data?,
                    passport_photo_file: passportPhotoFileData as Data?,
                    retirement_notice_file: retirementNoticeFileData as Data?,
                    id_card_file: idCardFileData as Data)
        
        // Function to upload files using Alamofire
        func uploadFiles(application_form_file: Data?,
                         monthly_arrears_payment_appointment_file: Data?,
                         payment_authorization_retirement_or_death_file: Data?,
                         clearance_form_file: Data?,
                         promotion_notification_file: Data?,
                         pension_life_certificate_file: Data?,
                         passport_photo_file: Data?,
                         retirement_notice_file: Data?,
                         id_card_file: Data) {
            // Prepare headers
            let headers: HTTPHeaders = [
                "Authorization": "Bearer \(UserDefaults.standard.accessToken)"
            ]
            
            // Create a dictionary to hold the file data along with their names and MIME types
            var files: [String: (Data, String, String)] = [
                "id_card_file": (id_card_file, "id_card_file.pdf", "application/pdf")
            ]
            
            // Add optional files if available
            if let passportPhotoFileData = passport_photo_file {
                files["passport_photo_file"] = (passportPhotoFileData, "passport_photo.jpg", "image/jpeg")
            }
            if let applicationFormFileData = application_form_file {
                files["application_form_file"] = (applicationFormFileData, "application_form.pdf", "application/pdf")
            }
            if let monthlyArrearsFileData = monthly_arrears_payment_appointment_file {
                files["monthly_arrears_payment_appointment_file"] = (monthlyArrearsFileData, "monthly_arrears.pdf", "application/pdf")
            }
            if let paymentAuthorizationFileData = payment_authorization_retirement_or_death_file {
                files["payment_authorization_retirement_or_death_file"] = (paymentAuthorizationFileData, "payment_authorization.pdf", "application/pdf")
            }
            if let clearanceFormFileData = clearance_form_file {
                files["clearance_form_file"] = (clearanceFormFileData, "clearance_form_file.pdf", "application/pdf")
            }
            if let promotionNotificationFileData = promotion_notification_file {
                files["promotion_notification_file"] = (promotionNotificationFileData, "promotion_notification_file.pdf", "application/pdf")
            }
            if let pensionLifeCertificateFileData = pension_life_certificate_file {
                files["pension_life_certificate_file"] = (pensionLifeCertificateFileData, "pension_life_certificate.pdf", "application/pdf")
            }
            if let retirementNoticeFileData = retirement_notice_file {
                files["retirement_notice_file"] = (retirementNoticeFileData, "retirement_notice.pdf", "application/pdf")
            }
            
            AF.upload(
                multipartFormData: { (multipartFormData) in
                    // Append each file to the multipart form data
                    for (key, (data, fileName, mimeType)) in files {
                        multipartFormData.append(data, withName: key, fileName: fileName, mimeType: mimeType)
                    }
                },
                to: Constants.baseurlRetiree,
                method: .post,
                headers: headers
            )
            .responseJSON { response in
                // Handle API response
                switch response.result {
                case .success(let responseData):
                    do {
                        // Decode JSON response into an instance of ActiveDocumentUploadResponse
                        let decoder = JSONDecoder()
                        let jsonData = try JSONSerialization.data(withJSONObject: responseData)
                        let uploadResponse = try decoder.decode(ActiveDocumentUploadResponse.self, from: jsonData)
                        if uploadResponse.detail.status == "success" {
                            DispatchQueue.main.async {
                                guard let segmentServiceVC = self.parent as? RetireeViewController else {
                                    return
                                }
                                segmentServiceVC.segments.selectedSegmentIndex = 2
                                segmentServiceVC.updateSegmentControl(selectedIndex: 2) // Call the method to update the segment
                                if let scrollView = segmentServiceVC.view.subviews.compactMap({ $0 as? UIScrollView }).first {
                                    scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                                }
                                let toast = ToastView(text: uploadResponse.detail.message)
                                toast.show(in: segmentServiceVC.view, duration: 3.0)
                            }
                            print("Status: \(uploadResponse.detail.status)")
                            print("Message: \(uploadResponse.detail.message)")
                        } else {
                            let toast = ToastView(text: uploadResponse.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                        let toast = ToastView(text: "Error")
                        toast.show(in: self.view, duration: 3.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    DispatchQueue.main.async {
                        var errorMessage = "An error occurred. Please try again later."
                        
                        // Check specific error types and provide more informative messages
                        if let apiError = error as? APIErrorFormat {
                            switch apiError {
                            case .networkError:
                                errorMessage = "Network error. Please check your internet connection."
                            case .invalidResponse:
                                errorMessage = "Invalid response from the server. Please try again."
                            }
                        }
                        
                        let toast = ToastView(text: error.localizedDescription)
                        toast.show(in: self.view, duration: 3.0)
                    }
                }
            }
        }
        
    }

    
    @IBAction func appointmentClearButtonClicked(_ sender: Any) {
        selectedButton = 2
        clearFileInformation(for: 2)
        resetUI(for: 2)
        
    }
    
    @IBAction func autherizationCancelButtonClicked(_ sender: Any) {
        selectedButton = 3
        clearFileInformation(for: 3)
        resetUI(for: 3)
        
    }
    @IBAction func clearanceFormCancelButtonClicked(_ sender: Any) {
        selectedButton = 4
        clearFileInformation(for: 4)
        resetUI(for: 4)
    }
    @IBAction func promotionCancelButtonClicked(_ sender: Any) {
        
        selectedButton = 5
        clearFileInformation(for: 5)
        resetUI(for: 5)
    }
    
    @IBAction func pensionCancelButtonClicked(_ sender: Any) {
        
        selectedButton = 6
        clearFileInformation(for: 6)
        resetUI(for: 6)
    }
    @IBAction func passportPhotoCancelButtonClicked(_ sender: Any) {
        selectedButton = 7
        clearFileInformation(for: 7)
        resetUI(for: 7)    }
    
    @IBAction func retirementCancelButtonClicked(_ sender: Any) {
        selectedButton = 8
        clearFileInformation(for: 8)
        resetUI(for: 8)
    }
    
    @IBAction func idCardCancelButtonClicked(_ sender: Any) {
        selectedButton = 9
        clearFileInformation(for: 9)
        resetUI(for: 9)    }
    
    @IBAction func uploadApplicationCancelButtonClicked(_ sender: Any) {
        selectedButton = 1
        clearFileInformation(for: 1)
        resetUI(for: 1)    }
    
    @IBAction func uploadApplicationUploadButtonClicked(_ sender: Any) {
        selectedButton = 1
        pickAndDisplayFile()
        
    }
    
    @IBAction func appointmentButtonClicked(_ sender: Any) {
        
        selectedButton = 2
        pickAndDisplayFile()
        
    }
    
    @IBAction func autherizationButtonClicked(_ sender: Any) {
        selectedButton = 3
        pickAndDisplayFile()
        
        
    }
    @IBAction func clearanceFormButtonClicked(_ sender: Any) {
        
        selectedButton = 4
        pickAndDisplayFile()    }
    @IBAction func promotionButtonClicked(_ sender: Any) {
        selectedButton = 5
        pickAndDisplayFile()
    }
    @IBAction func pensionButtonClicked(_ sender: Any) {
        selectedButton = 6
        pickAndDisplayFile()
        
    }
    @IBAction func passportPhotoButtonClicked(_ sender: Any) {
        
        selectedButton = 7
        pickImageFromGallery()
    }
    @IBAction func retiremwntButtonClicked(_ sender: Any) {
        
        selectedButton = 8
        pickAndDisplayFile()
        
    }
    @IBAction func idCardButtonClicked(_ sender: Any) {
        
        selectedButton = 9
        pickAndDisplayFile()
        
    }
    
    func clearFileInformation(for button: Int) {
        let userDefaults = UserDefaults.standard
        
        switch button {
        case 1:
            userDefaults.removeObject(forKey: "selectedFileURL")
            userDefaults.removeObject(forKey: "fileDataVal1")
        case 2:
            userDefaults.removeObject(forKey: "selectedFileURL2")
            userDefaults.removeObject(forKey: "fileDataVal2")
        case 3:
            userDefaults.removeObject(forKey: "selectedFileURL3")
            userDefaults.removeObject(forKey: "fileDataVal3")
        case 4:
            userDefaults.removeObject(forKey: "selectedFileURL4")
            userDefaults.removeObject(forKey: "fileDataVal4")
        case 5:
            userDefaults.removeObject(forKey: "selectedFileURL5")
            userDefaults.removeObject(forKey: "fileDataVal5")
        case 6:
            userDefaults.removeObject(forKey: "selectedFileURL6")
            userDefaults.removeObject(forKey: "fileDataVal6")
        case 7:
            userDefaults.removeObject(forKey: "selectedFileURL7")
            userDefaults.removeObject(forKey: "fileDataVal7")
        case 8:
            userDefaults.removeObject(forKey: "selectedFileURL8")
            userDefaults.removeObject(forKey: "fileDataVal8")
        case 9:
            userDefaults.removeObject(forKey: "selectedFileURL9")
            userDefaults.removeObject(forKey: "fileDataVal9")
            
        default:
            break
        }
    }
    
    
    func resetUI(for button: Int) {
        switch button {
        case 1:
            uploadViewButtton.isHidden = true
            uploadApplicationInsideView.isHidden = true
            uploadApplicationFileLabel.text = ""
            uploadApplicationPercentageLabel.text = ""
            uploadApplicationPercentageLabel.isHidden = true
            uploadApplicationProgressBar.isHidden  = true
            uploadApplicationCancelButton.isHidden = true
            uploadApplicationViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 2:
            paymentMonthlyArrearsViewButton.isHidden = true
            appointmentInsideView.isHidden = true
            appointmentFileLabel.text = ""
            appointmentPercentageLabel.text = ""
            appointmentPercentageLabel.isHidden = true
            appointmentProgressBar.isHidden = true
            appointmentClearButton.isHidden = true
            appointmentViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 3:
            autherizationPaymentViewButton.isHidden = true
            autherizationInsideView.isHidden = true
            autherizationFileLabel.text = ""
            autherizationPercentageLabel.text = ""
            autherizationPercentageLabel.isHidden = true
            autherizationProgressBar.isHidden = true
            autherizationCancelButton.isHidden = true
            autherizationViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 4:
            clearanceViewButton.isHidden = true
            clearanceFormInsideView.isHidden = true
            clearanceFormFileLabel.text = ""
            clearanceFormPercentageLabel.text = ""
            clearanceFormPercentageLabel.isHidden = true
            clearanceFormProgressBar.isHidden = true
            clearanceFormCancelButton.isHidden = true
            clearanceFormViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 5:
            notificationOfPromotionViewButton.isHidden = true
            promotionInsideView.isHidden = true
            promotionFileLabel.text = ""
            promotionPercentageLabel.text = ""
            promotionPercentageLabel.isHidden = true
            promotionProgressBar.isHidden  = true
            promotionCancelButton.isHidden = true
            promotionViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 6:
            pensionLifeCertificateViewButton.isHidden = true
            pensionInsideView.isHidden = true
            pensionFileLabel.text = ""
            pensionPercentageLabel.text = ""
            pensionPercentageLabel.isHidden = true
            pensionProgressBar.isHidden = true
            pensionCancelButton.isHidden = true
            pensionViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 7:
            passportPhotoViewButton.isHidden = true
            passportPhotoInsideView.isHidden = true
            passportPhotoFileLabel.text = ""
            passportPhotoPercentageLabel.text = ""
            passportPhotoPercentageLabel.isHidden = true
            passportPhotoProgressBar.isHidden = true
            passportPhotoCancelButton.isHidden = true
            passportPhotoViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 8:
            retirementNoticeViewButton.isHidden = true
            retirementInsideView.isHidden = true
            retirementFileLabel.text = ""
            retirementPercentageLabel.text = ""
            retirementPercentageLabel.isHidden = true
            retirementProgressBar.isHidden = true
            retirementCancelButton.isHidden = true
            retirementViewHeight.constant -= 90 // You can adjust the value as needed
            
        case 9:
            idCardViewButton.isHidden = true
            idCardInsideView.isHidden = true
            idCardFileLabel.text = ""
            idCardPercentageLabel.text = ""
            idCardPercentageLabel.isHidden = true
            idCardProgressBar.isHidden = true
            idCardCancelButton.isHidden = true
            idCardViewHeight.constant -= 90 // You can adjust the value as needed
            
        default:
            break
        }
        UIView.animate(withDuration: 0) {
            self.view.layoutIfNeeded()
        }
    }
    
    
    
    func pickImageFromGallery() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        present(imagePicker, animated: true, completion: nil)
    }
    func pickAndDisplayFile() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["com.adobe.pdf"], in: .import)
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
    }
    
    
    func updateProgressBar(progress: Float) {
        switch selectedButton {
        case 1:
            uploadApplicationProgressBar.progress = progress
        case 2:
            appointmentProgressBar.progress = progress
        case 3:
            autherizationProgressBar.progress = progress
        case 4:
            clearanceFormProgressBar.progress = progress
            
        case 5:
            promotionProgressBar.progress = progress
        case 6:
            pensionProgressBar.progress = progress
        case 7:
            passportPhotoProgressBar.progress = progress
        case 8:
            retirementProgressBar.progress = progress
            
        case 9:
            idCardProgressBar.progress = progress
            
            
        default:
            break
        }
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        
        // Display the file name in the corresponding label
        
        switch selectedButton {
        case 1:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal1 = fileData // Store the loaded file data
            
            uploadApplicationFileLabel.text = selectedURL.lastPathComponent
            self.uploadApplicationViewHeight.constant = 200
            self.uploadApplicationFileLabel.isHidden = false
            self.uploadApplicationPercentageLabel.isHidden = false
            self.uploadApplicationProgressBar.isHidden = false
            self.uploadApplicationCancelButton.isHidden = false
            
            self.uploadApplicationInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.uploadApplicationProgressBar.progress = min(1, progress)
                    self.uploadApplicationPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal1?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.uploadApplicationPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.uploadApplicationProgressBar.isHidden = true
                        uploadViewButtton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
            
        case 2:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL2 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal2 = fileData // Store the loaded file data
            
            appointmentFileLabel.text = selectedURL.lastPathComponent
            self.appointmentViewHeight.constant = 200
            self.appointmentFileLabel.isHidden = false
            self.appointmentPercentageLabel.isHidden = false
            self.appointmentProgressBar.isHidden = false
            self.appointmentClearButton.isHidden = false
            self.appointmentInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.appointmentProgressBar.progress = min(1, progress)
                    self.appointmentPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal2?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.appointmentPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.appointmentProgressBar.isHidden = true
                        paymentMonthlyArrearsViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
            
        case 3:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL3 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal3 = fileData // Store the loaded file data
            
            autherizationFileLabel.text = selectedURL.lastPathComponent
            
            
            
            self.autherizationViewHeight.constant = 200
            self.autherizationFileLabel.isHidden = false
            self.autherizationPercentageLabel.isHidden = false
            self.autherizationProgressBar.isHidden = false
            self.autherizationCancelButton.isHidden = false
            self.autherizationInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.autherizationProgressBar.progress = min(1, progress)
                    self.autherizationPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal3?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.autherizationPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.autherizationProgressBar.isHidden = true
                        autherizationPaymentViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
            
        case 4:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL4 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal4 = fileData // Store the loaded file data
            
            clearanceFormFileLabel.text = selectedURL.lastPathComponent
            
            self.clearanceFormViewHeight.constant = 200
            self.clearanceFormFileLabel.isHidden = false
            self.clearanceFormPercentageLabel.isHidden = false
            self.clearanceFormProgressBar.isHidden = false
            self.clearanceFormCancelButton.isHidden = false
            self.clearanceFormInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.clearanceFormProgressBar.progress = min(1, progress)
                    self.clearanceFormPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal4?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.clearanceFormPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.clearanceFormProgressBar.isHidden = true
                        clearanceViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
        case 5:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL5 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal5 = fileData // Store the loaded file data
            
            promotionFileLabel.text = selectedURL.lastPathComponent
            
            self.promotionViewHeight.constant = 200
            self.promotionFileLabel.isHidden = false
            self.promotionPercentageLabel.isHidden = false
            self.promotionProgressBar.isHidden = false
            self.promotionCancelButton.isHidden = false
            self.promotionInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.promotionProgressBar.progress = min(1, progress)
                    self.promotionPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal5?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.promotionPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.promotionProgressBar.isHidden = true
                        notificationOfPromotionViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
        case 6:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL6 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal6 = fileData // Store the loaded file data
            
            pensionFileLabel.text = selectedURL.lastPathComponent
            
            self.pensionViewHeight.constant = 200
            self.pensionFileLabel.isHidden = false
            self.pensionPercentageLabel.isHidden = false
            self.pensionProgressBar.isHidden = false
            self.pensionCancelButton.isHidden = false
            self.pensionInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.pensionProgressBar.progress = min(1, progress)
                    self.pensionPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal6?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.pensionPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.pensionProgressBar.isHidden = true
                        pensionLifeCertificateViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
            
            /*   case 7:
             guard let fileURL = urls.first else { return }
             print("import result : \(fileURL)")
             fileDataVal7 = NSData(contentsOf: fileURL)
             passportPhotoFileLabel.text = fileURL.lastPathComponent
             
             self.passportPhotoViewHeight.constant = 200
             self.passportPhotoFileLabel.isHidden = false
             self.passportPhotoPercentageLabel.isHidden = false
             self.passportPhotoProgressBar.isHidden = false
             self.passportPhotoCancelButton.isHidden = false
             var progress: Float = 0
             let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
             DispatchQueue.main.async {
             // Update progress bar and label
             progress += 0.1
             self.passportPhotoProgressBar.progress = min(1, progress)
             self.passportPhotoPercentageLabel.text = "\(Int(progress * 100))% uploading"
             
             if progress >= 1 {
             timer.invalidate()
             // Upload completed, perform any additional actions here
             }
             }
             }
             
             uploadTimer.fire()*/
            
        case 8:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL8 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal8 = fileData // Store the loaded file data
            
            retirementFileLabel.text = selectedURL.lastPathComponent
            
            self.retirementViewHeight.constant = 200
            self.retirementFileLabel.isHidden = false
            self.retirementPercentageLabel.isHidden = false
            self.retirementProgressBar.isHidden = false
            self.retirementCancelButton.isHidden = false
            self.retirementInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.retirementProgressBar.progress = min(1, progress)
                    self.retirementPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal8?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.retirementPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.retirementProgressBar.isHidden = true
                        retirementNoticeViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
        case 9:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL9 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal9 = fileData // Store the loaded file data
            
            idCardFileLabel.text = selectedURL.lastPathComponent
            
            self.idCardViewHeight.constant = 200
            self.idCardFileLabel.isHidden = false
            self.idCardPercentageLabel.isHidden = false
            self.idCardProgressBar.isHidden = false
            self.idCardCancelButton.isHidden = false
            self.idCardInsideView.isHidden = false
            
            var progress: Float = 0
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.idCardProgressBar.progress = min(1, progress)
                    self.idCardPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        if let fileSize = fileDataVal9?.length {
                            let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                            self.idCardPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        }
                        
                        self.idCardProgressBar.isHidden = true
                        idCardViewButton.isHidden = false
                        // Optionally, hide the progress bar or show a completion message
                        // self.idCardProgressBar.isHidden = true
                    }
                }
            }
            
            uploadTimer.fire()
        default:
            break
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Handle case for passport photo upload button
            switch selectedButton {
            case 7:
                if let selectedImage = info[.originalImage] as? UIImage {
                    // Extract filename from URL
                    guard let imageURL = info[.imageURL] as? URL else {
                        print("No image URL found")
                        return
                    }
                    
                    selectedFileURL7 = imageURL
                    let fileName = imageURL.lastPathComponent
                    
                    if let data = selectedImage.jpegData(compressionQuality: 1.0) {
                        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                        let destinationURL = documentsURL.appendingPathComponent(fileName)
                        do {
                            try data.write(to: destinationURL)
                            print("Image URL: \(destinationURL)")
                            fileDataVal7 = data as NSData
                            
                            passportPhotoFileLabel.text = fileName
                            passportPhotoViewHeight.constant = 200
                            passportPhotoFileLabel.isHidden = false
                            passportPhotoPercentageLabel.isHidden = false
                            passportPhotoProgressBar.isHidden = false
                            passportPhotoCancelButton.isHidden = false
                            passportPhotoInsideView.isHidden = false
                            
                            // Upload progress handling
                            var progress: Float = 0
                            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                                DispatchQueue.main.async { [self] in
                                    // Update progress bar and label
                                    progress += 0.1
                                    self.passportPhotoProgressBar.progress = min(1, progress)
                                    self.passportPhotoPercentageLabel.text = "\(Int(progress * 100))% uploading"
                                    
                                    if progress >= 1 {
                                        timer.invalidate()
                                        // Upload completed, show file size on progress bar
                                        let fileSize = data.count
                                        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                                        self.passportPhotoPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                                        
                                        // Optionally, hide the progress bar or show a completion message
                                        self.passportPhotoProgressBar.isHidden = true
                                        passportPhotoViewButton.isHidden = false
                                    }
                                }
                            }
                            
                            uploadTimer.fire()
                        } catch {
                            print("Error saving image: \(error)")
                        }
                    }
                }
            default:
                // Handle default case if needed
                break
            }
            
            // Dismiss the image picker
            dismiss(animated: true, completion: nil)
        }
        // Dismiss the image picker
        dismiss(animated: true, completion: nil)
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        // Handle cancellation if needed
    }
}
