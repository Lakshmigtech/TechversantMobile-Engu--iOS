//
//  RetireeBasicDetailsViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit

protocol RetireeDetailsKeyboardDelegate: AnyObject {
    func keyboardWillShow(notification: NSNotification)
    func keyboardWillHide(notification: NSNotification)
}

class RetireeBasicDetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    weak var keyboardDelegate: RetireeDetailsKeyboardDelegate?

    @IBOutlet weak var kinPincodeTextField: UITextField!
    @IBOutlet weak var userPincode: UITextField!
    
    @IBOutlet weak var lgaView: UIView!
    @IBOutlet weak var lgaTableView: UITableView!
    @IBOutlet weak var subtreasuryView: UIView!
    @IBOutlet weak var subtreasuryTableView: UITableView!
    @IBOutlet weak var gradeLevelTextfield: UITextField!
    @IBOutlet weak var gradeLevelView: UIView!
    @IBOutlet weak var gradeLevelTableView: UITableView!
    @IBOutlet weak var countryTextField: UITextField!
    @IBOutlet weak var dobTextField: UITextField!
    @IBOutlet weak var dateOfAppointmentTextField: UITextField!
    @IBOutlet weak var dateOfRetirementTextField: UITextField!
    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var femaleButton: UIButton!
    @IBOutlet weak var subtreasuryTextField: UITextField!
    @IBOutlet weak var lgaTextField: UITextField!
    
    @IBOutlet weak var firstNameTextfield: UITextField!
    @IBOutlet weak var middleNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var nameofNextofKinTextField: UITextField!
    @IBOutlet weak var nextofKinEmailAddressTextField: UITextField!
    @IBOutlet weak var nextofKinPhoneTextField: UITextField!
    @IBOutlet weak var nextofKinAddressTextField: UITextField!
    @IBOutlet weak var lgpbTextField: UITextField!
    @IBOutlet weak var latPromotionYearTextField: UITextField!
    @IBOutlet weak var lastPositionView: UIView!
    @IBOutlet weak var lastPositionTableView: UITableView!
    @IBOutlet weak var lastPositionTextField: UITextField!
    @IBOutlet weak var localGovernmentView: UIView!
    @IBOutlet weak var localGovernmentTableView: UITableView!
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var lgaButton: UIButton!
    @IBOutlet weak var localGovernmentButton: UIButton!
    @IBOutlet weak var subtreasuryButton: UIButton!
    @IBOutlet weak var gradeLevelButton: UIButton!
    @IBOutlet weak var lastPositionButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var buttonView: UIView!
    
    
    var countriesViewController = CountriesViewController()
    var countryName: String?
    var isToggled = false
    var selectedSex: String?
    var isMaleSelected = false
    var isFemaleSelected = false
    var lgas: [Lgas] = []
    var subtreasury: [Lgas] = []
    var gradeLvl:[GradeLevel] = []
    var lastPosition:[LocalGovenmentPensionBoard] = []
    var localGovernment:[LocalGovenmentPensionBoard] = []
    var textFields: [UITextField] = []
    var buttons: [UIButton] = []
    
    var selectedLgaId: Int?
    var selectedSubtreasuryId: Int?
    var selectedGradeLevelId: Int?
    var selectedLastPositionId: Int?
    var selectedLocalGovernmentId: Int?
    
    weak var delegate: BasicDetailsDelegateRetiree?
    // Define a variable to store the initial text of nextofKinPhoneTextField
    var initialText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nextofKinPhoneTextField.keyboardType = .numberPad  // Set the keyboard type to number pad
        nextofKinPhoneTextField.returnKeyType = .done  // Optionally set the return key type
        kinPincodeTextField.keyboardType = .numberPad
        kinPincodeTextField.returnKeyType = .done
        userPincode.keyboardType = .numberPad
        userPincode.returnKeyType = .done

        buttons = [countryButton, lgaButton, subtreasuryButton, gradeLevelButton, lastPositionButton,localGovernmentButton]
        
        textFields = [firstNameTextfield,middleNameTextField, lastNameTextField, dobTextField, addressTextField,userPincode, countryTextField, lgaTextField, nameofNextofKinTextField,nextofKinEmailAddressTextField,  nextofKinPhoneTextField, nextofKinAddressTextField,kinPincodeTextField, lgpbTextField,subtreasuryTextField, dateOfAppointmentTextField,latPromotionYearTextField, gradeLevelTextfield,dateOfRetirementTextField,lastPositionTextField]
        
        for textField in textFields {
            textField.delegate = self
        }
        
        subtreasuryTableView.allowsSelection = true
        lgaTableView.allowsSelection = true
        lgaTableView.delegate = self
        lgaTableView.dataSource = self
        lgaView.isHidden = true
        subtreasuryView.isHidden = true
        lastPositionView.isHidden = true
        subtreasuryTableView.delegate = self
        subtreasuryTableView.dataSource = self
        gradeLevelView.isHidden = true
        gradeLevelTableView.delegate = self
        gradeLevelTableView.dataSource = self
        lastPositionTableView.delegate = self
        lastPositionTableView.dataSource = self
        localGovernmentTableView.delegate = self
        localGovernmentTableView.dataSource = self
        localGovernmentView.isHidden = true
        firstNameTextfield.delegate = self
        middleNameTextField.delegate = self
        lastNameTextField.delegate = self
        nameofNextofKinTextField.delegate = self
        
        userPincode.delegate = self
        kinPincodeTextField.delegate = self
        
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        dobTextField.inputView = datePicker
        
        // Add a toolbar with a done button to dismiss the date picker
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonPressed))
        toolbar.setItems([doneButton], animated: false)
        dobTextField.inputAccessoryView = toolbar
        
        let appointmentDatePicker = UIDatePicker()
        appointmentDatePicker.datePickerMode = .date
        appointmentDatePicker.maximumDate = Date() // Only allow dates up to today
        dateOfAppointmentTextField.inputView = appointmentDatePicker
        
        // Add a toolbar with a done button to dismiss the date picker
        let appointmentToolbar = UIToolbar()
        appointmentToolbar.sizeToFit()
        let appointmentDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(AppointmentDoneButtonPressed))
        appointmentToolbar.setItems([appointmentDoneButton], animated: false)
        dateOfAppointmentTextField.inputAccessoryView = appointmentToolbar
        
        let retireDatePicker = UIDatePicker()
        retireDatePicker.datePickerMode = .date
        retireDatePicker.maximumDate = Date() // Only allow dates up to today
        dateOfRetirementTextField.inputView = retireDatePicker

        let retireToolbar = UIToolbar()
        retireToolbar.sizeToFit()
        let retireDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(RetireDoneButtonPressed))
        retireToolbar.setItems([retireDoneButton], animated: false)
        dateOfRetirementTextField.inputAccessoryView = retireToolbar
        
        maleButton.setImage(UIImage(named: "deselect"), for: .normal)
        femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
        maleButton.isSelected = false
        femaleButton.isSelected = false
        initalSetup()
        setupCountryPicker()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
        fetchBasicDetailsRetrive()
        
        addTapGestures(to: firstNameTextfield)
        
        addTapGestures(to: middleNameTextField)
        
        addTapGestures(to: lastNameTextField)
        
        addTapGestures(to: addressTextField)
        
        addTapGestures(to: nameofNextofKinTextField)
        
        addTapGestures(to: nextofKinEmailAddressTextField)
        
        addTapGestures(to: nextofKinAddressTextField)
        
        // Add gestures to phoneNumberTextField
        addTapGestures(to: nextofKinPhoneTextField)
        
        // Add gestures to passwordTextField
        addTapGestures(to: latPromotionYearTextField)
        
      
    }
   
    
    

    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }

    func fetchBasicDetailsRetrive(){
        
        APIManager().perform(RetireeBasicDetailsRetrive(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            
            switch result {
            case .success(let data):
                if data.detail.status == "success", let userProfileDetails = data.detail.userProfileDetails {
                    
                    DispatchQueue.main.async { [self] in
                        if data.detail.userProfileDetails?.firstName != nil{
                            
                            self.firstNameTextfield.text = userProfileDetails.firstName
                            self.middleNameTextField.text = userProfileDetails.middleName
                            self.lastNameTextField.text = userProfileDetails.lastName
                            self.dobTextField.text = userProfileDetails.dob
                            
                            if let sex = data.detail.userProfileDetails?.sex {
                                switch sex {
                                case "male":
                                    maleButton.setImage(UIImage(named: "select"), for: .normal)
                                case "female":
                                    femaleButton.setImage(UIImage(named: "select"), for: .normal)
                                default:
                                    // Handle other cases if necessary
                                    break
                                }
                            }
                            // Disable the next button when data is successfully populated
                                           self.nextButton.isEnabled = false
                                           self.buttonView.alpha = 0.5 // Optional: Change appearance to indicate it's disabled
                            
                            self.addressTextField.text = userProfileDetails.address
                            self.userPincode.text = userProfileDetails.pincode
                            self.countryTextField.text = userProfileDetails.country
                            self.lgaTextField.text = userProfileDetails.lga
                            self.nameofNextofKinTextField.text = userProfileDetails.nextOfKinName
                            self.nextofKinEmailAddressTextField.text = userProfileDetails.nextOfKinEmail
                            self.nextofKinPhoneTextField.text = userProfileDetails.nextOfKinPhoneNumber
                            self.nextofKinAddressTextField.text = userProfileDetails.nextOfKinAddress
                            self.kinPincodeTextField.text = userProfileDetails.nextOfKinPincode
                            self.subtreasuryTextField.text = userProfileDetails.subTreasury
                            self.dateOfAppointmentTextField.text = userProfileDetails.dateOfAppointment
                            self.latPromotionYearTextField.text = userProfileDetails.lastPromotionYear
                            self.lgpbTextField.text = userProfileDetails.localGovernmentPensionBoard
                            self.gradeLevelTextfield.text = userProfileDetails.gradeLevel
                            self.dateOfRetirementTextField.text = userProfileDetails.dateOfRetirement
                            self.lastPositionTextField.text = userProfileDetails.positionHeldLastIDOrOther
                            delegate?.didRetrieveData(success: true)
                            
                            
                        }
                        else{
                            DispatchQueue.main.async {
                                delegate?.didRetrieveData(success: false)
                            }                        }}
                    
                }else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Failed")
                        }
                    } else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                    } else if data.detail.tokenStatus == "Invalid"{
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Failed")
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.alert(message: "Failed to refresh token", title: "Session Expired")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    delegate?.didRetrieveData(success: false)
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    else if let nsError = error as NSError? {
                        // Check if the error is related to being offline
                        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                            errorMessage = "You are offline. Please check your internet connection."
                        }
                    }
                    
                }
            }
        }
    }
  /*  func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Check if the current text field should only accept alphabets
        let shouldAcceptAlphabets: Bool
        switch textField {
        case firstNameTextfield, middleNameTextField, lastNameTextField, nameofNextofKinTextField:
            shouldAcceptAlphabets = true
        default:
            shouldAcceptAlphabets = false
        }
        
        // If the text field should only accept alphabets, check the input
        if shouldAcceptAlphabets {
            let allowedCharacters = CharacterSet.letters
            let characterSet = CharacterSet(charactersIn: string)
            let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
            
            if !isAlphabetic && !string.isEmpty {
                // Show alert if a non-alphabetic character is entered
                showAlert(message: "Please enter only alphabetic characters.")
                return false
            }
        }
        
        // Check if the current text field should only accept numbers
        let shouldAcceptNumbers: Bool
        switch textField {
        case nextofKinPhoneTextField, kinPincodeTextField, userPincode:
            shouldAcceptNumbers = true
        default:
            shouldAcceptNumbers = false
        }
        
        // If the text field should only accept numbers, check the input
        if shouldAcceptNumbers {
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            let isNumeric = allowedCharacters.isSuperset(of: characterSet)
            
            if !isNumeric && !string.isEmpty {
                // Show alert if a non-numeric character is entered
                showAlert(message: "Please enter only numeric characters.")
                return false
            }
        }
        // If this is the nextofKInPhoneTextField, prevent backspace from deleting initial text
        if textField == nextofKinPhoneTextField {
            // Detect backspace (if the replacement string is empty)
            if string.isEmpty {
                // Ensure backspace is only allowed after the initial text length
                if range.location < initialText.count {
                    // Prevent deleting the initial text
                    return false
                }
            }
        }
        return true
    }*/
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

           // Check if the current text field should only accept alphabets
           let shouldAcceptAlphabets: Bool
           switch textField {
           case firstNameTextfield, middleNameTextField, lastNameTextField, nameofNextofKinTextField:
               shouldAcceptAlphabets = true
           default:
               shouldAcceptAlphabets = false
           }
           
           // If the text field should only accept alphabets, check the input
           if shouldAcceptAlphabets {
               let allowedCharacters = CharacterSet.letters
               let characterSet = CharacterSet(charactersIn: string)
               let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
               
               if !isAlphabetic && !string.isEmpty {
                   // Show alert if a non-alphabetic character is entered
                   showAlert(message: "Please enter only alphabetic characters.")
                   return false
               }
           }
           
           // Check if the current text field should only accept numbers
           let shouldAcceptNumbers: Bool
           switch textField {
           case nextofKinPhoneTextField, kinPincodeTextField, userPincode:
               shouldAcceptNumbers = true
           default:
               shouldAcceptNumbers = false
           }
           
           // If the text field should only accept numbers, check the input
           if shouldAcceptNumbers {
               let allowedCharacters = CharacterSet.decimalDigits
               let characterSet = CharacterSet(charactersIn: string)
               let isNumeric = allowedCharacters.isSuperset(of: characterSet)
               
               if !isNumeric && !string.isEmpty {
                   // Show alert if a non-numeric character is entered
                   showAlert(message: "Please enter only numeric characters.")
                   return false
               }
               
               // Check if the text field is userPincode or kinPincode and limit to 6 digits
                       if (textField == userPincode || textField == kinPincodeTextField) {
                           let currentText = textField.text ?? ""
                           let newLength = currentText.count + string.count - range.length
                           if newLength > 6 {
                               return false
                           }
                       }
               // Check if the text field is nextofKInPhoneTextField and limit to 10 digits
                      if textField == nextofKinPhoneTextField {
                          let currentText = textField.text ?? ""
                          let newLength = currentText.count + string.count - range.length
                          if newLength > 14 {
                              return false
                          }
                     }
                }
        // Handle special logic for nextofKinPhoneTextField
           if textField == nextofKinPhoneTextField {
               // Set initial text if it hasn't been set yet
               if initialText.isEmpty {
                   initialText = textField.text ?? ""
               }
               
               // Detect backspace (if the replacement string is empty)
               if string.isEmpty {
                   // Prevent deleting initial text
                   if range.location < initialText.count {
                       return false
                   }
               }
           }
           
           return true
       }
    
    
    
    func showAlerts(message: String) {
        let alert = UIAlertController(title: "Input Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        // Get the location of the tap
        let location = sender.location(in: view)
        
        // Check if the tap is inside any of the views
        if !lgaView.frame.contains(location) && !subtreasuryView.frame.contains(location) && !gradeLevelView.frame.contains(location) && !lastPositionView.frame.contains(location) && !localGovernmentView.frame.contains(location) {
            // Hide all views
            lgaView.isHidden = true
            subtreasuryView.isHidden = true
            gradeLevelView.isHidden = true
            lastPositionView.isHidden = true
            localGovernmentView.isHidden = true
        }
    }
    @IBAction func buttonClicked(_ sender: UIButton) {
        if sender == lgaButton {
            // Check if the country field is selected
            if !countryButton.isSelected {
                showAlert(message: "Please select Country first.")
                return
            }
        }
        // Check if the clicked button is lga, subtreasury, last grade, or occupation
        if sender  == subtreasuryButton || sender == gradeLevelButton || sender == localGovernmentButton || sender == lastPositionButton{
            // Check if both country and lga text fields have values
            if countryTextField.text?.isEmpty ?? true || lgaTextField.text?.isEmpty ?? true {
                showAlert(message: "Please fill in both Country and LGA fields first.")
                return
            }
        }
        // Allow the button to be selected
        handleButtonSelection(sender)
    }
    func handleButtonSelection(_ button: UIButton) {
        button.isSelected = true
        // let associatedView = buttonViews[button]
        //associatedView?.isHidden = false
    }
    @IBAction func nextButtonClicked(_ sender: Any) {
        fetchBasicDetails()
        
    }
    
    func fetchBasicDetails(){
        guard let firstName = firstNameTextfield.text, !firstName.isEmpty else {
            alert(message: "Please enter First Name", title: "Mandatory Field")
            return
        }
        let middleName = middleNameTextField.text ?? ""
        
        guard let lastName = lastNameTextField.text, !lastName.isEmpty else {
            alert(message: "Please enter Last Name", title: "Mandatory Field")
            return
        }
        guard let dob = dobTextField.text, !dob.isEmpty else {
            alert(message: "Please enter DOB", title: "Mandatory Field")
            return
        }
        guard let address = addressTextField.text, !address.isEmpty else {
            alert(message: "Please enter address", title: "Mandatory Field")
            return
        }
        guard let pincode = userPincode.text, !pincode.isEmpty else {
            alert(message: "Please enter pincode", title: "Mandatory Field")
            return
        }
        
        guard let country = countryTextField.text, !country.isEmpty else {
            alert(message: "Please enter country", title: "Mandatory Field")
            return
        }
        guard let lga = lgaTextField.text, !lga.isEmpty else {
            alert(message: "Please enter lga", title: "Mandatory Field")
            return
        }
        guard let nameofNextofKin = nameofNextofKinTextField.text, !nameofNextofKin.isEmpty else {
            alert(message: "Please enter Name of next of kin", title: "Mandatory Field")
            return
        }
        let nextofKinEmailAddress = nextofKinEmailAddressTextField.text ?? ""

        // Check if the email address is not empty
        if !nextofKinEmailAddress.isEmpty {
            // Validate the email format
            if !nextofKinEmailAddress.isValidEmail {
                // If the email is invalid, show an alert
                alert(message: "Please provide a valid Email Address", title: "Email Validation")
                return
            }
        }
        guard let nextofKinPhone = nextofKinPhoneTextField.text, !nextofKinPhone.isEmpty else {
            alert(message: "Please enter Next of kin  phone", title: "Mandatory Field")
            return
        }
        guard let nextofKinAddress = nextofKinAddressTextField.text, !nextofKinAddress.isEmpty else {
            alert(message: "Please enter next of kin address", title: "Mandatory Field")
            return
        }
        guard let nextofKinPincode = userPincode.text, !nextofKinPincode.isEmpty else {
            alert(message: "Please enter next of kin Pincode", title: "Mandatory Field")
            return
        }
        guard let subtreasury = subtreasuryTextField.text, !subtreasury.isEmpty else {
            alert(message: "Please enter Subtreasury", title: "Mandatory Field")
            return
        }
        guard let dateofAppointment = dateOfAppointmentTextField.text, !dateofAppointment.isEmpty else {
            alert(message: "Please enter Date of Appointment", title: "Mandatory Field")
            return
        }
        guard let lastGrade = gradeLevelTextfield.text, !lastGrade.isEmpty else {
            alert(message: "Please enter Last grade", title: "Mandatory Field")
            return
        }
        guard let lastPositionHeld = lastPositionTextField.text, !lastPositionHeld.isEmpty else {
            alert(message: "Please enter last Promotion held", title: "Mandatory Field")
            return
        }
        guard let lastPromotionYearText = latPromotionYearTextField.text, !lastPromotionYearText.isEmpty else {
            alert(message: "Please enter last Promotion Year", title: "Mandatory Field")
            return
        }
        
        guard let lastPromotionYear = Int(lastPromotionYearText) else {
            alert(message: "Please enter a valid number for the last Promotion Year", title: "Invalid Input")
            return
        }
        guard let dateOfRetirement = dateOfRetirementTextField.text, !dateOfRetirement.isEmpty else {
            alert(message: "Please enter date of retirement", title: "Mandatory Field")
            return
        }
        guard let localGovernmentPension = lgpbTextField.text, !localGovernmentPension.isEmpty else {
            alert(message: "Please enter local Government Pension Board", title: "Mandatory Field")
            return
        }
        guard let sex = selectedSex else {
            alert(message: "Please select a sex", title: "Mandatory Field")
            return
        }
        guard let selectedLgaId = selectedLgaId else {
            return
        }
        
        guard let selectedSubtreasuryId = selectedSubtreasuryId else {
            return
        }
        
        guard let selectedGradeLevelId = selectedGradeLevelId else {
            return
        }
        guard let selectedLastPositionId = selectedLastPositionId else {
            return
        }
        guard let selectedLocalGovernmentId = selectedLocalGovernmentId else {
            return
        }
        
        RetireeUserData.shared.firstName = firstName
        RetireeUserData.shared.middleName = middleName
        RetireeUserData.shared.lastName = lastName
        
        
        self.showHUD(message: "")
        APIManager().perform(RetireeAccountCompletion(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: RetireeAccountCompletion.Body( user_type: "retired", first_name: firstName, middle_name: middleName, last_name:lastName, dob: dob, sex: sex, address: address, pincode: pincode, country: country, lga_id: selectedLgaId , next_of_kin_name: nameofNextofKin, next_of_kin_email: nextofKinEmailAddress, next_of_kin_phone_number: nextofKinPhone, next_of_kin_address: nextofKinAddress, next_of_kin_pincode: nextofKinPincode, local_government_pension_board_id: selectedLocalGovernmentId, sub_treasury_id:selectedSubtreasuryId, date_of_appointment: dateofAppointment, last_promotion_year: lastPromotionYear , grade_level: selectedGradeLevelId, date_of_retirement: dateOfRetirement ,position_held_last_id_or_other: String(selectedLastPositionId)))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        guard let segmentServiceVC = self.parent as? RetireeViewController else {
                            return
                        }
                        segmentServiceVC.segments.selectedSegmentIndex = 1
                        segmentServiceVC.updateSegmentControl(selectedIndex: 1) // Call the method to update the segment
                        if let scrollView = segmentServiceVC.view.subviews.compactMap({ $0 as? UIScrollView }).first {
                            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                        }
                        
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: segmentServiceVC.view, duration: 3.0)
                        
                    }
                }else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)}
                    } else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                    } else if data.detail.tokenStatus == "Invalid" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)}
                    } else {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: "Failed to refresh token")
                            toast.show(in: self.view, duration: 3.0)}
                    }
                } else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
                
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    
                    let toast = ToastView(text: error.localizedDescription)
                    toast.show(in: self.view, duration: 3.0)
                }
            }
        }
    }
    
    
    @IBAction func lgaDropDownClick(_ sender: Any) {
        if isToggled {
            lgaView.isHidden = true
        } else {
            lgaView.isHidden = false
            AccountCompletionAPI()
        }
        isToggled.toggle()
    }
    @IBAction func subtreasuryDropDownClick(_ sender: Any) {
        
        if isToggled {
            subtreasuryView.isHidden = true
            
        } else {
            subtreasuryView.isHidden = false
        }
        isToggled.toggle()
    }
    @IBAction func gradeLevelButtonClicked(_ sender: Any) {
        
        if isToggled {
            gradeLevelView.isHidden = true
            
        } else {
            gradeLevelView.isHidden = false
        }
        isToggled.toggle()
    }
    
    @IBAction func lastPositionDropDown(_ sender: Any) {
        if isToggled {
            lastPositionView.isHidden = true
            
        } else {
            lastPositionView.isHidden = false
        }
        isToggled.toggle()
    }
    
    @IBAction func localGovernmentPensionBoardDropDown(_ sender: Any) {
        
        if isToggled {
            localGovernmentView.isHidden = true
            
        } else {
            localGovernmentView.isHidden = false
        }
        isToggled.toggle()
    }
    func AccountCompletionAPI() {
        let lgaParams: AccountCompletion.Body
        lgaParams = AccountCompletion.Body(country: countryTextField.text ?? "")
        let lgaRequest = AccountCompletion( queryParams: nil, body: lgaParams)
        
        self.showHUD(message: "")
        APIManager().perform(lgaRequest) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                
                if data.detail.status == "success" {
                    self.gradeLvl = data.detail.gradeLevels!
                    self.subtreasury = data.detail.subTreasuries!
                    self.lgas = data.detail.lgas!
                    self.lastPosition = data.detail.positions!
                    self.localGovernment = data.detail.localGovenmentPensionBoards!
                    // Reload the table view on the main thread
                    DispatchQueue.main.async {
                        self.gradeLevelTableView.reloadData()
                        self.subtreasuryTableView.reloadData()
                        self.lgaTableView.reloadData()
                        self.lastPositionTableView.reloadData()
                        self.localGovernmentTableView.reloadData()
                    }
                    
                } else if data.detail.status == "fail" {
                    
                    self.alert(message: data.detail.message!, title: "Failed")
                    
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    
                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == lgaTableView {
            return lgas.count
        } else if tableView == subtreasuryTableView {
            return subtreasury.count
        }
        else if tableView == gradeLevelTableView {
            return gradeLvl.count
        }
        else if tableView == lastPositionTableView {
            return lastPosition.count
        }
        else if tableView == localGovernmentTableView {
            return localGovernment.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == lgaTableView {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cells", for: indexPath) as? RetireeLgaTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            
            cell.textLabel?.text = lgas[indexPath.row].name
            
            return cell
            
        }
        else if tableView == subtreasuryTableView {
            
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? RetireeSubtreasuryTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            
            cell.textLabel?.text = subtreasury[indexPath.row].name
            
            return cell
        }
        else if tableView == gradeLevelTableView {
            
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? RetireGradeLevelTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            cell.textLabel?.text = gradeLvl[indexPath.row].level
            
            return cell
        }
        else if tableView == lastPositionTableView {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? LastPositionHeldTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            cell.textLabel?.text = lastPosition[indexPath.row].positionName
            
            return cell
        }
        else if tableView == localGovernmentTableView {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? LocalGovernmentTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            cell.textLabel?.text = localGovernment[indexPath.row].positionName
            
            return cell
        }
        
        // Return a default cell if neither condition is met
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lgaView.isHidden = true
        isToggled = false
        subtreasuryView.isHidden = true
        isToggled = false
        gradeLevelView.isHidden = true
        isToggled = false
        lastPositionView.isHidden = true
        isToggled = false
        localGovernmentView.isHidden = true
        isToggled = false
        
        if tableView == subtreasuryTableView {
            let selectedlga = subtreasury[indexPath.row]
            subtreasuryTextField.text = selectedlga.name
            selectedSubtreasuryId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.subtreasuryView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }
        else if tableView == lgaTableView {
            let selectedlga = lgas[indexPath.row]
            lgaTextField.text = selectedlga.name
            selectedLgaId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.lgaView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }
        else if tableView == gradeLevelTableView {
            let selectedlga = gradeLvl[indexPath.row]
            gradeLevelTextfield.text = selectedlga.level
            
            selectedGradeLevelId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.gradeLevelView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
            
        }
        else if tableView == lastPositionTableView {
            let selectedlga = lastPosition[indexPath.row]
            lastPositionTextField.text = selectedlga.positionName
            
            selectedLastPositionId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.lastPositionView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }
        else if tableView == localGovernmentTableView {
            let selectedlga = localGovernment[indexPath.row]
            lgpbTextField.text = selectedlga.positionName
            
            selectedLocalGovernmentId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.localGovernmentView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }
    }
  /*  func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
    // method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }*/
    
    func initalSetup() {
           let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
           view.addGestureRecognizer(tap)
           
           // Register for keyboard notifications
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
           
           // Set the text field delegates
           for view in view.subviews {
               if let textField = view as? UITextField {
                   textField.delegate = self
                   textFields.append(textField)
               }
           }
       }
       
       deinit {
           // Remove the keyboard notifications
           NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
           NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
       }
    
       
       @objc func keyboardWillShow(notification: NSNotification) {
           keyboardDelegate?.keyboardWillShow(notification: notification)
       }
       
       @objc func keyboardWillHide(notification: NSNotification) {
           keyboardDelegate?.keyboardWillHide(notification: notification)
       }
       
       @objc func dismissKeyBord() {
           self.view.endEditing(true)
       }
   
    
    
    
    func setupCountryPicker(){
        self.countriesViewController = CountriesViewController()
        self.countriesViewController.delegate = self
        self.countriesViewController.allowMultipleSelection = false
        if let info = self.getCountryAndName() {
            countryName = info.countryName!
            // self.lblFlag.text = info.countryFlag!
            self.countryTextField.text = info.countryName!
        }
    }
    
    private func getCountryAndName(_ countryParam: String? = nil) -> CountryModel? {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonObj = JSON(data)
                let countryData = CountryListModel.init(jsonObj.arrayValue)
                let locale: Locale = Locale.current
                var countryCode: String?
                if countryParam != nil {
                    countryCode = countryParam
                } else {
                    countryCode = locale.regionCode
                }
                let currentInfo = countryData.country?.filter({ (cm) -> Bool in
                    return cm.countryShortName?.lowercased() == countryCode?.lowercased()
                })
                
                if currentInfo!.count > 0 {
                    return currentInfo?.first
                } else {
                    return nil
                }
                
            } catch {
                // handle error
            }
        }
        return nil
    }
    
    @IBAction func maleButtonClicked(_ sender: Any) {
        selectedSex = "male"
        maleButton.isSelected = !maleButton.isSelected
        
        // Set image based on button state
        if maleButton.isSelected {
            maleButton.setImage(UIImage(named: "select"), for: .normal)
            femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
            femaleButton.isSelected = false
        } else {
            maleButton.setImage(UIImage(named: "deselect"), for: .normal)
        }
        male()
    }
    @IBAction func femalebuttonClicked(_ sender: Any) {
        selectedSex = "female"
        femaleButton.isSelected = !femaleButton.isSelected
        
        // Set image based on button state
        if femaleButton.isSelected {
            femaleButton.setImage(UIImage(named: "select"), for: .normal)
            maleButton.setImage(UIImage(named: "deselect"), for: .normal)
            maleButton.isSelected = false
        } else {
            femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
        }
        female()
        
    }
    func male(){
        if !isMaleSelected {
            selectedSex = "male"
            isMaleSelected = true
            isFemaleSelected = false
        } else {
            selectedSex = nil
            isMaleSelected = false
        }
        
        updateButtonStates()
    }
    func female(){
        if !isFemaleSelected {
            selectedSex = "female"
            isFemaleSelected = true
            isMaleSelected = false
        } else {
            selectedSex = nil
            isFemaleSelected = false
        }
        
        updateButtonStates()
    }
    func updateButtonStates() {
        // Update button UI based on the selection
        maleButton.isSelected = isMaleSelected
        femaleButton.isSelected = isFemaleSelected
    }
    
    @objc func doneButtonPressed() {
        let datePicker = dobTextField.inputView as! UIDatePicker
        let selectedDate = datePicker.date
        
        // Format the selected date and update the text field
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" // Adjust the date format here
        dobTextField.text = dateFormatter.string(from: selectedDate)
        
        // Dismiss the date picker
        dobTextField.resignFirstResponder()
        
        // Calculate the age and check if the person is at least 18 years old
        let calendar = Calendar.current
        let currentDate = Date()
        
        let ageComponents = calendar.dateComponents([.year], from: selectedDate, to: currentDate)
        if let age = ageComponents.year, age >= 18 {
            // Person is at least 18 years old
            // Proceed with the rest of the code
        } else {
            // Person is not 18 years old or more
            alert(message: "Person should be 18 years old or more", title: "Age Restriction")
            dobTextField.text = "" // Clear the text field if the age is not valid
        }
    }
    @objc func RetireDoneButtonPressed() {
        let datePicker = dateOfRetirementTextField.inputView as! UIDatePicker
        let selectedDate = datePicker.date
        
        // Format the selected date and update the text field
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" // Adjust the date format here
        dateOfRetirementTextField.text = dateFormatter.string(from: selectedDate)
        
        // Validate the dates
            if let appointmentText = dateOfAppointmentTextField.text, !appointmentText.isEmpty {
                let appointmentDate = dateFormatter.date(from: appointmentText)
                
                if let appointmentDate = appointmentDate, selectedDate <= appointmentDate {
                    showAlert(message: "Date of Appointment must be earlier than Date of Retirement.")
                }
            }
        
        
        // Dismiss the date picker
        dateOfRetirementTextField.resignFirstResponder()
    }
    @objc func AppointmentDoneButtonPressed() {
        // This function is called when the "Done" button on the toolbar is pressed
        let datePicker = dateOfAppointmentTextField.inputView as! UIDatePicker
        let selectedDate = datePicker.date
        
        // Format the selected date and update the text field
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" // Adjust the date format here
        dateOfAppointmentTextField.text = dateFormatter.string(from: selectedDate)
        
        // Validate the dates
           if let retirementText = dateOfRetirementTextField.text, !retirementText.isEmpty {
               let retirementDate = dateFormatter.date(from: retirementText)
               
               if let retirementDate = retirementDate, selectedDate >= retirementDate {
                   showAlert(message: "Date of Appointment must be earlier than Date of Retirement.")
               }
           }
        
        
        // Dismiss the date picker
        dateOfAppointmentTextField.resignFirstResponder()
    }
   
    
    
    
    
    
    @IBAction func countryDropDownClicked(_ sender: UIButton) {
        
        DispatchQueue.main.async {
            CountriesViewController.show(countriesViewController: self.countriesViewController, toVar: self)
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let index = textFields.firstIndex(of: textField) {
            if index < textFields.count - 1 {
                let nextTextField = textFields[index + 1]
                nextTextField.becomeFirstResponder()
            } else {
                textField.resignFirstResponder()
            }
        }
        return true
    }
    // UITextFieldDelegate method to handle editing
 /*   func textFieldDidBeginEditing(_ textField: UITextField) {
        if let index = textFields.firstIndex(of: textField), index > 0 {
            let previousTextField = textFields[index - 1]
            if previousTextField.text?.isEmpty ?? true {
                // Show error message
                showAlert(message: "Please fill in the order.")
                textField.resignFirstResponder()
            }
        }
    }*/

    
    // Helper method to show alert message
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
extension RetireeBasicDetailsViewController: CountriesViewControllerDelegate {
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountries countries: [Country]) {
        
        countries.forEach { co in
            //            Logger.println(co.name)
        }
    }
    func countriesViewControllerDidCancel(_ countriesViewController: CountriesViewController) {
        
        //        Logger.println("user hass been tap cancel")
        
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountry country: Country) {
        if let info = self.getCountryAndName(country.countryCode) {
            countryName = info.countryName!
            //  self.lblFlag.text = info.countryFlag!
            self.countryTextField.text = info.countryName!
            self.nextofKinPhoneTextField.text = info.countryCode!
        }
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didUnselectCountry country: Country) {
        
        //        Logger.println(country.name + " unselected")
    }
}
