//
//  RetireeUserData.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 03/04/24.
//

import Foundation

struct RetireeUserData {
    static var shared = RetireeUserData()
    
    private let firstNameKey = "firstName"
    private let middleNameKey = "middleName"
    private let lastNameKey = "lastName"
    
    var firstName: String? {
        get { return UserDefaults.standard.string(forKey: firstNameKey) }
        set { UserDefaults.standard.set(newValue, forKey: firstNameKey) }
    }
    
    var middleName: String? {
        get { return UserDefaults.standard.string(forKey: middleNameKey) }
        set { UserDefaults.standard.set(newValue, forKey: middleNameKey) }
    }
    
    var lastName: String? {
        get { return UserDefaults.standard.string(forKey: lastNameKey) }
        set { UserDefaults.standard.set(newValue, forKey: lastNameKey) }
    }
    
    private init() {}
}
