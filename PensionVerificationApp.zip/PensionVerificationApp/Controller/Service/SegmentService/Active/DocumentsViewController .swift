//
//  DocumentsViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit
import Alamofire
import WebKit

class DocumentsViewController: UIViewController, UIDocumentPickerDelegate, UIImagePickerControllerDelegate & UINavigationControllerDelegate, WKNavigationDelegate{
    
    
    @IBOutlet weak var uploadApplicationButton: UIButton!
    @IBOutlet weak var promotionLetterViewButton: UIButton!
    @IBOutlet weak var idCardViewButton: UIButton!
    @IBOutlet weak var passportPhotoViewButton: UIButton!
    @IBOutlet weak var clearanceViewButton: UIButton!
    
    
    @IBOutlet weak var uploadCancelButton: UIButton!
    @IBOutlet weak var promotionCancelButton: UIButton!
    @IBOutlet weak var idCardCancelButton: UIButton!
    @IBOutlet weak var passportCancelButton: UIButton!
    @IBOutlet weak var clearanceCancelButton: UIButton!
    
    @IBOutlet weak var uploadButton: UIButton!
    @IBOutlet weak var selectedFileLabel: UILabel!
    @IBOutlet weak var mainContentView: UIView!
    @IBOutlet weak var percentageLabel: UILabel!
    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var insideView: UIView!
    @IBOutlet weak var uploadButtonView: UIView!
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var promotionLetterFileLabel: UILabel!
    @IBOutlet weak var PromotionLetterPercentageLabel: UILabel!
    @IBOutlet weak var promotionLetterProgressBar: UIProgressView!
    @IBOutlet weak var promotionLetterUploadButton: UIButton!
    @IBOutlet weak var promotionContentView: UIView!
    @IBOutlet weak var promotionInsideView: UIView!
    @IBOutlet weak var promotionUploadView: UIView!
    @IBOutlet weak var promotionLetterViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var idCardFileLabel: UILabel!
    @IBOutlet weak var idCardPercentageLabel: UILabel!
    @IBOutlet weak var idCardProgressBar: UIProgressView!
    @IBOutlet weak var idCardUploadButton: UIButton!
    @IBOutlet weak var idCardContentView: UIView!
    @IBOutlet weak var idCardInsideView: UIView!
    @IBOutlet weak var idCardUploadView: UIView!
    @IBOutlet weak var idCardViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var photoFileLabel: UILabel!
    @IBOutlet weak var photoPercentageLabel: UILabel!
    @IBOutlet weak var photoProgressBar: UIProgressView!
    @IBOutlet weak var photoUploadButton: UIButton!
    @IBOutlet weak var photoContentView: UIView!
    @IBOutlet weak var photoInsideView: UIView!
    @IBOutlet weak var photoUploadView: UIView!
    @IBOutlet weak var photoViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var clearanceFileLabel: UILabel!
    @IBOutlet weak var clearancePercentageLabel: UILabel!
    @IBOutlet weak var clearanceProgressBar: UIProgressView!
    @IBOutlet weak var clearanceUploadButton: UIButton!
    @IBOutlet weak var clearanceContentView: UIView!
    @IBOutlet weak var clearanceInsideView: UIView!
    @IBOutlet weak var clearanceUploadView: UIView!
    @IBOutlet weak var clearanceViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var buttonView: UIView!
    

    
    
    var fileDataVal1:NSData?
    var fileDataVal2:NSData?
    var fileDataVal3:NSData?
    var fileDataVal4:NSData?
    var fileDataVal5:NSData?
    
    var retreiveData1:String?
    var retreiveData2:String?
    var retreiveData3:String?
    var retreiveData4:String?
    var retreiveData5:String?
    
    var imagePicker: UIImagePickerController!
    
    var selectedFileURL: URL? // Variable to store the selected file URL
    var selectedFileURL2: URL?
    var selectedFileURL3: URL?
    var selectedFileURL4: URL?
    var selectedFileURL5: URL?
    
    var selectedButton: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        preloadImagePicker()
        fetchRetrieveActiveDocumentAPI()
        
        uploadApplicationButton.isHidden = true
        promotionLetterViewButton.isHidden = true
        idCardViewButton.isHidden = true
        passportPhotoViewButton.isHidden =  true
        clearanceViewButton.isHidden = true
        
        self.navigationController?.navigationBar.isHidden = true
        self.uploadCancelButton.isHidden = true
        self.promotionCancelButton.isHidden = true
        self.idCardCancelButton.isHidden = true
        self.passportCancelButton.isHidden = true
        progressBar.isHidden = true
        percentageLabel . isHidden = true
        selectedFileLabel.isHidden = true
        mainContentView.applyShadow()
        mainContentView.applyCornerRadius(20)
        insideView.applyShadow()
        uploadButtonView.addRoundedBottomCorners(radius: 20)
        insideView.applyCornerRadius(10)
        
        promotionLetterProgressBar.isHidden = true
        PromotionLetterPercentageLabel . isHidden = true
        promotionLetterFileLabel.isHidden = true
        promotionContentView.applyShadow()
        promotionContentView.applyCornerRadius(20)
        promotionInsideView.applyShadow()
        promotionUploadView.addRoundedBottomCorners(radius: 20)
        promotionInsideView.applyCornerRadius(10)
        
        idCardProgressBar.isHidden = true
        idCardPercentageLabel . isHidden = true
        idCardFileLabel.isHidden = true
        idCardContentView.applyShadow()
        idCardContentView.applyCornerRadius(20)
        idCardInsideView.applyShadow()
        idCardUploadView.addRoundedBottomCorners(radius: 20)
        idCardInsideView.applyCornerRadius(10)
        
        photoProgressBar.isHidden = true
        photoFileLabel . isHidden = true
        photoPercentageLabel.isHidden = true
        photoContentView.applyShadow()
        photoContentView.applyCornerRadius(20)
        photoInsideView.applyShadow()
        photoUploadView.addRoundedBottomCorners(radius: 20)
        photoInsideView.applyCornerRadius(10)
        
        clearanceProgressBar.isHidden = true
        // clearanceFileLabel . isHidden = true
        // clearancePercentageLabel.isHidden = true
        clearanceContentView.applyShadow()
        clearanceContentView.applyCornerRadius(20)
        clearanceInsideView.applyShadow()
        clearanceUploadView.addRoundedBottomCorners(radius: 20)
        clearanceInsideView.applyCornerRadius(10)
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Load the selected file based on the selected button and update UI
        loadSelectedFile()
    }
    
    func loadSelectedFile() {
        let userDefaults = UserDefaults.standard
        
        if let savedSelectedButton = userDefaults.value(forKey: "selectedButton") as? Int {
            selectedButton = savedSelectedButton
            
            switch selectedButton {
            case 1:
                selectedFileURL = userDefaults.url(forKey: "selectedFileURL")
                fileDataVal1 = userDefaults.data(forKey: "fileDataVal1") as NSData?
                updateUI(fileURL: selectedFileURL, fileData: fileDataVal1, label: selectedFileLabel, viewHeight: viewHeight, percentageLabel: percentageLabel, progressBar: progressBar, uploadButton: uploadApplicationButton)
            case 2:
                selectedFileURL2 = userDefaults.url(forKey: "selectedFileURL2")
                fileDataVal2 = userDefaults.data(forKey: "fileDataVal2") as NSData?
                updateUI(fileURL: selectedFileURL2, fileData: fileDataVal2, label: promotionLetterFileLabel, viewHeight: promotionLetterViewHeight, percentageLabel: PromotionLetterPercentageLabel, progressBar: promotionLetterProgressBar, uploadButton: promotionLetterViewButton)
            case 3:
                selectedFileURL3 = userDefaults.url(forKey: "selectedFileURL3")
                fileDataVal3 = userDefaults.data(forKey: "fileDataVal3") as NSData?
                updateUI(fileURL: selectedFileURL3, fileData: fileDataVal3, label: idCardFileLabel, viewHeight: idCardViewHeight, percentageLabel: idCardPercentageLabel, progressBar: idCardProgressBar, uploadButton: idCardViewButton)
            case 4:
                selectedFileURL4 = userDefaults.url(forKey: "selectedFileURL4")
                fileDataVal4 = userDefaults.data(forKey: "fileDataVal4") as NSData?
                updateUI(fileURL: selectedFileURL4, fileData: fileDataVal4, label: photoFileLabel, viewHeight: photoViewHeight, percentageLabel: photoPercentageLabel, progressBar: photoProgressBar, uploadButton: passportPhotoViewButton)
            case 5:
                selectedFileURL5 = userDefaults.url(forKey: "selectedFileURL5")
                fileDataVal5 = userDefaults.data(forKey: "fileDataVal5") as NSData?
                updateUI(fileURL: selectedFileURL5, fileData: fileDataVal5, label: clearanceFileLabel, viewHeight: clearanceViewHeight, percentageLabel: clearancePercentageLabel, progressBar: clearanceProgressBar, uploadButton: clearanceViewButton)
            default:
                break
            }
        }
    }
    
    func saveSelectedFile() {
        let userDefaults = UserDefaults.standard
        
        userDefaults.set(selectedButton, forKey: "selectedButton")
        switch selectedButton {
        case 1:
            userDefaults.set(selectedFileURL, forKey: "selectedFileURL")
            userDefaults.set(fileDataVal1, forKey: "fileDataVal1")
        case 2:
            userDefaults.set(selectedFileURL2, forKey: "selectedFileURL2")
            userDefaults.set(fileDataVal2, forKey: "fileDataVal2")
        case 3:
            userDefaults.set(selectedFileURL3, forKey: "selectedFileURL3")
            userDefaults.set(fileDataVal3, forKey: "fileDataVal3")
        case 4:
            userDefaults.set(selectedFileURL4, forKey: "selectedFileURL4")
            userDefaults.set(fileDataVal4, forKey: "fileDataVal4")
        case 5:
            userDefaults.set(selectedFileURL5, forKey: "selectedFileURL5")
            userDefaults.set(fileDataVal5, forKey: "fileDataVal5")
        default:
            break
        }
    }
    func updateUI(fileURL: URL?, fileData: NSData?, label: UILabel, viewHeight: NSLayoutConstraint, percentageLabel: UILabel, progressBar: UIProgressView, uploadButton: UIButton) {
        guard let fileURL = fileURL, let fileData = fileData else { return }
        label.text = fileURL.lastPathComponent
        viewHeight.constant = 200
        label.isHidden = false
        percentageLabel.isHidden = false
        progressBar.isHidden = true
        uploadButton.isHidden = false
        let fileSize = fileData.length
        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
        percentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
    }
    
    func preloadImagePicker() {
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
    }
  
    func fetchRetrieveActiveDocumentAPI() {
        showHUD(message: "")
           APIManager().perform(DocumentRetreiveActive(bearerToken: UserDefaults.standard.accessToken)) { [self] result in
               DispatchQueue.main.async { [self] in // Ensure UI updates are performed on the main thread
                   self.hideHUD()
                   switch result {
                   case .success(let data):
                       if data.detail.status == "success" {
                           // Mandatory fields (ID Card and Passport Photo)
                           idCardViewButton.isHidden = false
                           idCardViewHeight.constant = 200
                           idCardCancelButton.isHidden = false
                           idCardPercentageLabel.isHidden = false
                           idCardFileLabel.isHidden = false
                           
                           // Optional fields
                           if !data.detail.fileURLResponse.passportPhotoFileURL.isEmpty {
                               passportPhotoViewButton.isHidden = false
                               photoViewHeight.constant = 200
                               passportCancelButton.isHidden = false
                               photoPercentageLabel.isHidden = false
                               photoFileLabel.isHidden = false
                           }
                           
                           if !data.detail.fileURLResponse.applicationFormFileURL.isEmpty {
                               uploadApplicationButton.isHidden = false
                               viewHeight.constant = 200
                               uploadCancelButton.isHidden = false
                               percentageLabel.isHidden = false
                               selectedFileLabel.isHidden = false
                           }
                           
                           if !data.detail.fileURLResponse.promotionLetterTransferLetterFileURL.isEmpty {
                               promotionLetterViewButton.isHidden = false
                               promotionLetterViewHeight.constant = 200
                               promotionCancelButton.isHidden = false
                               PromotionLetterPercentageLabel.isHidden = false
                               promotionLetterFileLabel.isHidden = false
                           }
                           
                           if !data.detail.fileURLResponse.clearanceFormFileURL.isEmpty {
                               clearanceViewButton.isHidden = false
                               clearanceViewHeight.constant = 200
                               clearanceCancelButton.isHidden = false
                               clearancePercentageLabel.isHidden = false
                               clearanceFileLabel.isHidden = false
                           }
                          
                           
                           // Store URLs
                           self.retreiveData1 = data.detail.fileURLResponse.applicationFormFileURL
                           self.retreiveData2 = data.detail.fileURLResponse.promotionLetterTransferLetterFileURL
                           self.retreiveData3 = data.detail.fileURLResponse.idCardFileURL
                           self.retreiveData4 = data.detail.fileURLResponse.passportPhotoFileURL
                           self.retreiveData5 = data.detail.fileURLResponse.clearanceFormFileURL
                       } else if data.detail.status == "fail" {
                           if data.detail.tokenStatus == "valid" {
                               self.alert(message: data.detail.message, title: "Failed")
                           } else if data.detail.tokenStatus == "expired" {
                               self.callRefreshToken()
                           } else if data.detail.tokenStatus == "Invalid" {
                               self.alert(message: data.detail.message, title: "Failed")
                           } else {
                               self.alert(message: "Failed to refresh token", title: "Session Expired")
                           }
                       }
                   case .failure(let error):
                       print("error", error)
                      
                    // Handle failure
                }
            }
        }
    }
    func displayFile(at url: URL) {
        let webView = WKWebView(frame: view.bounds)
        let request = URLRequest(url: url)
        webView.load(request)
        
        // Embed the webView in a navigation controller
        let navController = UINavigationController(rootViewController: UIViewController())
        navController.viewControllers.first?.view = webView
        
        // Add a back button
        let backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backButtonPressed))
        webView.navigationDelegate = self // Make sure your view controller conforms to WKNavigationDelegate
        navController.navigationBar.topItem?.leftBarButtonItem = backButton
        
        present(navController, animated: false, completion: nil)
    }
    
    @objc func backButtonPressed() {
        dismiss(animated: true, completion: nil)
    }
    
    func handleViewButtonAction(urlString: String?, selectedButton: Int) {
        if let urlString = urlString, !urlString.isEmpty {
            // Display the document in a web view
            let cmsVC = UIStoryboard(name: "Services", bundle: nil).instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
            cmsVC.URLString = urlString
            let navVC = UINavigationController(rootViewController: cmsVC)
            navVC.modalPresentationStyle = .fullScreen
            present(navVC, animated: true, completion: nil)
        } else {
            // Determine the selected file URL based on the selected button
            let fileURL: URL?
            switch selectedButton {
            case 1:
                fileURL = selectedFileURL
            case 2:
                fileURL = selectedFileURL2
            case 3:
                fileURL = selectedFileURL3
            case 4:
                fileURL = selectedFileURL4
            case 5:
                fileURL = selectedFileURL5
            default:
                fileURL = nil
            }
            
            // Prompt the user to pick a file from their phone
            if let fileURL = fileURL {
                displayFile(at: fileURL)
            } else {
                print("No file selected")
                // Show an alert or handle the case where no file is selected
                showAlertNoFileSelected()
            }
        }
    }
    // Helper function to show an alert when no file is selected
    func showAlertNoFileSelected() {
        let alert = UIAlertController(title: "Error", message: "No file selected", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func showDocumentPicker() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.data"], in: .import)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .fullScreen
        present(documentPicker, animated: true, completion: nil)
    }
    @IBAction func documentViewButtonAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData1, selectedButton: 1)
    }
    
    @IBAction func promotionLetterViewAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData2, selectedButton: 2)
    }
    @IBAction func idCardViewButtonAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData3, selectedButton: 3)
        
    }
    @IBAction func passportPhotoViewButtonAction(_ sender: Any) {
        
        handleViewButtonAction(urlString: retreiveData4, selectedButton: 4)
    }
    @IBAction func clearancrFormViewButtonAction(_ sender: Any) {
        handleViewButtonAction(urlString: retreiveData5, selectedButton: 5)
    }
    @IBAction func nextButtonClicked(_ sender: Any) {
        
        guard let idCardFileData = fileDataVal3 else {
            // Handle the case when the mandatory ID card file data is nil
            print("Upload mandatory ID card file")
            DispatchQueue.main.async {
                self.alert(message: "Please upload the mandatory file (ID Card)", title: "Alert")
            }
            return
        }

        // Optional file data handling
        let applicationFormFileData = fileDataVal1
        let promotionLetterFileData = fileDataVal2
        let passportPhotoFileData = fileDataVal4
        let clearanceFormFileData = fileDataVal5

        uploadFiles(
            application_form_file: applicationFormFileData as Data?,
            promotion_letter_transfer_letter_file: promotionLetterFileData as Data?,
            id_card_file: idCardFileData as Data,
            passport_photo_file: passportPhotoFileData as Data?,
            clearance_form_file: clearanceFormFileData as Data?
        )

        // Function to upload files using Alamofire
        func uploadFiles(application_form_file: Data?,
                         promotion_letter_transfer_letter_file: Data?,
                         id_card_file: Data,
                         passport_photo_file: Data?,
                         clearance_form_file: Data?) {
            // Prepare headers
            let headers: HTTPHeaders = [
                "Authorization": "Bearer \(UserDefaults.standard.accessToken)"
            ]
            
            // Create a dictionary to hold the file data along with their names and MIME types.
            var files: [String: (Data, String, String)] = [
                "id_card_file": (id_card_file, "id_card.pdf", "application/pdf")
            ]
            
            // Add optional files if available
            if let applicationFormFileData = application_form_file {
                files["application_form_file"] = (applicationFormFileData, "application_form.pdf", "application/pdf")
            }
            if let promotionLetterFileData = promotion_letter_transfer_letter_file {
                files["promotion_letter_transfer_letter_file"] = (promotionLetterFileData, "promotion_letter.pdf", "application/pdf")
            }
            if let passportPhotoFileData = passport_photo_file {
                files["passport_photo_file"] = (passportPhotoFileData, "passport_photo.jpg", "image/jpeg")
            }
            if let clearanceFormFileData = clearance_form_file {
                files["clearance_form_file"] = (clearanceFormFileData, "clearance_form.pdf", "application/pdf")
            }
            
            AF.upload(
                multipartFormData: { (multipartFormData) in
                    // Append each file to the multipart form data
                    for (key, (data, fileName, mimeType)) in files {
                        multipartFormData.append(data, withName: key, fileName: fileName, mimeType: mimeType)
                    }
                },
                to: Constants.baseurlActive,
                method: .post,
                headers: headers
            )
            .responseJSON { response in
                // Handle API response
                switch response.result {
                case .success(let responseData):
                    do {
                        

                        
                        
                        // Decode JSON response into an instance of ActiveDocumentUploadResponse
                        let decoder = JSONDecoder()
                        let jsonData = try JSONSerialization.data(withJSONObject: responseData)
                        let uploadResponse = try decoder.decode(ActiveDocumentUploadResponse.self, from: jsonData)
                        if uploadResponse.detail.status == "success" {
                            DispatchQueue.main.async {
                                guard let segmentServiceVC = self.parent as? SegmentServiceViewController else {
                                    return
                                }
                                segmentServiceVC.segments.selectedSegmentIndex = 2
                                segmentServiceVC.updateSegmentControl(selectedIndex: 2) // Call the method to update the segment
                                if let scrollView = segmentServiceVC.view.subviews.compactMap({ $0 as? UIScrollView }).first {
                                    scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                                }
                                let toast = ToastView(text: uploadResponse.detail.message)
                                toast.show(in: segmentServiceVC.view, duration: 3.0)
                            }
                            print("Status: \(uploadResponse.detail.status)")
                            print("Message: \(uploadResponse.detail.message)")
                        } else {
                            let toast = ToastView(text: uploadResponse.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                        let toast = ToastView(text: "Error")
                        toast.show(in: self.view, duration: 3.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    DispatchQueue.main.async {
                        var errorMessage = "An error occurred. Please try again later."
                        
                        // Check specific error types and provide more informative messages
                        if let apiError = error as? APIErrorFormat {
                            switch apiError {
                            case .networkError:
                                errorMessage = "Network error. Please check your internet connection."
                            case .invalidResponse:
                                errorMessage = "Invalid response from the server. Please try again."
                            }
                        }
                        
                        let toast = ToastView(text: error.localizedDescription)
                        toast.show(in: self.view, duration: 3.0)
                    }
                }
            }
        }

         }
   
    @IBAction func cancelButton(_ sender: Any) {
        
        selectedButton = 1
        clearFileInformation(for: 1)
        resetUI(for: 1)
        
    }
    
    @IBAction func clearanceCancelButtonTapped(_ sender: Any) {
        
        selectedButton = 5
        clearFileInformation(for: 5)
        resetUI(for: 5)
    }
    @IBAction func clearanceUploadButtonClicked(_ sender: Any) {
        selectedButton = 5
        pickAndDisplayFile()
    }
    
    @IBAction func UploadButtonClicked(_ sender: Any) {
        selectedButton = 1
        pickAndDisplayFile()    }
    
    @IBAction func promotionUploadButtonClicked(_ sender: Any) {
        selectedButton = 2
        pickAndDisplayFile()
    }
    @IBAction func idcardUploadButtonClicked(_ sender: Any) {
        selectedButton = 3
        pickAndDisplayFile()
    }
    
    @IBAction func passportUploadButtonClicked(_ sender: Any) {
        selectedButton = 4
        pickImageFromGallery()
    }
    
    
    func pickImageFromGallery() {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = false
        present(imagePicker, animated: true, completion: nil)
    }
    @IBAction func idCardCancellButtonTapped(_ sender: Any) {
        selectedButton = 3
        clearFileInformation(for: 3)
        resetUI(for: 3)
        
        
    }
    @IBAction func photoCncelButtonTapped(_ sender: Any) {
        selectedButton = 4
        clearFileInformation(for: 4)
        resetUI(for: 4)
    }
    
    @IBAction func promotionClearButtonClicked(_ sender: Any) {
        selectedButton = 2
        clearFileInformation(for: 2)
        resetUI(for: 2)
        
    }
    func clearFileInformation(for button: Int) {
        let userDefaults = UserDefaults.standard
        
        switch button {
        case 1:
            userDefaults.removeObject(forKey: "selectedFileURL")
            userDefaults.removeObject(forKey: "fileDataVal1")
        case 2:
            userDefaults.removeObject(forKey: "selectedFileURL2")
            userDefaults.removeObject(forKey: "fileDataVal2")
        case 3:
            userDefaults.removeObject(forKey: "selectedFileURL3")
            userDefaults.removeObject(forKey: "fileDataVal3")
        case 4:
            userDefaults.removeObject(forKey: "selectedFileURL4")
            userDefaults.removeObject(forKey: "fileDataVal4")
        case 5:
            userDefaults.removeObject(forKey: "selectedFileURL5")
            userDefaults.removeObject(forKey: "fileDataVal5")
        default:
            break
        }
    }
    
    
    func resetUI(for button: Int) {
        switch button {
        case 1:
            uploadApplicationButton.isHidden = true
            selectedFileLabel.text = ""
            percentageLabel.text = ""
            percentageLabel.isHidden = true
            progressBar.isHidden = true
            uploadCancelButton.isHidden = true
            viewHeight.constant -= 90
        case 2:
            promotionLetterViewButton.isHidden = true
            promotionLetterFileLabel.text = ""
            PromotionLetterPercentageLabel.text = ""
            PromotionLetterPercentageLabel.isHidden = true
            promotionLetterProgressBar.isHidden = true
            promotionCancelButton.isHidden = true
            promotionLetterViewHeight.constant -= 90
        case 3:
            idCardViewButton.isHidden = true
            idCardFileLabel.text = ""
            idCardPercentageLabel.text = ""
            idCardPercentageLabel.isHidden = true
            idCardProgressBar.isHidden = true
            idCardCancelButton.isHidden = true
            idCardViewHeight.constant -= 90
        case 4:
            passportPhotoViewButton.isHidden = true
            photoFileLabel.text = ""
            photoPercentageLabel.text = ""
            photoPercentageLabel.isHidden = true
            photoProgressBar.isHidden = true
            passportCancelButton.isHidden = true
            photoViewHeight.constant -= 90
        case 5:
            clearanceViewButton.isHidden = true
            clearanceFileLabel.text = ""
            clearancePercentageLabel.text = ""
            clearancePercentageLabel.isHidden = true
            clearanceProgressBar.isHidden = true
            clearanceCancelButton.isHidden = true
            clearanceViewHeight.constant -= 90
        default:
            break
        }
        
        UIView.animate(withDuration: 0) {
            self.view.layoutIfNeeded()
        }
    }
    
    func pickAndDisplayFile() {
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["com.adobe.pdf"], in: .import)
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
    }
    
    /*  func pickAndDisplayFile() {
     let alertController = UIAlertController(title: "Select File Type", message: nil, preferredStyle: .actionSheet)
     
     let pdfAction = UIAlertAction(title: "Upload File", style: .default) { _ in
     let documentPicker = UIDocumentPickerViewController(documentTypes: ["com.adobe.pdf"], in: .import)
     documentPicker.delegate = self
     self.present(documentPicker, animated: true, completion: nil)
     }
     
     //        let galleryAction = UIAlertAction(title: "Gallery", style: .default) { _ in
     //            self.pickImageFromGallery()
     //        }
     
     let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
     
     alertController.addAction(pdfAction)
     //alertController.addAction(galleryAction)
     alertController.addAction(cancelAction)
     
     present(alertController, animated: true, completion: nil)
     }*/
    
    
    func updateProgressBar(progress: Float) {
        switch selectedButton {
        case 1:
            progressBar.progress = progress
        case 2:
            promotionLetterProgressBar.progress = progress
        case 3:
            idCardProgressBar.progress = progress
        case 4:
            photoProgressBar.progress = progress
        case 5 :
            clearanceProgressBar.progress = progress
        default:
            break
        }
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        switch selectedButton {
        case 1:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal1 = fileData // Store the loaded file data
            
            // Update UI elements
            selectedFileLabel.text = selectedURL.lastPathComponent
            viewHeight.constant = 200
            selectedFileLabel.isHidden = false
            percentageLabel.isHidden = false
            progressBar.isHidden = false
            uploadCancelButton.isHidden = false
            
            var progress: Float = 0
            
            // Start a timer to simulate upload progress
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    progressBar.progress = min(1, progress)
                    percentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        let fileSize = fileData.length
                        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                        percentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        
                        // Optionally, hide the progress bar or show a completion message
                        progressBar.isHidden = true
                        uploadApplicationButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
        case 2:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL2 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal2 = fileData
            
            promotionLetterFileLabel.text = selectedURL.lastPathComponent
            self.promotionLetterViewHeight.constant = 200
            self.promotionLetterFileLabel.isHidden = false
            self.PromotionLetterPercentageLabel.isHidden = false
            self.promotionLetterProgressBar.isHidden = false
            self.promotionCancelButton.isHidden = false
            
            var progress: Float = 0
            
            // Start a timer to simulate upload progress
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.promotionLetterProgressBar.progress = min(1, progress)
                    self.PromotionLetterPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        let fileSize = fileData.length
                        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                        self.PromotionLetterPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.promotionLetterProgressBar.isHidden = true
                        promotionLetterViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
        case 3:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL3 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal3 = fileData
            
            
            idCardFileLabel.text = selectedURL.lastPathComponent
            
            self.idCardViewHeight.constant = 200
            self.idCardFileLabel.isHidden = false
            self.idCardPercentageLabel.isHidden = false
            self.idCardProgressBar.isHidden = false
            self.idCardCancelButton.isHidden = false
            
            var progress: Float = 0
            
            // Start a timer to simulate upload progress
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.idCardProgressBar.progress = min(1, progress)
                    self.idCardPercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        let fileSize = fileData.length
                        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                        self.idCardPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.idCardProgressBar.isHidden = true
                        idCardViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
            
            /*  case 4:
             guard let fileURL = urls.first else { return }
             print("import result : \(fileURL)")
             fileDataVal4 = NSData(contentsOf: fileURL)
             photoFileLabel.text = "\(fileURL.lastPathComponent)"
             
             self.photoViewHeight.constant = 200
             self.photoFileLabel.isHidden = false
             self.photoPercentageLabel.isHidden = false
             self.photoProgressBar.isHidden = false
             self.passportCancelButton.isHidden = false
             var progress: Float = 0
             let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
             DispatchQueue.main.async {
             // Update progress bar and label
             progress += 0.1
             self.photoProgressBar.progress = min(1, progress)
             self.photoPercentageLabel.text = "\(Int(progress * 100))% uploading"
             
             if progress >= 1 {
             timer.invalidate()
             // Upload completed, perform any additional actions here
             }
             }
             }
             
             uploadTimer.fire()*/
            
        case 5:
            guard let selectedURL = urls.first else {
                print("No document selected")
                return
            }
            
            print("Selected document URL: \(selectedURL)")
            selectedFileURL5 = selectedURL // Store the selected file URL
            
            // Load file data from the selected URL
            guard let fileData = NSData(contentsOf: selectedURL) else {
                print("Failed to load file data")
                return
            }
            
            fileDataVal5 = fileData
            
            clearanceFileLabel.text = selectedURL.lastPathComponent
            
            self.clearanceViewHeight.constant = 200
            self.clearanceFileLabel.isHidden = false
            self.clearancePercentageLabel.isHidden = false
            self.clearanceProgressBar.isHidden = false
            self.clearanceCancelButton.isHidden = false
            
            var progress: Float = 0
            
            // Start a timer to simulate upload progress
            let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                DispatchQueue.main.async { [self] in
                    // Update progress bar and label
                    progress += 0.1
                    self.clearanceProgressBar.progress = min(1, progress)
                    self.clearancePercentageLabel.text = "\(Int(progress * 100))% uploading"
                    
                    if progress >= 1 {
                        timer.invalidate()
                        
                        // Upload completed, show file size on progress bar
                        let fileSize = fileData.length
                        let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                        self.clearancePercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                        
                        // Optionally, hide the progress bar or show a completion message
                        self.clearanceProgressBar.isHidden = true
                        clearanceViewButton.isHidden = false
                    }
                }
            }
            
            uploadTimer.fire()
            
        default:
            break
        }
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        // Handle cancellation if needed
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[.originalImage] as? UIImage {
            // Handle case for passport photo upload button
            
            switch selectedButton {
            case 4:
                if let selectedImage = info[.originalImage] as? UIImage {
                    guard let imageURL = info[.imageURL] as? URL else {
                        print("No image URL found")
                        return
                    }
                    
                    selectedFileURL4 = imageURL
                    
                    let fileName = imageURL.lastPathComponent
                    
                    guard let data = selectedImage.jpegData(compressionQuality: 1.0) else {
                        print("Failed to convert image to JPEG")
                        return
                    }
                    
                    let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    let destinationURL = documentsURL.appendingPathComponent(fileName)
                    
                    do {
                        try data.write(to: destinationURL)
                        print("Image URL: \(destinationURL)")
                        fileDataVal4 = data as NSData
                        
                        photoFileLabel.text = fileName
                        photoViewHeight.constant = 200
                        photoFileLabel.isHidden = false
                        photoPercentageLabel.isHidden = false
                        photoProgressBar.isHidden = false
                        passportCancelButton.isHidden = false
                        
                        var progress: Float = 0
                        let uploadTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
                            DispatchQueue.main.async { [self] in
                                progress += 0.1
                                self.photoProgressBar.progress = min(1, progress)
                                self.photoPercentageLabel.text = "\(Int(progress * 100))% uploading"
                                
                                if progress >= 1 {
                                    timer.invalidate()
                                    let fileSize = data.count
                                    let fileSizeInMB = Double(fileSize) / (1024 * 1024)
                                    self.photoPercentageLabel.text = String(format: "%.2f MB", fileSizeInMB)
                                    self.photoProgressBar.isHidden = true
                                    passportPhotoViewButton.isHidden = false
                                }
                            }
                        }
                        uploadTimer.fire()
                    } catch {
                        print("Error saving image: \(error)")
                    }
                }
            default:
                break
            }
            
            // Dismiss the image picker
            dismiss(animated: true, completion: nil)
        }
        
        // Dismiss the image picker
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
