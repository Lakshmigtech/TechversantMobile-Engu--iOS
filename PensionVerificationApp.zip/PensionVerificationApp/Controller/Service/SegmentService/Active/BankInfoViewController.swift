//
//  BankInfoViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit


class BankInfoViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate{
    
    @IBOutlet weak var bankTableView: UITableView!
    @IBOutlet weak var accountTypeTableView: UITableView!
    @IBOutlet weak var accountTypeView: UIView!
    @IBOutlet weak var banklistView: UIView!
    @IBOutlet weak var selectBankTextfield: UITextField!
    @IBOutlet weak var selectBankLogoImageView: UIImageView!
    @IBOutlet weak var selectAccounttypeTextField: UITextField!
    @IBOutlet weak var checkBoxButton: UIButton!
    
    @IBOutlet weak var accountNumberTextField: UITextField!
    @IBOutlet weak var reEnterAccountNumberTextField: UITextField!
    @IBOutlet weak var accountHolderNameTextField: UITextField!
    @IBOutlet weak var swiftCodeTextField: UITextField!
    @IBOutlet weak var bankCodeTextField: UITextField!
    @IBOutlet weak var acccountTypeTextField: UITextField!
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var verifyLabel: UILabel!
    @IBOutlet weak var verifyImage: UIImageView!
    @IBOutlet weak var verifyWidth: NSLayoutConstraint!
    
    var accountHolderName: String = ""
    var isVerificationSuccessful = false

    var selectedBankId: Int?
    var isToggled = false
    var accountList: [AccountType] = []
    var bankList: [Bank] = []
    var swiftCode: [SwiftCodeResponse] = []
    var isFirstButtonClick = true
    var isFirstButtonClicks = true
    
    var typingTimer: Timer?
    


    override func viewDidLoad() {
        super.viewDidLoad()
        selectBankTextfield.delegate = self
        selectAccounttypeTextField.delegate = self
        accountNumberTextField.delegate = self
        reEnterAccountNumberTextField.delegate = self
        accountHolderNameTextField.delegate = self
        swiftCodeTextField.delegate = self
        bankCodeTextField.delegate = self
        acccountTypeTextField.delegate = self
        swiftCodeTextField.delegate = self

        checkBoxButton.setImage(UIImage(systemName: "square"), for: .normal)
        checkBoxButton.tintColor = .systemGreen
        nextButton.isEnabled = false
        banklistView.isHidden = true
        bankTableView.delegate = self
        bankTableView.dataSource = self
        accountTypeView.isHidden = true
        accountTypeTableView.delegate = self
        accountTypeTableView.dataSource = self
        swiftCodeTextField.delegate  = self
        bankTableView.dataSource = self
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
        accountNumberTextField.delegate = self
        accountHolderNameTextField.delegate = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateVerifyLabel), name: NSNotification.Name("VerificationStatusChanged"), object: nil)
        addTapGestures(to: accountNumberTextField)
        
        addTapGestures(to: reEnterAccountNumberTextField)
        
        addTapGestures(to: accountHolderNameTextField)
        
        // Add gestures to phoneNumberTextField
        addTapGestures(to: swiftCodeTextField)
       
        
    }
    // UITextFieldDelegate method called when editing finishes
        func textFieldDidEndEditing(_ textField: UITextField) {
            // Check if the user finished editing the re-enter account number field
            if textField == reEnterAccountNumberTextField {
                checkAccountNumbers()
            }
        }
    // Function to check if the account numbers match
        func checkAccountNumbers() {
            let accountNumber = accountNumberTextField.text
            let reEnterAccountNumber = reEnterAccountNumberTextField.text
            
            // Ensure both fields are filled
            if accountNumber?.isEmpty == false && reEnterAccountNumber?.isEmpty == false {
                // Compare account numbers
                if accountNumber == reEnterAccountNumber {
                    // If they match
                    //showAlert(message: "Account numbers match!")
                } else {
                    // If they do not match
                    showAlert(message: "Account numbers do not match. Please try again.")
                }
            } else {
                // If either field is empty
                showAlert(message: "Please enter both account numbers.")
            }
        }
        
        // Function to show an alert
        func showAlert(message: String) {
            let alertController = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(okAction)
            present(alertController, animated: true, completion: nil)
        }
    
    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
    deinit {
            NotificationCenter.default.removeObserver(self)
           }
    @objc func updateVerifyLabel() {
            let verificationStatus = UserDefaults.standard.bool(forKey: "verificationStatus")
            let verificationStatusDetail = UserDefaults.standard.string(forKey: "verificationStatusDetail")
            
            if let verificationStatusDetail = verificationStatusDetail {
                if verificationStatus && verificationStatusDetail == "success" {
                    verifyLabel.text = "VERIFIED"
                    verifyLabel.textColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0) // Custom green color
                    verifyImage.image = UIImage(named: "tick") // Set your success image here
                    isVerificationSuccessful = true
                    verifyWidth.constant = 70
                    verifyImage.isHidden = false
                
                } else {
                    verifyLabel.text = "REVERIFY"
                    verifyLabel.textColor = .red
                    isVerificationSuccessful = false
                    verifyImage.isHidden = true
                    verifyWidth.constant = 110
                }
           
          }
        }
    @IBAction func verifyButtonAction(_ sender: Any) {
        // Update the verify label based on the saved verification status
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in
            updateVerifyLabel()
        }
        
            let storyboard = UIStoryboard(name: Storyboards.Services, bundle: nil)
            if let verifyAccountVC = storyboard.instantiateViewController(withIdentifier: "VerifyAccountViewController") as? VerifyAccountViewController {
                verifyAccountVC.accountNumber = accountNumberTextField.text
                verifyAccountVC.bankCode = bankCodeTextField.text
                
                // Present the VerifyAccountViewController as a popup (modal)
                verifyAccountVC.modalPresentationStyle = .overCurrentContext
                present(verifyAccountVC, animated: true, completion: nil)
            }
        }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Set the account holder name to the text field
        accountHolderNameTextField.text = accountHolderName
        
        
        
    }
    
    
   /* func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Define the allowed characters for swiftCodeTextField (A-Z and 0-9)
        let swiftCodeAllowedCharacters = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
        
        // Define the allowed characters for accountHolderNameTextField (letters only)
        let nameAllowedCharacters = CharacterSet.letters
        
        switch textField {
        case accountHolderNameTextField:
            // Check if the replacement string contains only alphabetic characters
            if string.rangeOfCharacter(from: nameAllowedCharacters.inverted) != nil && !string.isEmpty {
                showAlert(title: "Error", message: "Please enter only alphabetic characters.")
                return false
            }
            
        case swiftCodeTextField:
            // Concatenate the new string with the existing text
            let newText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? string
            
            // Check if the replacement string contains only allowed characters (A-Z and 0-9)
            if string.rangeOfCharacter(from: swiftCodeAllowedCharacters.inverted) != nil {
                showAlert(title: "Error", message: "Swift code can only contain uppercase letters and digits.")
                return false
            }
            
            // Check for whitespace in the new string
            if newText.rangeOfCharacter(from: .whitespaces) != nil {
                showAlert(title: "Error", message: "Swift code cannot contain spaces.")
                return false
            }
            
            // Perform API call with newText
            fetchBankCode(for: newText)
            
        default:
            return true
        }
        
        return true
    }*/
   
    
        

        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            // Define the allowed characters for swiftCodeTextField (A-Z and 0-9)
            let swiftCodeAllowedCharacters = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
            
            // Define the allowed characters for accountHolderNameTextField (letters only)
            let nameAllowedCharacters = CharacterSet.letters
            
            switch textField {
            case accountHolderNameTextField:
                // Check if the replacement string contains only alphabetic characters
                if string.rangeOfCharacter(from: nameAllowedCharacters.inverted) != nil && !string.isEmpty {
                    showAlert(title: "Error", message: "Please enter only alphabetic characters.")
                    return false
                }
            
            case swiftCodeTextField:
                // Concatenate the new string with the existing text
                let newText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? string
                
                // Check if the replacement string contains only allowed characters (A-Z and 0-9)
                if string.rangeOfCharacter(from: swiftCodeAllowedCharacters.inverted) != nil {
                    showAlert(title: "Error", message: "Swift code can only contain uppercase letters and digits.")
                    return false
                }
                
                // Check for whitespace in the new string
                if newText.rangeOfCharacter(from: .whitespaces) != nil {
                    showAlert(title: "Error", message: "Swift code cannot contain spaces.")
                    return false
                }

                // Restart the timer whenever the user types
                resetTypingTimer(with: newText)

            default:
                return true
            }
            
            return true
        }
        
        private func resetTypingTimer(with swiftCode: String) {
            // Invalidate the previous timer
            typingTimer?.invalidate()
            
            // Create a new timer that calls fetchBankCode after 3 seconds of inactivity
            typingTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { [weak self] _ in
                self?.fetchBankCode(for: swiftCode)
            }
        }

        
    
    
    
    
    
    
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    func isValidAccountNumber(_ accountNumber: String) -> Bool {
        // Check for 10 to 12 digits
        guard (10...12).contains(accountNumber.count) else {
            return false
        }
        
        // Your other validation logic
        // ...
        
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField == accountNumberTextField {
            // Check if the account number text field is the one being edited
            guard let accountNumber = textField.text else {
                return true
            }
            
            var errorMessages: [String] = []
            
            // Check for 10 to 12-digit validation
            if !(10...12).contains(accountNumber.count) {
                errorMessages.append("Account number should contain between 10 and 12 digits.")
            }
            
            // Your other validation logic
            // ...
            
            if !isValidAccountNumber(accountNumber) {
                showAlert(messages: errorMessages)
                return false
            }
        }
        return true
    }
    
    func containsConsecutiveNumbers(_ accountNumber: String) -> Bool {
        let consecutiveNumbers = ["12345678", "23456789"]
        return consecutiveNumbers.contains { accountNumber.contains($0) }
    }
    
    func showAlert(messages: [String]) {
        for message in messages {
            let alert = UIAlertController(title: "Validation Error", message: message, preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == accountNumberTextField {
            reEnterAccountNumberTextField.becomeFirstResponder() // Make the nextTextField active
        } else {
            textField.resignFirstResponder()
        }
        return true
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        // Get the location of the tap
        let location = sender.location(in: view)
        
        // Check if the tap is inside any of the views
        if !banklistView.frame.contains(location) && !accountTypeView.frame.contains(location)  {
            // Hide all views
            banklistView.isHidden = true
            
            accountTypeView.isHidden = true
        }
    }
    func fetchBankCode(for swiftCode: String) {
        guard !swiftCode.isEmpty else {
            alert(message: "Please enter SwiftCode", title: "Mandatory Field")
            return
        }
        
        APIManager().perform(SwiftCode(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: SwiftCode.Body(swift_code: swiftCode))) { result in
            self.hideHUD()
            
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    // Directly assign swiftCodeResponse
                    self.swiftCode = [data.detail.swiftCodeResponse] // Assuming swiftCode is an array
                    
                    // Extract bank code from the swiftCodeResponse and update the bankCodeTextField
                    let bankCode = data.detail.swiftCodeResponse.bankCode // Assuming bankCode is not optional
                    DispatchQueue.main.async {
                        self.bankCodeTextField.text = bankCode
                    }
                }
                else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        self.alert(message: data.detail.message, title: "Failed")
                    }
                    else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                        
                    }
                    else if data.detail.tokenStatus == "Invalid"{
                        self.alert(message: data.detail.message, title: "Failed")
                        
                    }
                    else {
                        self.alert(message: "Failed to refresh token", title: "Session Expired")
                    }
                }
                
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    
                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == bankTableView{
            return bankList.count
        }
        else if tableView == accountTypeTableView{
            return accountList.count
        }
        
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == bankTableView{
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? BanksTableViewCell
            
            // Configure the cell with data from the bankList array
            let bank = bankList[indexPath.row]
            
            cell?.textLabel?.text = bank.name
            // Assuming 'name' is a property in BankListResponse
            if let logoURL = URL(string: bank.logo) {
                // Load the image asynchronously
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: logoURL),
                       let image = UIImage(data: imageData) {
                        // Update the UI on the main thread
                        DispatchQueue.main.async {
                            cell?.imageView?.image = image
                            cell?.setNeedsLayout()  // Refresh the layout to display the new image
                        }
                    }
                }
            }
            return cell!
        }
        else if tableView == accountTypeTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? AccountsTableViewCell
            
            let accountType = accountList[indexPath.row]
            cell?.textLabel?.text = accountType.type
            return cell!
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        banklistView.isHidden = true
        isToggled = false
        if tableView == bankTableView{
            
            let selectedBank = bankList[indexPath.row]
            selectBankTextfield.text = selectedBank.name
            selectedBankId = selectedBank.id
            // Optionally, you can dismiss the table view or perform any other actions
            tableView.deselectRow(at: indexPath, animated: true)
            // Load the logo image asynchronously
            if let logoURL = URL(string: selectedBank.logo) {
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: logoURL),
                       let image = UIImage(data: imageData) {
                        // Update the UI on the main thread
                        DispatchQueue.main.async {
                            self.selectBankLogoImageView.image = image
                        }
                    }
                }
            }
            banklistView.isHidden = true
            isToggled = false
        }
        else if tableView == accountTypeTableView{
            let selectedAccount = accountList[indexPath.row]
            selectAccounttypeTextField.text = selectedAccount.type
            accountTypeView.isHidden = true
            tableView.deselectRow(at: indexPath, animated: true)
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    func fetchBankList() {
        APIManager().perform(BankList(bearerToken: UserDefaults.standard.accessToken)) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    self.bankList = data.detail.banks
                    self.accountList = data.detail.accountType
                    DispatchQueue.main.async {
                        self.bankTableView.reloadData()
                        self.accountTypeTableView.reloadData()
                    }
                } else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        self.alert(message: data.detail.message, title: "Failed")
                    }
                    else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                        
                    }
                    else if data.detail.tokenStatus == "Invalid"{
                        self.alert(message: data.detail.message, title: "Failed")
                        
                    }
                    else {
                        self.alert(message: "Failed to refresh token", title: "Session Expired")
                    }
                }
            case .failure(let error):
                print("Error:", error)
                DispatchQueue.main.async {
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            self.alert(message: "Network error. Please check your internet connection.", title: "Error")
                        case .invalidResponse:
                            self.alert(message: "Invalid response from the server. Please try again.", title: "Error")
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func selectBankDropdownButton(_ sender: Any) {
        if isFirstButtonClick {
            showHUD(message: "")
            isFirstButtonClick = false
        }
        isToggled.toggle()
        
        if isToggled {
            banklistView.isHidden = false
            fetchBankList()
        } else {
            banklistView.isHidden = true
        }
    }
    @IBAction func selectAccounttypeDropdownButton(_ sender: Any) {
        isToggled.toggle()
        
        if isToggled {
            accountTypeView.isHidden = false
            
        } else {
            accountTypeView.isHidden = true
        }
    }
    @IBAction func checkBoxClicked(_ sender: Any) {
        checkBoxButton.isSelected = !checkBoxButton.isSelected
        
        if checkBoxButton.isSelected {
            checkBoxButton.setImage(UIImage(systemName: "checkmark.square"), for: .normal)
            checkBoxButton.tintColor = .systemGreen
            nextButton.isEnabled = true
            nextButton.alpha = 1.0
            
        } else {
            checkBoxButton.setImage(UIImage(systemName: "square"), for: .normal)
            checkBoxButton.tintColor = .systemGreen
            nextButton.isEnabled = false
            nextButton.alpha = 0.5
        }
    }
    @IBAction func nextButton(_ sender: Any) {
        if isVerificationSuccessful {
                fetchBankDetails() // Call your API to fetch bank details
            } else {
                // Show an alert or handle the case where verification is not successful
                showAlert(title: "Error", message: "Verification is required before proceeding.")
            }
    }
    
    func fetchBankDetails(){
        guard let accountNumber = accountNumberTextField.text, !accountNumber.isEmpty, accountNumber.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil else {
            alert(message: "Please enter a valid Account Number", title: "Invalid Input")
            return
        }
        // Validate re-entered account number: Check if it matches the account number
        guard let reEnterAccountNumber = reEnterAccountNumberTextField.text, !reEnterAccountNumber.isEmpty, reEnterAccountNumber == accountNumber else {
            alert(message: "Re-entered Account Number does not match", title: "Invalid Input")
            return
        }
        // Validate account holder name: Check if it contains only letters and spaces, and is not empty
        guard let holderName = accountHolderNameTextField.text, !holderName.isEmpty, holderName.rangeOfCharacter(from: CharacterSet.letters.union(CharacterSet(charactersIn: " ")).inverted) == nil else {
            alert(message: "Please enter a valid Account Holder Name", title: "Invalid Input")
            return
        }
        
        guard let accountsType = acccountTypeTextField.text, !accountsType.isEmpty else {
            alert(message: "Please enter Account Type", title: "Mandatory Field")
            return
        }
        guard let bankCode = bankCodeTextField.text, !bankCode.isEmpty else {
            alert(message: "Please enter Bank Code", title: "Mandatory Field")
            return
        }
        guard let swiftCode = swiftCodeTextField.text, !swiftCode.isEmpty else {
            alert(message: "Please enter Swift Code", title: "Mandatory Field")
            return
        }
        guard let selectedBankId = selectedBankId else {
            return
        }
        let autoRenewal = checkBoxButton.isSelected
        
        self.showHUD(message: "")
        APIManager().perform(BankDetails(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: BankDetails.Body(bank_id: String(selectedBankId), account_number: accountNumber, re_enter_account_number: reEnterAccountNumber, account_holder_name: holderName, account_type: accountsType,swift_code: swiftCode,bank_code:bankCode, auto_renewal: autoRenewal))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                // Check if the detail message matches the success message
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                     
                        // Show toast message
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: self.view, duration: 3.0)
                        
                        let storedUserId = UserDefaults.standard.userId
                        print("Stored User ID: \(storedUserId)")

                        // Navigate to DashBoardViewController after the toast is shown
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay 
                            let popup = UIStoryboard(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "EINSaveViewController") as! EINSaveViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                         
                        }
                    }
                }
                else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)}
                    } else if data.detail.tokenStatus == "expired" {
                        DispatchQueue.main.async {                        self.callRefreshToken()}
                    } else if data.detail.tokenStatus == "Invalid" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)}
                    } else {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: "Failed to refresh token")
                            toast.show(in: self.view, duration: 3.0)}
                    }
                } else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
                
            case .failure(let error):
                // Handle API call failure
                DispatchQueue.main.async {
                    let toast = ToastView(text: error.localizedDescription)
                    toast.show(in: self.view, duration: 3.0)      }      }
        }    }
    
    
   /*     guard let accountNumber = accountNumberTextField.text, !accountNumber.isEmpty, accountNumber.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil else {
            alert(message: "Please enter a valid Account Number", title: "Invalid Input")
            return
        }
        guard let reEnterAccountNumber = reEnterAccountNumberTextField.text, !reEnterAccountNumber.isEmpty, reEnterAccountNumber == accountNumber else {
            alert(message: "Re-entered Account Number does not match", title: "Invalid Input")
            return
        }
        guard let holderName = accountHolderNameTextField.text, !holderName.isEmpty, holderName.rangeOfCharacter(from: CharacterSet.letters.union(CharacterSet(charactersIn: " ")).inverted) == nil else {
            alert(message: "Please enter a valid Account Holder Name", title: "Invalid Input")
            return
        }
        guard let accountsType = acccountTypeTextField.text, !accountsType.isEmpty else {
            alert(message: "Please enter Account Type", title: "Mandatory Field")
            return
        }
        guard let bankCode = bankCodeTextField.text, !bankCode.isEmpty else {
            alert(message: "Please enter Bank Code", title: "Mandatory Field")
            return
        }
        guard let swiftCode = swiftCodeTextField.text, !swiftCode.isEmpty else {
            alert(message: "Please enter Swift Code", title: "Mandatory Field")
            return
        }
        guard let selectedBankId = selectedBankId else {
            return
        }
        let autoRenewal = checkBoxButton.isSelected

        self.showHUD(message: "")
        let performBankDetailsAPI = {
            APIManager().perform(BankDetails(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: BankDetails.Body(bank_id: String(selectedBankId), account_number: accountNumber, re_enter_account_number: reEnterAccountNumber, account_holder_name: holderName, account_type: accountsType, swift_code: swiftCode, bank_code: bankCode, auto_renewal: autoRenewal))) { result in
                self.hideHUD()
                switch result {
                case .success(let data):
                    if data.detail.status == "success" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                let popup = UIStoryboard(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "EINSaveViewController") as! EINSaveViewController
                                self.addChild(popup)
                                popup.view.frame = self.view.frame
                                self.view.addSubview(popup.view)
                                popup.didMove(toParent: self)
                                popup.modalPresentationStyle = .overCurrentContext
                            }
                        }
                    } else if data.detail.status == "fail" {
                        if data.detail.tokenStatus == "valid" {
                            DispatchQueue.main.async {
                                let toast = ToastView(text: data.detail.message)
                                toast.show(in: self.view, duration: 3.0)
                            }
                        } else if data.detail.tokenStatus == "expired" {
                            self.callRefreshToken { success in
                                if success {
                                    self.fetchBankDetails()  // Retry with new token
                                } else {
                                    let toast = ToastView(text: "Token refresh failed")
                                    toast.show(in: self.view, duration: 3.0)
                                }
                            }
                        } else {
                            let toast = ToastView(text: "Failed to refresh token")
                            toast.show(in: self.view, duration: 3.0)
                        }
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        let toast = ToastView(text: error.localizedDescription)
                        toast.show(in: self.view, duration: 3.0)
                    }
                }
            }
        }
        performBankDetailsAPI()
    }*/
    
    
    
    
    
    
}

