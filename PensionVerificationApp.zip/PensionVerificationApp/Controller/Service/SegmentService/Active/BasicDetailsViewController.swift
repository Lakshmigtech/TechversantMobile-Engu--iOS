//
//  BasicDetailsViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 01/11/23.
//

import UIKit

protocol BasicDetailsKeyboardDelegate: AnyObject {
    func keyboardWillShow(notification: NSNotification)
    func keyboardWillHide(notification: NSNotification)
}

class BasicDetailsViewController: UIViewController, UIDocumentPickerDelegate,UITableViewDelegate,UITableViewDataSource ,UITextFieldDelegate {
    
    weak var keyboardDelegate: BasicDetailsKeyboardDelegate?
    


    @IBOutlet weak var userPincode: UITextField!
    @IBOutlet weak var kinPincode: UITextField!
    @IBOutlet weak var occupationView: UIView!
    @IBOutlet weak var occupationTableView: UITableView!
    @IBOutlet weak var occupationTextField: UITextField!
    @IBOutlet weak var dobTextField:
    UITextField!
    
    @IBOutlet weak var dateOfAppointmentTextField: UITextField!
    @IBOutlet weak var lgaView: UIView!
    @IBOutlet weak var lgaTableView: UITableView!
    @IBOutlet weak var subtreasuryView: UIView!
    @IBOutlet weak var subtreasuryTableView: UITableView!
    @IBOutlet weak var gradeLevelView: UIView!
    @IBOutlet weak var gradeLevelTableView: UITableView!
    @IBOutlet weak var countryTextField: UITextField!
    @IBOutlet weak var femaleButton: UIButton!
    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var lgaTextField: UITextField!
    @IBOutlet weak var subtreasuryTextField: UITextField!
    @IBOutlet weak var gradeLevelTextField: UITextField!
    
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var middleNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var nameofNextofKInTextField: UITextField!
    @IBOutlet weak var nextofKinEmailAddressTextField: UITextField!
    @IBOutlet weak var nextofKInPhoneTextField: UITextField!
    @IBOutlet weak var nextofKinAddressTextField: UITextField!
    
    @IBOutlet weak var countryButton: UIButton!
    @IBOutlet weak var lgaButton: UIButton!
    @IBOutlet weak var subtreasuryButton: UIButton!
    @IBOutlet weak var lastGradeButton: UIButton!
    @IBOutlet weak var occupationButton: UIButton!
    @IBOutlet weak var maleLabel: UILabel!
    @IBOutlet weak var femaleLabel: UILabel!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var buttonView: UIView!
    

    var countriesViewController = CountriesViewController()
    var countryName: String?
    var isToggled = false
    var lga: [Lgas] = []
    var subtreasury: [Lgas] = []
    var gradeLvl:[GradeLevel] = []
    var occupation: [Occupation] = []
    var selectedLgaId: Int?
    var selectedSubtreasuryId: Int?
    var selectedGradeLevelId: Int?
    var selectedOccupationId: Int?
    
    var selectedSex: String?
    var isMaleSelected = false
    var isFemaleSelected = false
    var buttonViews: [UIButton: UIView] = [:]
    var textFields: [UITextField] = []
    var buttons: [UIButton] = []
    weak var delegate: BasicDetailsDelegate?
    // Variable to store the dynamic initial text
    var initialText: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
        buttons = [countryButton, lgaButton, subtreasuryButton, lastGradeButton, occupationButton]
        // Add all text fields to the array
        textFields = [firstNameTextField,middleNameTextField, lastNameTextField, dobTextField, addressTextField,userPincode, countryTextField, lgaTextField, nameofNextofKInTextField,nextofKinEmailAddressTextField, nextofKInPhoneTextField, nextofKinAddressTextField,kinPincode, subtreasuryTextField, dateOfAppointmentTextField, gradeLevelTextField, occupationTextField]
        
        // Set delegate for text fields
        for textField in textFields {
            textField.delegate = self
        }
        // Assign the initial text from the text field (if it already contains any text)
        initialText = nextofKInPhoneTextField.text ?? ""
        subtreasuryTableView.allowsSelection = true
        lgaTableView.allowsSelection = true
        lgaTableView.delegate = self
        lgaTableView.dataSource = self
        lgaView.isHidden = true
        subtreasuryView.isHidden = true
        subtreasuryTableView.delegate = self
        subtreasuryTableView.dataSource = self
        gradeLevelView.isHidden = true
        gradeLevelTableView.delegate = self
        gradeLevelTableView.dataSource = self
        occupationView.isHidden = true
        occupationTableView.delegate = self
        occupationTableView.dataSource = self
        firstNameTextField.delegate = self
        middleNameTextField.delegate = self
        lastNameTextField.delegate = self
        nameofNextofKInTextField.delegate = self
        
        userPincode.delegate = self
        kinPincode.delegate = self
        nextofKInPhoneTextField.delegate = self
        
        nextofKInPhoneTextField.keyboardType = .numberPad  // Set the keyboard type to number pad
        nextofKInPhoneTextField.returnKeyType = .done  // Optionally set the return key type
        kinPincode.keyboardType = .numberPad
        kinPincode.returnKeyType = .done
        userPincode.keyboardType = .numberPad
        userPincode.returnKeyType = .done

        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        dobTextField.inputView = datePicker
        // Add a toolbar with a done button to dismiss the date picker
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonPressed))
        toolbar.setItems([doneButton], animated: false)
        dobTextField.inputAccessoryView = toolbar
        
        let appointmentDatePicker = UIDatePicker()
        appointmentDatePicker.datePickerMode = .date
        appointmentDatePicker.maximumDate = Date() // Only allow dates up to today
        dateOfAppointmentTextField.inputView = appointmentDatePicker
        
        // Add a toolbar with a done button to dismiss the date picker
        let appointmentToolbar = UIToolbar()
        appointmentToolbar.sizeToFit()
        let appointmentDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(AppointmentDoneButtonPressed))
        appointmentToolbar.setItems([appointmentDoneButton], animated: false)
        dateOfAppointmentTextField.inputAccessoryView = appointmentToolbar
        
        maleButton.setImage(UIImage(named: "deselect"), for: .normal)
        femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
        maleButton.isSelected = false
        femaleButton.isSelected = false
        initalSetup()
        setupCountryPicker()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
         fetchBasicDetailsRetrive()
        
        addTapGestures(to: userPincode)
        
        addTapGestures(to: kinPincode)
        
        addTapGestures(to: nameofNextofKInTextField)
        
        // Add gestures to phoneNumberTextField
        addTapGestures(to: nextofKinAddressTextField)
        
        addTapGestures(to: nextofKinEmailAddressTextField)
        
        // Add gestures to phoneNumberTextField
        addTapGestures(to: nextofKInPhoneTextField)
        
        addTapGestures(to: firstNameTextField)
        
        addTapGestures(to: middleNameTextField)
        
        addTapGestures(to: lastNameTextField)
        
        // Add gestures to phoneNumberTextField
        addTapGestures(to: addressTextField)
        
        
    }
   
   
    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
    
    
   /* func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
          // Check if the current text field should only accept alphabets
          let shouldAcceptAlphabets: Bool
          switch textField {
          case firstNameTextField, middleNameTextField, lastNameTextField, nameofNextofKInTextField:
              shouldAcceptAlphabets = true
          default:
              shouldAcceptAlphabets = false
          }
          
          // If the text field should only accept alphabets, check the input
          if shouldAcceptAlphabets {
              let allowedCharacters = CharacterSet.letters
              let characterSet = CharacterSet(charactersIn: string)
              let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
              
              if !isAlphabetic && !string.isEmpty {
                  // Show alert if a non-alphabetic character is entered
                  showAlert(message: "Please enter only alphabetic characters.")
                  return false
              }
          }
          
          // Check if the current text field should only accept numbers
          let shouldAcceptNumbers: Bool
          switch textField {
          case nextofKInPhoneTextField, kinPincode, userPincode:
              shouldAcceptNumbers = true
          default:
              shouldAcceptNumbers = false
          }
          
          // If the text field should only accept numbers, check the input
          if shouldAcceptNumbers {
              let allowedCharacters = CharacterSet.decimalDigits
              let characterSet = CharacterSet(charactersIn: string)
              let isNumeric = allowedCharacters.isSuperset(of: characterSet)
              
              if !isNumeric && !string.isEmpty {
                  // Show alert if a non-numeric character is entered
                  showAlert(message: "Please enter only numeric characters.")
                  return false
              }
          }
          
          return true
      }*/
   /* func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

           // Check if the current text field should only accept alphabets
           let shouldAcceptAlphabets: Bool
           switch textField {
           case firstNameTextField, middleNameTextField, lastNameTextField, nameofNextofKInTextField:
               shouldAcceptAlphabets = true
           default:
               shouldAcceptAlphabets = false
           }
           
           // If the text field should only accept alphabets, check the input
           if shouldAcceptAlphabets {
               let allowedCharacters = CharacterSet.letters
               let characterSet = CharacterSet(charactersIn: string)
               let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
               
               if !isAlphabetic && !string.isEmpty {
                   // Show alert if a non-alphabetic character is entered
                   showAlert(message: "Please enter only alphabetic characters.")
                   return false
               }
           }
           
           // Check if the current text field should only accept numbers
           let shouldAcceptNumbers: Bool
           switch textField {
           case nextofKInPhoneTextField, kinPincode, userPincode:
               shouldAcceptNumbers = true
           default:
               shouldAcceptNumbers = false
           }
           
           // If the text field should only accept numbers, check the input
           if shouldAcceptNumbers {
               let allowedCharacters = CharacterSet.decimalDigits
               let characterSet = CharacterSet(charactersIn: string)
               let isNumeric = allowedCharacters.isSuperset(of: characterSet)
               
               if !isNumeric && !string.isEmpty {
                   // Show alert if a non-numeric character is entered
                   showAlert(message: "Please enter only numeric characters.")
                   return false
               }
           }
           
           // If this is the nextofKInPhoneTextField, prevent backspace from deleting initial text
           if textField == nextofKInPhoneTextField {
               // Detect backspace (if the replacement string is empty)
               if string.isEmpty {
                   // Ensure backspace is only allowed after the initial text length
                   if range.location < initialText.count {
                       // Prevent deleting the initial text
                       return false
                   }
               }
           }
           
           return true
       }*/
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        // Check if the current text field should only accept alphabets
        let shouldAcceptAlphabets: Bool
        switch textField {
        case firstNameTextField, middleNameTextField, lastNameTextField, nameofNextofKInTextField:
            shouldAcceptAlphabets = true
        default:
            shouldAcceptAlphabets = false
        }
        
        // If the text field should only accept alphabets, check the input
        if shouldAcceptAlphabets {
            let allowedCharacters = CharacterSet.letters
            let characterSet = CharacterSet(charactersIn: string)
            let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
            
            if !isAlphabetic && !string.isEmpty {
                // Show alert if a non-alphabetic character is entered
                showAlert(message: "Please enter only alphabetic characters.")
                return false
            }
        }
        
        // Check if the current text field should only accept numbers
        let shouldAcceptNumbers: Bool
        switch textField {
        case nextofKInPhoneTextField, kinPincode, userPincode:
            shouldAcceptNumbers = true
        default:
            shouldAcceptNumbers = false
        }
        
        // If the text field should only accept numbers, check the input
        if shouldAcceptNumbers {
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            let isNumeric = allowedCharacters.isSuperset(of: characterSet)
            
            if !isNumeric && !string.isEmpty {
                // Show alert if a non-numeric character is entered
                showAlert(message: "Please enter only numeric characters.")
                return false
            }
            
            // Check if the text field is userPincode or kinPincode and limit to 6 digits
            if (textField == userPincode || textField == kinPincode) {
                let currentText = textField.text ?? ""
                let newLength = currentText.count + string.count - range.length
                if newLength > 6 {
                    return false
                }
            }
            // Check if the text field is nextofKInPhoneTextField and limit to 10 digits
                   if textField == nextofKInPhoneTextField {
                       let currentText = textField.text ?? ""
                       let newLength = currentText.count + string.count - range.length
                       if newLength > 14 {
                           return false
                       }
                   }
            
        }
        
        // If this is the nextofKInPhoneTextField, prevent backspace from deleting initial text
        if textField == nextofKInPhoneTextField {
            // Detect backspace (if the replacement string is empty)
            if string.isEmpty {
                // Ensure backspace is only allowed after the initial text length
                if range.location < initialText.count {
                    // Prevent deleting the initial text
                    return false
                }
            }
        }
        
        return true
    }

    
    
    
    

    func fetchBasicDetailsRetrive(){
        
        APIManager().perform(BasicDetailsRetrive(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            switch result {
            case .success(let data):
                if data.detail.status == "success", let userProfileDetails = data.detail.userProfileDetails {
                    DispatchQueue.main.async { [self] in
                        if data.detail.userProfileDetails?.firstName != nil{
                            self.firstNameTextField.text = userProfileDetails.firstName
                            self.middleNameTextField.text = userProfileDetails.middleName
                            self.lastNameTextField.text = userProfileDetails.lastName
                            self.dobTextField.text = userProfileDetails.dob
                            if let sex = data.detail.userProfileDetails?.sex {
                                switch sex {
                                case "male":
                                    maleButton.setImage(UIImage(named: "select"), for: .normal)
                                case "female":
                                    femaleButton.setImage(UIImage(named: "select"), for: .normal)
                                default:
                                    // Handle other cases if necessary
                                    break
                                }
                            }
                            // Disable the next button when data is successfully populated
                                            self.nextButton.isEnabled = false
                                            self.buttonView.alpha = 0.5 // Optional: Change appearance to indicate it's disabled
                            self.addressTextField.text = userProfileDetails.address
                            self.userPincode.text = userProfileDetails.pincode
                            self.countryTextField.text = userProfileDetails.country
                            self.lgaTextField.text = userProfileDetails.lga
                            self.nameofNextofKInTextField.text = userProfileDetails.nextOfKinName
                            self.nextofKinEmailAddressTextField.text = userProfileDetails.nextOfKinEmail
                            self.nextofKInPhoneTextField.text = userProfileDetails.nextOfKinPhoneNumber
                            self.nextofKinAddressTextField.text = userProfileDetails.nextOfKinAddress
                            self.kinPincode.text = userProfileDetails.nextOfKinPincode
                            self.subtreasuryTextField.text = userProfileDetails.subTreasury
                            self.dateOfAppointmentTextField.text = userProfileDetails.dateOfAppointment
                            self.gradeLevelTextField.text = userProfileDetails.gradeLevel
                            self.occupationTextField.text = userProfileDetails.occupation
                            delegate?.didRetrieveData(success: true)
                        }
                        else{
                            DispatchQueue.main.async {
                                delegate?.didRetrieveData(success: false)
                            }
                        }
                    }
                }else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        self.alert(message: data.detail.message, title: "Failed")
                    }
                    else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                        
                    }
                    else if data.detail.tokenStatus == "Invalid"{
                        self.alert(message: data.detail.message, title: "Failed")
                    }
                    else {
                        self.alert(message: "Failed to refresh token", title: "Session Expired")
                    }
                }else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    delegate?.didRetrieveData(success: false)
                    var errorMessage = "An error occurred. Please try again later."
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    
                    else if let nsError = error as NSError? {
                        // Check if the error is related to being offline
                        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                            errorMessage = "You are offline. Please check your internet connection."
                        }
                    }
                    
                }
            }
        }
    }
   /* func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Check if the current text field should only accept alphabets
        let shouldAcceptAlphabets: Bool
        switch textField {
        case firstNameTextField, middleNameTextField, lastNameTextField, nameofNextofKInTextField:
            shouldAcceptAlphabets = true
        default:
            shouldAcceptAlphabets = false
        }
        
        // If the text field should only accept alphabets, check the input
        if shouldAcceptAlphabets {
            let allowedCharacters = CharacterSet.letters
            let characterSet = CharacterSet(charactersIn: string)
            let isAlphabetic = allowedCharacters.isSuperset(of: characterSet)
            
            if !isAlphabetic && !string.isEmpty {
                // Show alert if a non-alphabetic character is entered
                showAlert(message: "Please enter only alphabetic characters.")
                return false
            }
        }
        
        return true
    }*/
    
    func showAlerts(message: String) {
        let alert = UIAlertController(title: "Input Error", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        // Get the location of the tap
        let location = sender.location(in: view)
        
        // Check if the tap is inside any of the views
        if !lgaView.frame.contains(location) && !subtreasuryView.frame.contains(location) && !gradeLevelView.frame.contains(location) &&
            !occupationView.frame.contains(location)
        {
            // Hide all views
            lgaView.isHidden = true
            subtreasuryView.isHidden = true
            gradeLevelView.isHidden = true
            occupationView.isHidden = true
        }
    }
    @IBAction func lgaDropDownClick(_ sender: Any) {
        if isToggled {
            lgaView.isHidden = true
            
        } else {
            lgaView.isHidden = false
            AccountCompletionAPI()
        }
        isToggled.toggle()
    }
    @IBAction func subtreasuryDropDownClick(_ sender: Any) {
        
        if isToggled {
            subtreasuryView.isHidden = true
            
        } else {
            subtreasuryView.isHidden = false
        }
        isToggled.toggle()
    }
    @IBAction func gradeLevelButtonClicked(_ sender: Any) {
        
        guard let subtreasury = subtreasuryTextField.text, !subtreasury.isEmpty else {
            showAlert(title: "Incomplete Information", message: "Please fill the Subtreasury field ", options: "Ok")
            return
        }
        
        if isToggled {
            gradeLevelView.isHidden = true
            
        } else {
            gradeLevelView.isHidden = false
            
        }
        isToggled.toggle()
    }
    @IBAction func occupationButtonClick(_ sender: Any) {
        
        guard let gradeLevel = gradeLevelTextField.text, !gradeLevel.isEmpty else {
            showAlert(title: "Incomplete Information", message: "Please fill  the LastGrade field ", options: "Ok")
            return
        }
        if isToggled {
            occupationView.isHidden = true
            
        } else {
            occupationView.isHidden = false
            
        }
        isToggled.toggle()
    }
    
    func AccountCompletionAPI() {
        let lgaParams: AccountCompletion.Body
        lgaParams = AccountCompletion.Body(country: countryTextField.text ?? "")
        
        let lgaRequest = AccountCompletion( queryParams: nil, body: lgaParams)
        
        self.showHUD(message: "")
        APIManager().perform(lgaRequest) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                
                if data.detail.status == "success" {
                    self.lga = data.detail.lgas!
                    self.occupation = data.detail.occupations!
                    self.gradeLvl = data.detail.gradeLevels!
                    self.subtreasury = data.detail.subTreasuries!
                    
                    // Reload the table view on the main thread
                    DispatchQueue.main.async {
                        self.lgaTableView.reloadData()
                        self.occupationTableView.reloadData()
                        self.gradeLevelTableView.reloadData()
                        self.subtreasuryTableView.reloadData()
                    }
                } else if data.detail.status == "fail" {
                    
                    self.alert(message: data.detail.message!, title: "Failed")
                    
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    else if let nsError = error as NSError? {
                        // Check if the error is related to being offline
                        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                            errorMessage = "You are offline. Please check your internet connection."
                        }
                    }
                    
                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == lgaTableView {
            return lga.count
        } else if tableView == subtreasuryTableView {
            return subtreasury.count
        }
        else if tableView == gradeLevelTableView {
            return gradeLvl.count
        }
        else if tableView == occupationTableView {
            return occupation.count
        }
        
        return 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == lgaTableView {
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cells", for: indexPath) as? LgaTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            
            cell.textLabel?.text = lga[indexPath.row].name
            
            return cell
            
        }
        else if tableView == subtreasuryTableView {
            
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? SubtreasuryTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            
            cell.textLabel?.text = subtreasury[indexPath.row].name
            
            return cell
        }
        else if tableView == gradeLevelTableView {
            
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? GradeLevelTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            cell.textLabel?.text = gradeLvl[indexPath.row].level
            
            return cell
        }
        else if tableView == occupationTableView {
            
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? occupationTableViewCell else {
                // Handle the case where cell couldn't be dequeued or casted
                return UITableViewCell()
            }
            cell.textLabel?.text = occupation[indexPath.row].name
            
            return cell
        }
        
        // Return a default cell if neither condition is met
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        lgaView.isHidden = true
        isToggled = false
        subtreasuryView.isHidden = true
        isToggled = false
        gradeLevelView.isHidden = true
        isToggled = false
        occupationView.isHidden = true
        isToggled = false
        if tableView == subtreasuryTableView {
            let selectedlga = subtreasury[indexPath.row]
            subtreasuryTextField.text = selectedlga.name
            selectedSubtreasuryId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.subtreasuryView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
            
        }
        else if tableView == lgaTableView {
            let selectedlga = lga[indexPath.row]
            lgaTextField.text = selectedlga.name
            selectedLgaId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.lgaView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }
        else if tableView == gradeLevelTableView {
            let selectedlga = gradeLvl[indexPath.row]
            gradeLevelTextField.text = selectedlga.level
            
            selectedGradeLevelId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.gradeLevelView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
            
        }
        
        else if tableView == occupationTableView {
            let selectedlga = occupation[indexPath.row]
            occupationTextField.text = selectedlga.name
            
            selectedOccupationId = selectedlga.id
            
            // Ensure UI updates are performed on the main thread
            DispatchQueue.main.async {
                self.occupationView.isHidden = true
            }
            
            // Deselect the row to remove the selection highlight
            tableView.deselectRow(at: indexPath, animated: true)
        }}
   /* func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
        if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
   //  method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }*/
    
    func initalSetup() {
           let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
           view.addGestureRecognizer(tap)
           
           // Register for keyboard notifications
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
           NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
           
           // Set the text field delegates
           for view in view.subviews {
               if let textField = view as? UITextField {
                   textField.delegate = self
                   textFields.append(textField)
               }
           }
       }
       
       deinit {
           // Remove the keyboard notifications
           NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
           NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
       }
    
       
       @objc func keyboardWillShow(notification: NSNotification) {
           keyboardDelegate?.keyboardWillShow(notification: notification)
       }
       
       @objc func keyboardWillHide(notification: NSNotification) {
           keyboardDelegate?.keyboardWillHide(notification: notification)
       }
       
       @objc func dismissKeyBord() {
           self.view.endEditing(true)
       }
   
    
    func setupCountryPicker(){
        self.countriesViewController = CountriesViewController()
        self.countriesViewController.delegate = self
        self.countriesViewController.allowMultipleSelection = false
        if let info = self.getCountryAndName() {
            countryName = info.countryName!
            // self.lblFlag.text = info.countryFlag!
            self.countryTextField.text = info.countryName!
        }
    }
    private func getCountryAndName(_ countryParam: String? = nil) -> CountryModel? {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonObj = JSON(data)
                let countryData = CountryListModel.init(jsonObj.arrayValue)
                let locale: Locale = Locale.current
                var countryCode: String?
                if countryParam != nil {
                    countryCode = countryParam
                } else {
                    countryCode = locale.regionCode
                }
                let currentInfo = countryData.country?.filter({ (cm) -> Bool in
                    return cm.countryShortName?.lowercased() == countryCode?.lowercased()
                })
                
                if currentInfo!.count > 0 {
                    return currentInfo?.first
                } else {
                    return nil
                }
                
            } catch {
                // handle error
            }
        }
        return nil
    }
    @IBAction func femaleButtonClicked(_ sender: Any) {
        
        selectedSex = "female"
        femaleButton.isSelected = !femaleButton.isSelected
        
        // Set image based on button state
        if femaleButton.isSelected {
            femaleButton.setImage(UIImage(named: "select"), for: .normal)
            maleButton.setImage(UIImage(named: "deselect"), for: .normal)
            maleButton.isSelected = false
        } else {
            femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
        }
        female()
    }
    @IBAction func maleButtonClicked(_ sender: Any) {
        
        selectedSex = "male"
        maleButton.isSelected = !maleButton.isSelected
        
        // Set image based on button state
        if maleButton.isSelected {
            maleButton.setImage(UIImage(named: "select"), for: .normal)
            femaleButton.setImage(UIImage(named: "deselect"), for: .normal)
            femaleButton.isSelected = false
        } else {
            maleButton.setImage(UIImage(named: "deselect"), for: .normal)
        }
        male()
    }
    func male(){
        if !isMaleSelected {
            selectedSex = "male"
            isMaleSelected = true
            isFemaleSelected = false
        } else {
            selectedSex = nil
            isMaleSelected = false
        }
        
        updateButtonStates()
    }
    func female(){
        if !isFemaleSelected {
            selectedSex = "female"
            isFemaleSelected = true
            isMaleSelected = false
        } else {
            selectedSex = nil
            isFemaleSelected = false
        }
        
        updateButtonStates()
    }
    
    func updateButtonStates() {
        // Update button UI based on the selection
        maleButton.isSelected = isMaleSelected
        femaleButton.isSelected = isFemaleSelected
    }
    @objc func doneButtonPressed() {
        let datePicker = dobTextField.inputView as! UIDatePicker
        let selectedDate = datePicker.date
        
        // Format the selected date and update the text field
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" // Adjust the date format here
        dobTextField.text = dateFormatter.string(from: selectedDate)
        
        // Dismiss the date picker
        dobTextField.resignFirstResponder()
        
        // Calculate the age and check if the person is at least 18 years old
        let calendar = Calendar.current
        let currentDate = Date()
        
        let ageComponents = calendar.dateComponents([.year], from: selectedDate, to: currentDate)
        if let age = ageComponents.year, age >= 18 {
            // Person is at least 18 years old
            // Proceed with the rest of the code
        } else {
            // Person is not 18 years old or more
            alert(message: "Person should be 18 years old or more", title: "Age Restriction")
            dobTextField.text = "" // Clear the text field if the age is not valid
        }
    }
    @objc func AppointmentDoneButtonPressed() {
        // This function is called when the "Done" button on the toolbar is pressed
        let datePicker = dateOfAppointmentTextField.inputView as! UIDatePicker
        let selectedDate = datePicker.date
        
        // Format the selected date and update the text field
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy" // Adjust the date format here
        dateOfAppointmentTextField.text = dateFormatter.string(from: selectedDate)
        
        // Dismiss the date picker
        dateOfAppointmentTextField.resignFirstResponder()
    }
    @IBAction func countryDropDownClicked(_ sender: UIButton) {
        DispatchQueue.main.async {
            CountriesViewController.show(countriesViewController: self.countriesViewController, toVar: self)
        }
    }
    
    @IBAction func nextButtonClicked(_ sender: Any) {
        // Set the account holder value in DataStorage
        fetchBasicDetails()
    }
  
    
    func fetchBasicDetails() {
        guard let firstName = firstNameTextField.text, !firstName.isEmpty else {
            alert(message: "Please enter First Name", title: "Mandatory Field")
            return
        }
        let middleName = middleNameTextField.text ?? ""
        
        guard let lastName = lastNameTextField.text, !lastName.isEmpty else {
            alert(message: "Please enter Last Name", title: "Mandatory Field")
            return
        }
        guard let dob = dobTextField.text, !dob.isEmpty else {
            alert(message: "Please enter DOB", title: "Mandatory Field")
            return
        }
        guard let address = addressTextField.text, !address.isEmpty else {
            alert(message: "Please enter address", title: "Mandatory Field")
            return
        }
        guard let pincode = userPincode.text, !pincode.isEmpty else {
            alert(message: "Please enter pincode", title: "Mandatory Field")
            return
        }
        guard let country = countryTextField.text, !country.isEmpty else {
            alert(message: "Please enter country", title: "Mandatory Field")
            return
        }
        guard let lga = lgaTextField.text, !lga.isEmpty else {
            alert(message: "Please enter lga", title: "Mandatory Field")
            return
        }
        guard let nameofNextofKin = nameofNextofKInTextField.text, !nameofNextofKin.isEmpty else {
            alert(message: "Please enter Name of next of kin", title: "Mandatory Field")
            return
        }
        let nextofKinEmailAddress = nextofKinEmailAddressTextField.text ?? ""
        
        // Check if the email address is not empty
        if !nextofKinEmailAddress.isEmpty {
            // Validate the email format
            if !nextofKinEmailAddress.isValidEmail {
                // If the email is invalid, show an alert
                alert(message: "Please provide a valid Email Address", title: "Email Validation")
                return
            }
        }
        guard let nextofKinPhone = nextofKInPhoneTextField.text, !nextofKinPhone.isEmpty else {
            alert(message: "Please enter Next of kin phone", title: "Mandatory Field")
            return
        }
        guard let nextofKinAddress = nextofKinAddressTextField.text, !nextofKinAddress.isEmpty else {
            alert(message: "Please enter next of kin address", title: "Mandatory Field")
            return
        }
        guard let nextofKinPincode = kinPincode.text, !nextofKinPincode.isEmpty else {
            alert(message: "Please enter next of kin pincode", title: "Mandatory Field")
            return
        }
        guard let subtreasury = subtreasuryTextField.text, !subtreasury.isEmpty else {
            alert(message: "Please enter Subtreasury", title: "Mandatory Field")
            return
        }
        guard let dateofAppointment = dateOfAppointmentTextField.text, !dateofAppointment.isEmpty else {
            alert(message: "Please enter Date of Appointment", title: "Mandatory Field")
            return
        }
        guard let lastGrade = gradeLevelTextField.text, !lastGrade.isEmpty else {
            alert(message: "Please enter Last grade", title: "Mandatory Field")
            return
        }
        guard let occupationType = occupationTextField.text, !occupationType.isEmpty else {
            alert(message: "Please enter Occupation Type", title: "Mandatory Field")
            return
        }
        guard let sex = selectedSex else {
            // Alert the user to select a sex
            alert(message: "Please select a sex", title: "Mandatory Field")
            return
        }
        guard let selectedLgaId = selectedLgaId else {
            return
        }
        
        guard let selectedSubtreasuryId = selectedSubtreasuryId else {
            return
        }
        
        guard let selectedGradeLevelId = selectedGradeLevelId else {
            return
        }
        
        guard let selectedOccupationId = selectedOccupationId else {
            return
        }
        
        UserData.shared.firstName = firstName
        UserData.shared.middleName = middleName
        UserData.shared.lastName = lastName
        
        self.showHUD(message: "")
        APIManager().perform(ActiveAccountCompletion(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: ActiveAccountCompletion.Body(user_type: "active", first_name: firstName, middle_name: middleName, last_name: lastName, dob: dob, sex: sex, address: address, pincode: pincode, country: country, lga_id: selectedLgaId, next_of_kin_name: nameofNextofKin, next_of_kin_email: nextofKinEmailAddress, next_of_kin_phone_number: nextofKinPhone, next_of_kin_address: nextofKinAddress, next_of_kin_pincode: nextofKinPincode, sub_treasury_id: selectedSubtreasuryId, date_of_appointment: dateofAppointment, grade_level: selectedGradeLevelId, occupation_id_or_other: String(selectedOccupationId)))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        // Notify the SegmentServiceViewController that Basic Details API succeeded
                        
                        guard let segmentServiceVC = self.parent as? SegmentServiceViewController else {
                            return
                        }
                        segmentServiceVC.segments.selectedSegmentIndex = 1
                        segmentServiceVC.updateSegmentControl(selectedIndex: 1) // Call the method to update the segment
                        if let scrollView = segmentServiceVC.view.subviews.compactMap({ $0 as? UIScrollView }).first {
                            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
                        }
                        
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: segmentServiceVC.view, duration: 3.0)
                    }
                } else if data.detail.status == "fail" {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: self.view, duration: 3.0)
                    }
                } else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.message)")
                        toast.show(in: self.view, duration: 3.0)
                    }
                }
                
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                    
                    let toast = ToastView(text: errorMessage)
                    toast.show(in: self.view, duration: 3.0)
                }
            }
        }
    }

    
    
    
        
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let index = textFields.firstIndex(of: textField) {
            if index < textFields.count - 1 {
                let nextTextField = textFields[index + 1]
                nextTextField.becomeFirstResponder()
            } else {
                textField.resignFirstResponder()
            }
        }
        return true
    }
    // UITextFieldDelegate method to handle editing
  /*  func textFieldDidBeginEditing(_ textField: UITextField) {
        if let index = textFields.firstIndex(of: textField), index > 0 {
            let previousTextField = textFields[index - 1]
            if previousTextField.text?.isEmpty ?? true {
                // Show error message
                showAlert(message: "Please fill in the order.")
                textField.resignFirstResponder()
            }
        }
    }*/
    
    // Helper method to show alert message
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func buttonClicked(_ sender: UIButton) {
        if sender == lgaButton {
            // Check if the country field is selected
            if !countryButton.isSelected {
                showAlert(message: "Please select Country first.")
                return
            }
        }
        
        // Check if the clicked button is lga, subtreasury, last grade, or occupation
        if sender  == subtreasuryButton || sender == lastGradeButton || sender == occupationButton {
            // Check if both country and lga text fields have values
            if countryTextField.text?.isEmpty ?? true || lgaTextField.text?.isEmpty ?? true {
                showAlert(message: "Please fill in both Country and LGA fields first.")
                return
            }
        }
        
        // Allow the button to be selected
        handleButtonSelection(sender)
    }
    func handleButtonSelection(_ button: UIButton) {
        button.isSelected = true
        let associatedView = buttonViews[button]
        associatedView?.isHidden = false
    }
    
}
extension BasicDetailsViewController: CountriesViewControllerDelegate {
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountries countries: [Country]) {
        
        countries.forEach { co in
            //            Logger.println(co.name)
        }
    }
    func countriesViewControllerDidCancel(_ countriesViewController: CountriesViewController) {
        //        Logger.println("user hass been tap cancel")
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountry country: Country) {
        if let info = self.getCountryAndName(country.countryCode) {
            countryName = info.countryName!
            //  self.lblFlag.text = info.countryFlag!
            self.countryTextField.text = info.countryName!
            self.nextofKInPhoneTextField.text = info.countryCode!
        }
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didUnselectCountry country: Country) {
        
        //        Logger.println(country.name + " unselected")
    }
}

