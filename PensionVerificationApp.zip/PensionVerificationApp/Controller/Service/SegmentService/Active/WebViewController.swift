//
//  WebViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 14/05/24.
//

import UIKit
import WebKit

class WebViewController: UIViewController  {
    
    var selectedFileURL: URL?
    var activityIndicator: UIActivityIndicatorView!
    var URLString:String?
    @IBOutlet weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self
        let backButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backButtonTapped))
                navigationItem.leftBarButtonItem = backButton
        // Do any additional setup after loading the view.
    }
    @objc func backButtonTapped() {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupWebView()
    }

    func setupWebView() {
        self.webView.navigationDelegate = self
        self.webView.allowsBackForwardNavigationGestures = true

        self.activityIndicator = UIActivityIndicatorView(style: .large)
                self.activityIndicator.color = UIColor.green // Replace with your desired color
                self.activityIndicator.center = self.view.center
                self.activityIndicator.hidesWhenStopped = true
                self.view.addSubview(self.activityIndicator)
        
        if let link = URL(string:URLString!) {
            self.activityIndicator.startAnimating()
            let request = URLRequest(url: link)
            self.webView.load(request)
        }
    }
}
extension WebViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        activityIndicator.stopAnimating()
        activityIndicator.isHidden = true
    }
}
