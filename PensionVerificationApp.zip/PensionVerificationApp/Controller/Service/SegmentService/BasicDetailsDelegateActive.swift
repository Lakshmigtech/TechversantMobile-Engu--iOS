//
//  BasicDetailsDelegateActive.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 16/05/24.
//

import Foundation
protocol BasicDetailsDelegate: AnyObject {
    func didRetrieveData(success: Bool)
}
