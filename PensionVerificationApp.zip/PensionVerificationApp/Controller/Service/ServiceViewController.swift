//
//  ServiceViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import UIKit

class ServiceViewController: UIViewController {

    @IBOutlet weak var retireeMainView: UIView!
    @IBOutlet weak var activeMainView: UIView!
    @IBOutlet weak var retireeView: UIView!
    @IBOutlet weak var activeView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        gradientViews()
    }
    func gradientViews(){
        activeMainView.backgroundColor = .white
        activeMainView.applyShadow() // Default shadow
        activeView.applyDarkGreenToLightGreenGradient()
        retireeMainView.backgroundColor = .white
        retireeMainView.applyShadow()
        retireeView.addDarkOrangeToLightOrangeGradient()
        activeView.makeRound()
        retireeView.makeRound()
    }
    @IBAction func activeServiceAction(_ sender: Any) {
        let activeVC = UIStoryboard.init(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "SegmentServiceViewController") as! SegmentServiceViewController
        self.navigationController?.pushViewController(activeVC, animated: true)
    }
    @IBAction func retireeAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "RetireeViewController") as! RetireeViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
        
    }
}
