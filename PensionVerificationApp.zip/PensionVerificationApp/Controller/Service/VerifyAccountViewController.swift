//
//  VerifyAccountViewController.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/07/24.
//

import UIKit
import Alamofire

class VerifyAccountViewController: UIViewController {
    
    
    @IBOutlet weak var accountNumberTf: UITextField!
    @IBOutlet weak var bankCodeTf: UITextField!
    
    var accountNumber: String?
    var bankCode: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        accountNumberTf.text = accountNumber
        bankCodeTf.text = bankCode
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGesture)
        accountNumberTf.delegate = self
        bankCodeTf.delegate  = self
        addTapGestures(to: accountNumberTf)
        addTapGestures(to: bankCodeTf)

    }

    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
  
    
    
    
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        // Call your removeAnimate function here
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        guard let accountNumber = accountNumberTf.text, !accountNumber.isEmpty else {
                   alert(message: "Please enter Account Number", title: "Mandatory Field")
                   return
               }
               guard let bankCode = bankCodeTf.text, !bankCode.isEmpty else {
                   alert(message: "Please enter Bank Code", title: "Mandatory Field")
                   return
               }
              
               self.showHUD(message: "")
               APIManager().perform(VerifyBankAccount(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: VerifyBankAccount.Body(account_number: accountNumber, bank_code: bankCode))) { result in
                   self.hideHUD()
                   switch result {
                   case .success(let data):
                       if data.detail.status == "success" {
                           DispatchQueue.main.async {
                               UserDefaults.standard.set(true, forKey: "verificationStatus")
                               UserDefaults.standard.set(data.detail.status, forKey: "verificationStatusDetail")
                               NotificationCenter.default.post(name: NSNotification.Name("VerificationStatusChanged"), object: nil)
                               let toast = ToastView(text: data.detail.message)
                               toast.show(in: self.view, duration: 3.0)
                               DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                                   self.dismiss(animated: true, completion: nil)
                               }
                           }
                       } else if data.detail.status == "fail" {
                           DispatchQueue.main.async {
                               UserDefaults.standard.set(false, forKey: "verificationStatus")
                               UserDefaults.standard.set(data.detail.status, forKey: "verificationStatusDetail")
                               NotificationCenter.default.post(name: NSNotification.Name("VerificationStatusChanged"), object: nil)
                               
                               let alert = UIAlertController(title: "Alert", message: data.detail.message, preferredStyle: .alert)
                               alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                                   alert.dismiss(animated: true, completion: nil)
                               }))
                               self.present(alert, animated: true, completion: nil)
                           }
                       } else if data.detail.tokenStatus == "valid" {
                           DispatchQueue.main.async {
                               self.callRefreshToken()
                           }
                       } else if data.detail.tokenStatus == "expired" {
                           DispatchQueue.main.async {
                               let toast = ToastView(text: data.detail.message)
                               toast.show(in: self.view, duration: 3.0)
                           }
                       } else if data.detail.tokenStatus == "Invalid" {
                           DispatchQueue.main.async {
                               let toast = ToastView(text: "Failed to refresh token")
                               toast.show(in: self.view, duration: 3.0)
                           }
                       } else {
                           DispatchQueue.main.async {
                               let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                               toast.show(in: self.view, duration: 3.0)
                           }
                       }
                       
                   case .failure(let error):
                       DispatchQueue.main.async {
                           let toast = ToastView(text: error.localizedDescription)
                           toast.show(in: self.view, duration: 3.0)
                       }
                   }
               }
           }
    
}
extension VerifyAccountViewController: UITextFieldDelegate {
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
}
