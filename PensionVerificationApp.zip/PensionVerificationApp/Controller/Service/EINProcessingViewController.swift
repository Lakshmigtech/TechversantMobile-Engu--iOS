//
//  EINProcessingViewController.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 03/06/24.
//

import UIKit

class EINProcessingViewController: UIViewController {
    @IBOutlet weak var processingLabel: UILabel!
    @IBOutlet weak var activityIndicatoe: UIActivityIndicatorView!
    @IBOutlet weak var pindicatorImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
      //  performProcessing()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.userGovetStatus()
        }
    }
   /* func performProcessing() {
           // Start your processing task here
           // For example, fetching data from a server
           // Show activity indicator
           activityIndicatoe.startAnimating()
           // Update status label
           processingLabel.text = "Processing..."
           // Simulate a task with DispatchQueue
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
               // Task completed
               // Stop activity indicator
               self.activityIndicatoe.stopAnimating()
               // Update status label
               self.processingLabel.text = "Processing Complete"
               // Navigate to next screen or perform other actions
               // For example, dismiss this view controller
               // self.dismiss(animated: true, completion: nil)
           }
       }*/
    func userGovetStatus(){
        
        APIManager().perform(UserGovtStatus(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    if data.detail.userGovtVerified == true{
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                            let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
       
                    }
                    }else if data.detail.userGovtVerified == false{
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                            let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
       
                    }
                    }
                }
                    
                else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                       // let toast = ToastView(text: data.detail.message)
                       // toast.show(in: self.view, duration: 3.0)
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                            let popup = UIStoryboard(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "NotGovtVerifiedViewController") as! NotGovtVerifiedViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                         
                        }
                    } else if data.detail.tokenStatus == "expired" {
                        self.callRefreshToken()
                    } else if data.detail.tokenStatus == "Invalid" {
                        let toast = ToastView(text: data.detail.message)
                        toast.show(in: self.view, duration: 3.0)
                    } else {
                        let toast = ToastView(text: "Failed to refresh token")
                        toast.show(in: self.view, duration: 3.0)
                    }
                } else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
                
            case .failure(let error):
                // Handle API call failure
                DispatchQueue.main.async {
                    let toast = ToastView(text: error.localizedDescription)
                    toast.show(in: self.view, duration: 3.0)   }         }
        }    }
    
   }

 
