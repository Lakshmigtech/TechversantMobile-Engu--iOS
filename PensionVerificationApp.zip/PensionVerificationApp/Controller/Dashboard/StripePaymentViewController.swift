//
//  StripePaymentViewController.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 30/08/24.
//

import UIKit
import WebKit

class StripePaymentViewController: UIViewController, WKNavigationDelegate {

    var checkoutURL: String?
    private var webView: WKWebView!
    
    
      //  var customContainerView: UIView!
    
    // Closure to pass the payment status message back
    var onPaymentStatusReceived: ((String) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize the WKWebView
        webView = WKWebView()
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        
        // Set up WebView constraints to cover the entire screen
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        // Load the checkout URL
        if let checkoutURL = checkoutURL, let url = URL(string: checkoutURL) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
        
        
        
        
     /*   // Create a custom container view
               customContainerView = UIView()
               customContainerView.backgroundColor = UIColor.white // Change to your preferred color
               customContainerView.layer.cornerRadius = 10
               customContainerView.layer.borderWidth = 0
               customContainerView.layer.borderColor = UIColor.white.cgColor
               customContainerView.translatesAutoresizingMaskIntoConstraints = false
               
               // Add the custom container view to the main view
               view.addSubview(customContainerView)

        // Set up constraints for the custom view to position it in the top-left corner
                NSLayoutConstraint.activate([
                    customContainerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
                    customContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
                    customContainerView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8), // Adjust width as needed
                    customContainerView.heightAnchor.constraint(equalToConstant: 50) // Adjust height as needed
                ])*/
                
        
        
        
        // Set the title for the view controller
                title = "Payment"
                
                // Create and configure the back button
                let backButton = UIButton(type: .system)
                backButton.setTitle("Back", for: .normal)
                backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

                // Set button frame (or use Auto Layout)
                backButton.frame = CGRect(x: 0, y: 30, width: 100, height: 50)
                view.addSubview(backButton)
                
                // Additional setup for Stripe payment here...
            }

            @objc func backButtonTapped() {
                // If presented modally, use dismiss()
                    dismiss(animated: true, completion: nil)
            }
   
    
    // WKNavigationDelegate method to intercept the URL before it's loaded
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = navigationAction.request.url?.absoluteString {
            print("Intercepted URL: \(url)")
            
            // Check if it's the success URL
            if url.contains("success?session_id") {
                // Extract the session ID from the URL
                if let sessionID = extractSessionID(from: url) {
                    print("Payment successful with session ID: \(sessionID)")
                    
                    // Make an API call to check the payment status
                    checkPaymentStatus(sessionID: sessionID)
                    
                    // Cancel the navigation to prevent the redirected URL from loading
                    decisionHandler(.cancel)
                    return
                }
            }
        }
        
        // Allow navigation for other URLs
        decisionHandler(.allow)
    }

    // Helper function to extract session ID from URL
    private func extractSessionID(from url: String) -> String? {
        guard let urlComponents = URLComponents(string: url),
              let queryItems = urlComponents.queryItems else {
            return nil
        }
        
        // Find the session_id parameter in the query items
        for item in queryItems {
            if item.name == "session_id" {
                return item.value
            }
        }
        return nil
    }
    
    // Function to make an API call to check the payment status
    private func checkPaymentStatus(sessionID: String) {
        // Create the request with the session ID
        let queryParams = PaymentStatusRequest.QueryParams(session_id: sessionID)
        let statusRequest = PaymentStatusRequest(bearerToken:  UserDefaults.standard.accessToken, queryParams: queryParams, body: nil)

        // Perform the API call
        APIManager().perform(statusRequest) { result in
            switch result {
            case .success(let paymentStatusResponse):
                print("Payment status: \(paymentStatusResponse)")
                
                // Pass the payment status message back to PaymentViewController
                DispatchQueue.main.async {
                    self.onPaymentStatusReceived?(paymentStatusResponse.message)
                    self.dismiss(animated: true, completion: nil)
                }

            case .failure(let error):
                print("Failed to get payment status: \(error)")
                // Handle the failure (e.g., show an error message)
            }
        }
    }
}
