//
//  SlotTableViewCell.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/09/24.
//

import UIKit

class SlotTableViewCell: UITableViewCell {

    @IBOutlet weak var slotLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
