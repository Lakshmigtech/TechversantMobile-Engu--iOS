//
//  BookingDetailsViewController.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 12/11/24.
//

import UIKit

class BookingDetailsViewController: UIViewController,dataSendBookingDetailsController{
    func date(text: String) {
        dateLabel.text = text
    }
    
    func slote(text: String) {
        slotLabel.text = text
    }
    
    var selectedDate: String?
    var selectedSlot: String?
    private var currentWalletBalance: Double = 0.0 // Store the current wallet balance
    private var walletBalanceCurrencys: String?
    var walletBalance: Double = 0.0 // Add this property
    @IBOutlet weak var walletBalanceLabel: UILabel!
    @IBOutlet weak var descriptionTextfield: UITextField!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var payButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var slotLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var baseView: UIView!
    @IBOutlet weak var payView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        baseView.addBorder(width: 1, color: UIColor.systemGray4)
        //amountView.addBorder(width: 1, color: UIColor.systemGray4)
        //amountView.applyShadow()
        descriptionView.addBorder(width: 1, color: UIColor.systemGray4)
        descriptionView.applyShadow()
        baseView.applyCornerRadius(10)
        baseView.applyShadow()
        payView.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        backButton.backgroundColor = UIColor(displayP3Red: 226/255, green: 255/255, blue: 239/255, alpha: 1.0)
        payView.layer.cornerRadius = 10
        backButton.layer.cornerRadius = 10
        // Set the labels with the received data
               dateLabel.text = selectedDate
               slotLabel.text = selectedSlot
        
        updateWalletBalance(walletBalance)
        employeDetails()
    }
    func employeDetails() {
        APIManager().perform(DashBoard(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [weak self] result in
            
            guard let self = self else { return } // Capture self weakly to avoid retain cycles

            switch result {
            case .success(let data):
                print("API call succeeded with data: \(data)")
                if data.detail.status == "success" {
                    print("Status is success")
                    DispatchQueue.main.async {
                        // Safely unwrap bankDetail and bankName
                        
                        self.updateWalletBalance(Double(data.detail.walletBalanceAmount ?? 0))
                        self.walletBalanceCurrencys = data.detail.walletBalanceCurrency
                        //  self.walletBalanceCurrency.text = self.walletBalanceCurrencys
                        
                        
                    }
                }
            case .failure(_): break
             //   self.handleError(error)
            }
        }
    }

    
private func updateWalletBalance(_ balance: Double) {
    walletBalance = balance
    walletBalanceLabel.text = "\(walletBalance)"
}
    
    
    
    @IBAction func backButtonClick(_ sender: Any) {
        
        if let nextViewController = storyboard?.instantiateViewController(withIdentifier: "DashBoardViewController") as? DashBoardViewController {
            // Pass the wallet balance
        //   nextViewController.walletBalance = currentWalletBalance
            navigationController?.pushViewController(nextViewController, animated: true)
            
        }
    }
    @IBAction func payButtonClick(_ sender: Any) {
//        guard let amountText = 500, let amount = Double(amountText) else {
//               print("Invalid amount entered")
//               return
//           }
           let descriptionText = descriptionTextfield.text ?? ""
           
           // Set currency value here
        let paymentDetails = PaymentDetails.Body(amount: 500.00, description: descriptionText, currency: "USD")
           
           let paymentRequest = PaymentDetails(bearerToken: UserDefaults.standard.accessToken, body: paymentDetails)
           
           showHUD(message: "")
           APIManager.shared.perform(paymentRequest) { [weak self] (result: Result<PaymentResponse, Error>) in
               self?.hideHUD()
               switch result {
               case .success(let result):
                   print(result)
                   DispatchQueue.main.async {
                       self?.alert(message: "Transaction Successfull", actions: UIAlertAction(title: "Success", style: .cancel))
                   }
                   
               case .failure(let error):
                   print("transaction failed: \(error.localizedDescription)")
               }
           }
        employeDetails()
    }
   
    
}
