//
//  DateSelectViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 08/11/23.
//

import UIKit
protocol dataSendBookingDetailsController {
    func date(text:String)
    func slote(text:String)
}

class DateSelectViewController: UIViewController,dataSendMainController{
  
    
    func data(text: String) {
        
        dateTextField.text = text
    }
    
    @IBOutlet var mainView: UIView!
    @IBOutlet weak var payView: UIView!
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var selectMainView: UIView!
    @IBOutlet weak var dateTextField: UITextField!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var slotTableView: UITableView!
    @IBOutlet weak var slotView: UIView!
    
    
    var selectedSlotId: Int?
    let datePicker = UIDatePicker()
    let textField = UITextField()
    var isFirstButtonClick = true
    var isToggled = false
    var slotData: [Slot] = []
    var delegate: dataSendBookingDetailsController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateTextField.delegate = self
        timeTextField.delegate = self
        
        dateView.addBorder(width: 1.0, color: UIColor.systemGray4)
        timeView.addBorder(width: 1.0, color: UIColor.systemGray4)
        selectMainView.applyCornerRadius(15)
        payView.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        backButton.backgroundColor = UIColor(displayP3Red: 226/255, green: 255/255, blue: 239/255, alpha: 1.0)
        payView.layer.cornerRadius = 10
        backButton.layer.cornerRadius = 10
        selectMainView.applyShadow()
        slotView.isHidden = true
        slotTableView.delegate = self
        slotTableView.dataSource = self
        
        // Disable delaysContentTouches for the tableView and its superview
               slotTableView.delaysContentTouches = false
               if let scrollView = slotTableView.subviews.first(where: { $0 is UIScrollView }) as? UIScrollView {
                   scrollView.delaysContentTouches = false
       }
           // Disable the delay when the touch begins
               slotTableView.canCancelContentTouches = true
               slotTableView.isUserInteractionEnabled = true
           // Gesture recognizer handling
           let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
           slotTableView.addGestureRecognizer(tapGesture)
        
        
        // Add a tap gesture recognizer to selectBankView
           let tapGestures = UITapGestureRecognizer(target: self, action: #selector(dateViewTapped))
           dateView.addGestureRecognizer(tapGestures)
           dateView.isUserInteractionEnabled = true
        
        // Add a tap gesture recognizer to selectBankView
           let tapGestureSlot = UITapGestureRecognizer(target: self, action: #selector(timeViewtapped))
           timeView.addGestureRecognizer(tapGestureSlot)
           timeView.isUserInteractionEnabled = true
        
    }
    @objc func dateViewTapped() {
        dateSelection()
    }
    @objc func timeViewtapped() {
        slotSelection()
    }
    
       // Ensuring tap gestures are recognized quickly
       @objc func handleTap(gesture: UITapGestureRecognizer) {
           let point = gesture.location(in: slotTableView)
           if let indexPath = slotTableView.indexPathForRow(at: point) {
               tableView(slotTableView, didSelectRowAt: indexPath)
           }
       }
       // Ensure gestures are recognized simultaneously to avoid delays
       func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
           return true
       }
    
    func showAnimate() {
            
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
            UIView.animate(withDuration: 0.25, animations: {
                self.view.alpha = 1.0
                self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            });
        }
        
        func removeAnimate() {
            UIView.animate(withDuration: 0.25, animations: {
                self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
                self.view.alpha = 0.0;
            }, completion:{(finished : Bool)  in
                if (finished)
                {
                    self.view.removeFromSuperview()
                }
            });
        }
    func dateSelection(){
        let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "CalendarViewController") as! CalendarViewController
        self.addChild(popup)
        popup.view.frame = self.view.frame
        self.view.addSubview(popup.view)
        popup.didMove(toParent: self)
        popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        // popup.modalTransitionStyle = .crossDissolve
        popup.delegate = self    }
    
    @IBAction func dateButtonClicked(_ sender: Any) {
        dateSelection()
        
    }
    @IBAction func timeButtonClicked(_ sender: Any) {
        
        datePicker.datePickerMode = .time
        datePicker.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
        
        timeTextField.inputView = datePicker
        timeTextField.becomeFirstResponder()
    }
 @objc func datePickerValueChanged(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = .short
        timeTextField.text = dateFormatter.string(from: sender.date)
    }
    @IBAction func closeButton(_ sender: Any) {
        removeAnimate()
    }
   
    
    @IBAction func slotDropDown(_ sender: Any) {
        slotSelection()
        
    }
    func slotSelection(){
        
        if isFirstButtonClick {
           // showHUD(message: "")
            isFirstButtonClick = false
        }
        isToggled.toggle()
        
        if isToggled {
            slotView.isHidden = false
            slotAPI()
        } else {
            slotView.isHidden = true
        }
    }
    
    func slotAPI() {
        guard let dateSelect = dateTextField.text, !dateSelect.isEmpty else {
            alert(message: "Please enter Date", title: "Mandatory Field")
            return
        }
        let queryParams = SlotAvailable.QueryParams(selectedDay: dateSelect)

        APIManager().perform(SlotAvailable(queryParams: queryParams, body: nil)) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.detail.status == "success" {
                        self.slotData = data.detail.slots // Assign slots to data source
                        self.slotTableView.reloadData() // Reload table view
                        self.slotView.isHidden = false // Show slot view if hidden
                    }
                }
            case .failure(let error):
                print("API call failed with error: \(error.localizedDescription)")
            }
        }
        
        
        
    }
    // Modify createBookingAPI to use selectedSlotId
       func createBookingAPI() {
           guard let dateSelect = dateTextField.text, !dateSelect.isEmpty else {
               alert(message: "Please select a Date for Booking", title: "Mandatory Field")
               return
           }
           
           // Ensure the selectedSlotId is available
           guard let selectedSlotId = selectedSlotId else {
               alert(message: "Please select a slot for Booking", title: "Mandatory Field")
               return
           }
           
           self.showHUD(message: "")
           APIManager().perform(CreateBooking(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: CreateBooking.Body(booking_date: dateSelect, booking_slot_id: selectedSlotId))) { result in
               self.hideHUD()
               switch result {
               case .success(let data):
                           if data.detail.status == "success" {
                               DispatchQueue.main.async {
                                   let toast = ToastView(text: data.detail.message)
                                   toast.show(in: self.view, duration: 3.0)
                                   
                                   // Dismiss after 5 seconds
                                                       DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                                                           // Remove the child view controller after 5 seconds
                                                           self.removeFromParentVC()
                                                       }
                               }
                           }
                   else if data.detail.status == "fail" {
                       DispatchQueue.main.async {
                           let toast = ToastView(text: data.detail.message)
                           toast.show(in: self.view, duration: 3.0)
                       }
                   } else {
                       DispatchQueue.main.async {
                           let toast = ToastView(text: "Unexpected status: \(data.detail.message)")
                           toast.show(in: self.view, duration: 3.0)
                       }
                   }
                   
               case .failure(let error):
                   print("Error:", error)
                   DispatchQueue.main.async {
                       var errorMessage = "An error occurred. Please try again later."
                       
                       if let apiError = error as? APIErrorFormat {
                           switch apiError {
                           case .networkError:
                               errorMessage = "Network error. Please check your internet connection."
                           case .invalidResponse:
                               errorMessage = "Invalid response from the server. Please try again."
                           }
                       }
                       
                       let toast = ToastView(text: errorMessage)
                       toast.show(in: self.view, duration: 3.0)
                   }
               }
           }
       }
    func removeFromParentVC() {
        self.willMove(toParent: nil)
        self.view.removeFromSuperview()
        self.removeFromParent()
    }
    
    
   
    @IBAction func payNowButtonClicked(_ sender: Any) {
        createBookingAPI()
        let slotSelected = timeTextField.text!
                  let dateSelected = dateTextField.text!
                  
                  // Set delegate methods if needed
                  delegate?.date(text: dateSelected)
                  delegate?.slote(text: slotSelected)

                  // Instantiate BookingDetailsViewController
                  let bookingDetailsVC = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "BookingDetailsViewController") as! BookingDetailsViewController
                  
                  // Pass the selected date and slot
                  bookingDetailsVC.selectedDate = dateSelected
                  bookingDetailsVC.selectedSlot = slotSelected
                  
                  // Navigate to BookingDetailsViewController
                  self.navigationController?.pushViewController(bookingDetailsVC, animated: true)
        
    }
    

}
extension DateSelectViewController: UITextFieldDelegate , UITableViewDelegate, UITableViewDataSource{
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return slotData.count
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SlotTableViewCell
           let slot = slotData[indexPath.row]
           cell.slotLabel.text = "\(slot.startTime) - \(slot.endTime)"
           
           return cell
       }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedSlot = slotData[indexPath.row]
        
        // Print the selected slot data
        print("Selected Slot: \(selectedSlot.startTime) - \(selectedSlot.endTime)")
        
        // Update the timeTextField with the selected slot
        timeTextField.text = "\(selectedSlot.startTime) - \(selectedSlot.endTime)"
        // Store the selected slotId
               selectedSlotId = selectedSlot.id
        
        // Optionally hide the slot view after selection
        slotView.isHidden = true
    }

}
