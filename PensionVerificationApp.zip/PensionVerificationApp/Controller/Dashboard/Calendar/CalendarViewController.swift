//
//  CalendarViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/11/23.
//



import UIKit
import FSCalendar

protocol dataSendMainController {
    func data(text:String)
}
class CalendarViewController: UIViewController,FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance
{
    var delegate: dataSendMainController?
    var bookingDateRanges: [BookingDateRange] = []
    var holidays: [String: String] = [:]  // To store holiday dates and names
    @IBOutlet weak var monthView: UIView!
    // struct  Data {
    // var duration:String
    // }
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var popView: UIView!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var calendar: FSCalendar!
    var formatter = DateFormatter()
    var selectedDates: [Date] = []
    var firstDate =  Date()
    var lastDate = Date()
    var currentMonthIndex = 0
    let calender = Calendar.current
    // var month = FSCalendarHeaderView()
    let weekdaysTextColor = UIColor.black
    override func viewDidLoad() {
        super.viewDidLoad()
        
        popView.addSubview(calendar)
        calendar.scrollDirection = .horizontal
        calendar.scope = .month
        calendar.delegate = self
        calendar.dataSource = self
        calendar.allowsMultipleSelection = false
        calendar.appearance.borderRadius = 13
        calendar.today = nil
        calendar.calendarHeaderView.backgroundColor = UIColor.white
        calendar.calendarWeekdayView.backgroundColor = UIColor.white
        calendar.appearance.weekdayTextColor = weekdaysTextColor
        calendar.appearance.headerTitleColor = weekdaysTextColor
        calendar.headerHeight = 0
        calendar.weekdayHeight = 0
        calendar.clipsToBounds = true
        updateMonthLabel()
        BookingAPI()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.61)
        calendar.appearance.selectionColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        calendar.appearance.titleSelectionColor = UIColor.white
        calendar.firstWeekday = 2
        submitButton.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        closeButton.backgroundColor = UIColor(displayP3Red: 226/255, green: 255/255, blue: 239/255, alpha: 1.0)
        closeButton.layer.cornerRadius = 10
        submitButton.layer.cornerRadius = 10
        calendar.placeholderType = .none
        self.showAnimate()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.61)
        
        submitButton.addTarget(self, action: #selector(submitClicked), for: .touchUpInside)
        calendar.reloadData()
        // Set the subtitle font size here
        calendar.appearance.subtitleFont = UIFont.systemFont(ofSize: 5.5, weight: .light) // Change 10 to your preferred size
        
        // Adding tap gesture recognizer to the calendar
               let tapGesture = UITapGestureRecognizer(target: self, action: #selector(calendarTapped(_:)))
               tapGesture.cancelsTouchesInView = false // Allow touches to propagate to the calendar
               calendar.addGestureRecognizer(tapGesture)
           }

           @objc func calendarTapped(_ sender: UITapGestureRecognizer) {
               // Get the location of the tap
               let point = sender.location(in: calendar)
               
               // Use the `date(for:)` method to get the date at the tapped point
              // if let date = calendar.date(for: point) {
                // Select the date if it's selectable
                  // calendar.select(date) // Select the date
                   
                   // Handle your date selection logic here
                   let formatter = DateFormatter()
                   formatter.dateFormat = "dd/MM/yyyy"
                  // let dateSelected = formatter.string(from: date)
                   
                   // Notify delegate or perform actions with the selected date
                  // print("Selected date: \(dateSelected)")
              // }
           }

    // Call this method after your API fetch to store holidays
    func BookingAPI() {
        APIManager().perform(BookingDateRangeAPI(queryParams: nil, body: nil)) { [self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    print("API call succeeded with data: \(data)")
                    if data.detail.status == "success" {
                        self.bookingDateRanges = data.detail.bookingDateRange
                        // Store holidays in a dictionary for fast lookup
                        for range in bookingDateRanges {
                            for holiday in range.holidays {
                                holidays[holiday.date] = holiday.name  // Store holiday name with date
                            }
                        }
                        calendar.reloadData()  // Reload calendar to reflect new data
                        updateMonthLabel()  // Ensure month label is updated
                    }
                }
            case .failure(let error):
                print("API call failed with error: \(error.localizedDescription)")
            }
        }
    }
    // Update the month label to reflect the current month
    func updateMonthLabel() {
        let currentDate = calender.date(byAdding: .month, value: currentMonthIndex, to: Date())!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM yyyy"
        let monthString = dateFormatter.string(from: currentDate)
        monthLabel.text = monthString
    }
    @IBAction func previousClicked(_ sender: Any) {
        calendar.setCurrentPage(getPreviousMonth(date: calendar.currentPage), animated: true)
        currentMonthIndex -= 1
        updateMonthLabel()
    }
    @IBAction func nextClicked(_ sender: Any) {
        
        calendar.setCurrentPage(getNextMonth(date: calendar.currentPage), animated: true)
        currentMonthIndex += 1
        updateMonthLabel()
    }
    @IBAction func closeButtonClicked(_ sender: Any) {
        removeAnimate()
    }
    
    @IBAction func submitClicked(_ sender: Any) {
        removeAnimate()
    }
    
    func getNextMonth(date:Date)->Date {
        return  Calendar.current.date(byAdding: .month, value: 1, to:date)!
    }
    
    func getPreviousMonth(date:Date)->Date {
        
        return  Calendar.current.date(byAdding: .month, value: -1, to:date)!
    }
    
    func showAnimate() {
        
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        self.view.alpha = 0.0;
        UIView.animate(withDuration: 0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        });
    }
    
    func removeAnimate() {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
        }, completion:{(finished : Bool)  in
            if (finished)
            {
                self.view.removeFromSuperview()
            }
        });
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
      /*  // Allow today's date to be selected
            let today = Calendar.current.startOfDay(for: Date())
            
            // Disable past dates, except for today
            if date < today {
                return false
            }*/
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        for range in bookingDateRanges {
            if let startDate = dateFormatter.date(from: range.startDay),
               let endDate = dateFormatter.date(from: range.endDay) {
                // Allow selection within the valid date range
                if date >= startDate && date <= endDate {
                    return true
                }
            }
        }
        return false
    }
    
    // Provide a subtitle (holiday name) for specific dates
    func calendar(_ calendar: FSCalendar, subtitleFor date: Date) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: date)
        
        // Return the holiday name if the date is a holiday
        if let holidayName = holidays[dateString] {
            return holidayName  // Display the holiday name below the date
        }
        return nil  // No subtitle for non-holiday dates
    }
    
    
    // Customize appearance to change holiday color and valid/invalid dates
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleDefaultColorFor date: Date) -> UIColor? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: date)
        
        let today = Calendar.current.startOfDay(for: Date())

        // Check if the date is a holiday
        if holidays[dateString] != nil {
            return UIColor.red  // Holiday dates in red
        }
        // Disable past dates and show them in gray
            if date < today {
                return UIColor.gray
            }
        
        // Disable dates outside the booking range
        for range in bookingDateRanges {
            if let startDate = dateFormatter.date(from: range.startDay),
               let endDate = dateFormatter.date(from: range.endDay) {
                if date >= startDate && date <= endDate {
                    return UIColor.black  // Valid dates
                }
            }
        }
        return UIColor.gray  // Invalid dates
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let dateSelected = formatter.string(from: date)
        delegate?.data(text: dateSelected)
        dismiss(animated: true, completion: nil)
       
    }
    func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
        if let index = selectedDates.firstIndex(of: date) {
            selectedDates.remove(at: index)
        }
        
    }
    
    func calendar(_ calendar: FSCalendar, shouldDeselect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        // Customize the deselection criteria for individual dates if needed
        return true
    }
}
extension Date {
    static func dates(from fromDate: Date, to toDate: Date) -> [Date] {
        var dates: [Date] = []
        var date = fromDate
        
        while date <= toDate {
            dates.append(date)
            guard let newDate = Calendar.current.date(byAdding: .day, value: 1, to: date) else { break }
            date = newDate
        }
        return dates
    }
}


