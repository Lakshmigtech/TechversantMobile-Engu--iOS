//
//  BankDetailsViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 08/11/23.
//

import UIKit

protocol imageDelegateProtocol: AnyObject {
    func imageData(_ image: UIImage?)
}
protocol dataSendDashBoardViewController {
    func data(text: String)
    func datas(text: String)
}

protocol cancelSendDashBoardViewController {
    func data1(text: String)
    func data2(text: String)
}

class BankDetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var bankTableView: UITableView!
    @IBOutlet weak var accountTypeTableView: UITableView!
    @IBOutlet weak var bankView: UIView!
    @IBOutlet weak var accountView: UIView!
    @IBOutlet weak var bankSelectionTextField: UITextField!
    @IBOutlet weak var accountTypeTextField: UITextField!
    @IBOutlet weak var bankLogoImage: UIImageView!
    @IBOutlet weak var selectBankView: UIView!
    @IBOutlet weak var accountNumberView: UIView!
    @IBOutlet weak var acoountnumberReenterView: UIView!
    @IBOutlet weak var accountHolderView: UIView!
    @IBOutlet weak var swiftCodeView: UIView!
    @IBOutlet weak var bankCodeView: UIView!
    @IBOutlet weak var accountTypeView: UIView!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var mainView: UIView!
    
    
    @IBOutlet weak var accountNumberTextField: UITextField!
    @IBOutlet weak var re_enterAccountNumberTextField: UITextField!
    @IBOutlet weak var accountHolderNameTextField: UITextField!
    @IBOutlet weak var swiftCodeTextField: UITextField!
    @IBOutlet weak var bankCodeTextField: UITextField!
    
    var selectedBankId: Int?
    var delegate: dataSendDashBoardViewController?
    var delegate1: cancelSendDashBoardViewController?
    var imageDelegate: imageDelegateProtocol?
    
    
    var isToggled = false
 /*   var bankName: [String] =
        ["Zenith Bank","HDFC Bank","South Indian Bank","Canara Bank"]*/
    var accountType: [String] =
        ["Savings Account","Current Account"]
    
    var bankList: [Bank] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bankSelectionTextField.delegate = self
        accountTypeTextField.delegate = self
        accountNumberTextField.delegate = self
        re_enterAccountNumberTextField.delegate = self
        accountHolderNameTextField.delegate = self
        swiftCodeTextField.delegate = self
        bankCodeTextField.delegate = self
        
        
        selectBankView.addBorder(width: 1.0, color: UIColor.systemGray4)
        accountNumberView.addBorder(width: 1.0, color: UIColor.systemGray4)
        acoountnumberReenterView.addBorder(width: 1.0, color: UIColor.systemGray4)
        accountHolderView.addBorder(width: 1.0, color: UIColor.systemGray4)
        swiftCodeView.addBorder(width: 1.0, color: UIColor.systemGray4)
        bankCodeView.addBorder(width: 1.0, color: UIColor.systemGray4)
        accountTypeView.addBorder(width: 1.0, color: UIColor.systemGray4)
        mainView.applyCornerRadius(15)
        checkButton.setImage(UIImage(systemName: "square"), for: .normal)
        checkButton.tintColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        bankView.isHidden = true
        bankTableView.delegate = self
        bankTableView.dataSource = self
        accountView.isHidden = true
        accountTypeTableView.delegate = self
        accountTypeTableView.dataSource = self
        submitButton.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        closeButton.backgroundColor = UIColor(displayP3Red: 226/255, green: 255/255, blue: 239/255, alpha: 1.0)
        closeButton.layer.cornerRadius = 10
        submitButton.layer.cornerRadius = 10
        showAnimate()
        
        
        
    }
    @IBAction func checkButtonClicked(_ sender: Any) {
        
        checkButton.isSelected = !checkButton.isSelected
        
        if checkButton.isSelected {
            checkButton.setImage(UIImage(systemName: "checkmark.square"), for: .normal)
            checkButton.tintColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        } else {
            checkButton.setImage(UIImage(systemName: "square"), for: .normal)
            checkButton.tintColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == bankTableView{
            return bankList.count
        }
        else{
            return accountType.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == bankTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? AddBankTableViewCell
            
            // Configure the cell with data from the bankList array
            let bank = bankList[indexPath.row]
            
            cell?.textLabel?.text = bank.name
            // Assuming 'name' is a property in BankListResponse
            if let logoURL = URL(string: bank.logo) {
                // Load the image asynchronously
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: logoURL),
                       let image = UIImage(data: imageData) {
                        // Update the UI on the main thread
                        DispatchQueue.main.async {
                            cell?.imageView?.image = image
                            cell?.setNeedsLayout()  // Refresh the layout to display the new image
                        }
                    }
                }
            }
            return cell!
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cells", for: indexPath) as? AddBankAccountsTableViewCell
            
            cell?.accountTypeLabel.text = accountType[indexPath.row]
            cell?.selectionStyle = .none
            return cell!
        }
       
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        bankView.isHidden = true
        isToggled = false
        
        if tableView == bankTableView{
            let selectedBank = bankList[indexPath.row]
            bankSelectionTextField.text = selectedBank.name
            selectedBankId = selectedBank.id
            // Optionally, you can dismiss the table view or perform any other actions
            tableView.deselectRow(at: indexPath, animated: true)
            // Load the logo image asynchronously
            if let logoURL = URL(string: selectedBank.logo) {
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: logoURL),
                       let image = UIImage(data: imageData) {
                        // Update the UI on the main thread
                        DispatchQueue.main.async {
                            self.bankLogoImage.image = image
                        }
                    }
                }
            }
          
        }
        else{
            let cell = accountTypeTableView.cellForRow(at: indexPath) as! AddBankAccountsTableViewCell
            let labelText = cell.accountTypeLabel.text
            accountTypeTextField.text = labelText
            accountView.isHidden = true
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == bankTableView {
            return 30
        } else  {
            return 80
        }
    }
    
    func fetchBankList() {
        
        showHUD(message: "")
        APIManager().perform(BankList(bearerToken: UserDefaults.standard.accessToken)) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    self.bankList = data.detail.banks
                                  DispatchQueue.main.async {
                                      self.bankTableView.reloadData()
                                  }
                } else if data.detail.status == "fail" {
                    if data.detail.message == "Invalid token"{
                        self.alert(message: data.detail.message, title: "Failed")
                    }else if data.detail.message == "expired" {
                        self.callRefreshToken()
                    }else{
                        
                    }
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message, title: "Failed Login")
                        // Handle the "fail" status here
                    }
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status ?? "")", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."

                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                        // Add more cases as needed
                        }
                    }

                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
//            {
//            case .success(let response):
//                self.bankList = response.banks
//                DispatchQueue.main.async {
//                    self.bankTableView.reloadData()
//                }
//            case .failure(let error):
//                print("Error fetching bank list: \(error)")
//            }
        }
    }
   
    @IBAction func bankSelectionClicked(_ sender: Any) {
        
        if isToggled {
            bankView.isHidden = true
            
        } else {
            bankView.isHidden = false
            fetchBankList()
        }
        isToggled.toggle()
    }
    @IBAction func accountTypeButtonClicked(_ sender: Any) {
        isToggled.toggle()
        
        if isToggled {
            accountView.isHidden = false
            
        } else {
            accountView.isHidden = true
            
        }
    }
    func showAnimate() {
        
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        self.view.alpha = 0.0;
        UIView.animate(withDuration: 0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        });
    }
    
    func removeAnimate() {
        UIView.animate(withDuration: 0.25, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.view.alpha = 0.0;
        }, completion:{(finished : Bool)  in
            if (finished)
            {
                self.view.removeFromSuperview()
            }
        });
    }
    @IBAction func submitButtonClicked(_ sender: Any) {
        
        guard let accountNumber = accountNumberTextField.text, !accountNumber.isEmpty, accountNumber.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil else {
               alert(message: "Please enter a valid Account Number", title: "Invalid Input")
               return
           }
           // Validate re-entered account number: Check if it matches the account number
           guard let reEnterAccountNumber = re_enterAccountNumberTextField.text, !reEnterAccountNumber.isEmpty, reEnterAccountNumber == accountNumber else {
               alert(message: "Re-entered Account Number does not match", title: "Invalid Input")
               return
           }
           // Validate account holder name: Check if it contains only letters and spaces, and is not empty
           guard let holderName = accountHolderNameTextField.text, !holderName.isEmpty, holderName.rangeOfCharacter(from: CharacterSet.letters.union(CharacterSet(charactersIn: " ")).inverted) == nil else {
               alert(message: "Please enter a valid Account Holder Name", title: "Invalid Input")
               return
           }
           
           // Perform other mandatory field validations as before
           
           guard let accountsType = accountTypeTextField.text, !accountsType.isEmpty else {
               alert(message: "Please enter Account Type", title: "Mandatory Field")
               return
           }
           guard let bankCode = bankCodeTextField.text, !bankCode.isEmpty else {
               alert(message: "Please enter Bank Code", title: "Mandatory Field")
               return
           }
           guard let swiftCode = swiftCodeTextField.text, !swiftCode.isEmpty else {
               alert(message: "Please enter Swift Code", title: "Mandatory Field")
               return                }
        
        guard let selectedBankId = selectedBankId else {
            return
        }
       /* let autoRenewal = checkBoxButton.isSelected
                
                self.showHUD(message: "")
        APIManager().perform(BankDetails(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: BankDetails.Body(bank_id: String(selectedBankId), account_number: accountNumber, re_enter_account_number: reEnterAccountNumber, account_holder_name: holderName, account_type: accountsType,swift_code: swiftCode,bank_code: bankCode, auto_renewal: <#Bool#>))) { result in
                    self.hideHUD()
                }*/
        
        
        
        let selectedItem = String(bankSelectionTextField.text!)
        delegate?.data(text:selectedItem)
        dismiss(animated: true, completion: nil)
        
        
        let selectedItem2 = String(accountTypeTextField.text!)
        delegate?.datas(text:selectedItem2)
        dismiss(animated: true, completion: nil)
        removeAnimate()
        
        let selectedImage = bankLogoImage.image // Replace this with your actual image
        imageDelegate?.imageData(selectedImage)
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func closeButton(_ sender: Any) {
        let selectedItem = String(bankSelectionTextField.text!)
        delegate1?.data1(text:selectedItem)
        dismiss(animated: true, completion: nil)
        let selectedItem2 = String(accountTypeTextField.text!)
        delegate1?.data2(text:selectedItem2)
        dismiss(animated: true, completion: nil)
        removeAnimate()
      
    }
}
extension BankDetailsViewController: UITextFieldDelegate {
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
}
