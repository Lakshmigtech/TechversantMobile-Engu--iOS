//
//  DashBoardViewControllerViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 08/11/23.
//

import UIKit

class DashBoardViewController: UIViewController,dataSendDashBoardViewController,cancelSendDashBoardViewController,imageDelegateProtocol{
    
    func data(text: String) {
        bankNameLabel.text = text
        if bankNameLabel.text == ""{
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  -= 390
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
        }
        else{
            bankSelectView.isHidden = false
            secondBankView.isHidden = false
        }
    }
    func datas(text: String) {
        bankTypeLabel.text = text
        if bankTypeLabel.text == ""{
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  -= 390
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
        }
        else{
            bankSelectView.isHidden = false
            secondBankView.isHidden = false
        }
    }
    func data1(text: String) {
        bankNameLabel.text = ""
        if bankNameLabel.text == text{
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  -= 390
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
        }
        else{
            
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  -= 390
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
            
        }
    }
    func data2(text: String) {
        bankTypeLabel.text = ""
        if bankTypeLabel.text == text{
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  = 250
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
            
            
        }
        else{
            bankSelectView.isHidden = true
            secondBankView.isHidden = true
            mainViewHeight.constant  = 250
            bankAccountSeparateView.isHidden = true
            hiddenStack.isHidden = false
        }
    }
    @IBOutlet weak var personImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var scheduleWidth: NSLayoutConstraint!
    @IBOutlet weak var mainViewHeight: NSLayoutConstraint!
    @IBOutlet weak var secondBnakViewHeight: NSLayoutConstraint!
    @IBOutlet weak var bankViewHeight: NSLayoutConstraint!
    @IBOutlet weak var bankAccountSeparateView: UIView!
    @IBOutlet weak var separateView: UIView!
    @IBOutlet weak var settingsButton: UIButton!
    @IBOutlet weak var bankSelectView: UIView!
    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var bankAccountView: UIView!
    @IBOutlet weak var secondBankView: UIView!
    @IBOutlet weak var noBankStack: UIStackView!
    @IBOutlet weak var bankImage: UIImageView!
    @IBOutlet weak var bankNameLabel: UILabel!
    @IBOutlet weak var bankTypeLabel: UILabel!
    @IBOutlet weak var bankSideImage: UIImageView!
    @IBOutlet weak var bankSideLabel: UILabel!
    @IBOutlet weak var verificationStatusView: UIView!
    @IBOutlet weak var scheduleStack: UIStackView!
    @IBOutlet weak var appointmentStack: UIStackView!
    @IBOutlet weak var hiddenStack: UIStackView!
    @IBOutlet weak var moneyLabel: UILabel!
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var secondBankImage: UIImageView!
    @IBOutlet weak var secondBankName: UILabel!
    @IBOutlet weak var secondBankAccountType: UILabel!
    @IBOutlet weak var appointmentView: UIView!
    @IBOutlet weak var selectBankView: UIView!
    
    
    var isRetiree: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
        bankAccountView.applyCornerRadius(15)
        verificationStatusView.applyCornerRadius(15)
        settingsButton.addBorder(width: 1.0, color: UIColor.systemGray4)
        logoutButton.addBorder(width: 1.0, color: UIColor.systemGray4)
        settingsButton.applyCornerRadius(10)
        logoutButton.applyCornerRadius(10)
        bankAccountView.layer.cornerRadius = 20
        verificationStatusView.layer.cornerRadius = 20
        bankAccountView.applyShadow()
        verificationStatusView.applyShadow()
        bankSelectView.isHidden = false
        secondBankView.isHidden = true
        separateView.isHidden = true
        bankAccountSeparateView.isHidden = true
        hiddenStack.isHidden = true
       // mainViewHeight.constant  -= 280
       // updateNameLabel()
      //  updateNameLabelRetiree()
        
        //employeDetails()
        mainViewHeight.constant = 250
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(appointmentViewTapped))
           appointmentView.addGestureRecognizer(tapGesture)
           appointmentView.isUserInteractionEnabled = true
        
        // Add a tap gesture recognizer to selectBankView
           let tapGestures = UITapGestureRecognizer(target: self, action: #selector(selectBankViewTapped))
           selectBankView.addGestureRecognizer(tapGestures)
           selectBankView.isUserInteractionEnabled = true
        
        
    }
    @objc func appointmentViewTapped() {
        bookAppointment()
    }
    // New function to handle tap on selectBankView
    @objc func selectBankViewTapped() {
        selectBank()
    }
    
    @IBAction func addWalletAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "WalletBalanceViewController") as! WalletBalanceViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func bookAppointmentClicked(_ sender: Any) {
        bookAppointment()
    }
    @IBAction func selectBnakButtonClicked(_ sender: Any) {
        
       selectBank()
       
    }
      override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Call the EmployeeDetails API
        employeDetails()
    }
    func selectBank(){
        
        let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "BankDetailsViewController") as! BankDetailsViewController
        self.addChild(popup)
        popup.view.frame = self.view.frame
        self.view.addSubview(popup.view)
        popup.didMove(toParent: self)
        popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        // popup.modalTransitionStyle = .crossDissolve
        popup.delegate = self
        popup.delegate1 = self
        popup.imageDelegate = self
        bankSelectView.isHidden = false
        noBankStack.isHidden = true
        bankAccountSeparateView.isHidden = false
        mainViewHeight.constant = 250
        secondBankView.isHidden = false
        scheduleStack.alpha = 0.0
        scheduleWidth.constant = 75
        hiddenStack.isHidden = true
        
    }
    
    func bookAppointment(){
        
        let popup = UIStoryboard(name:Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DateSelectViewController") as! DateSelectViewController
                self.addChild(popup)
                popup.view.frame = self.view.frame
                self.view.addSubview(popup.view)
                popup.didMove(toParent: self)
                popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        
    }
    func employeDetails() {
        APIManager().perform(DashBoard(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            
            switch result {
            case .success(let data):
                print("API call succeeded with data: \(data)")
                if data.detail.status == "success" {
                    print("Status is success")
                    DispatchQueue.main.async {
                        // Show toast message
                        // let toast = ToastView(text: data.detail.message)
                        // toast.show(in: self.view, duration: 3.0)
                        print(data.detail.message)
                        self.nameLabel.text = data.detail.fullName
                        self.moneyLabel.text = data.detail.walletBalanceCurrency
                        self.balanceLabel.text = "\(data.detail.walletBalanceAmount)"
                        self.bankTypeLabel.text = data.detail.bankDetail?.accountType
                        self.bankNameLabel.text = data.detail.bankDetail?.bankName
                        if let bankImageUrl = URL(string: data.detail.bankDetail!.bankImage!) {
                            self.loadImages(from: bankImageUrl)
                        }
                        if let imageUrl = URL(string: data.detail.profilePic!) {
                            self.loadImage(from: imageUrl)
                        }
                    }
                } else if data.detail.status == "fail" {
                    print("Status is fail")
                    DispatchQueue.main.async {
                        if data.detail.tokenStatus == "valid" || data.detail.tokenStatus == "Invalid" {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        } else if data.detail.tokenStatus == "expired" {
                            self.callRefreshToken()
                        } else {
                            let toast = ToastView(text: "Failed to refresh token")
                            toast.show(in: self.view, duration: 3.0)
                        }
                    }
                } else {
                    print("Unexpected status: \(data.detail.status)")
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("API call failed with error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    // Handle API call failure
                    let toast = ToastView(text: error.localizedDescription)
                    toast.show(in: self.view, duration: 3.0)
                }
            }

        }
    }
    private func loadImage(from url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil, let image = UIImage(data: data) else {
                print("Failed to load image from URL: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            DispatchQueue.main.async {
                self.personImage.image = image
            }
        }
        task.resume()
    }
    private func loadImages(from url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil, let image = UIImage(data: data) else {
                print("Failed to load image from URL: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            DispatchQueue.main.async {
                self.bankImage.image = image
            }
        }
        task.resume()
    }
    func imageData(_ image: UIImage?) {
        // Use the received image as needed
        bankImage.image = image
    
    }
    @IBAction func viewProfileAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "EmployeeDetailViewController") as! EmployeeDetailViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func accountAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "AccountViewController") as! AccountViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func walletHistoryAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "WalletHistoryViewController") as! WalletHistoryViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func backButtonAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    func logoutCall(){

    }
    func failurecall(){
        
    }
    @IBAction func logoutButtonClicked(_ sender: Any) {
        self.showHUD(message: "")
        let logoutRequest = Logout(bearerToken: UserDefaults.standard.accessToken)
         APIManager().perform(logoutRequest) { result in
            self.hideHUD()
            // Your result handling code here
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: data.detail.message, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alert, animated: true, completion: nil)

                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                            let loginVc = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                            self.navigationController?.pushViewController(loginVc, animated: true)
                        }
                    }
                }
             else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "expired"{
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Fail")
                            // Handle the "fail" status here
                            let refresh_TokenVal = UserDefaults.standard.refreshToken
                            APIManager().perform(RefreshToken(queryParams: nil,body: RefreshToken.Body(refresh_token: refresh_TokenVal))) { result in
                                self.hideHUD()
                                // Your result handling code here
                                switch result {
                                case .success(let data):
                                    if data.detail.status == "success" {
                                        DispatchQueue.main.async {
                                            UserDefaults.standard.removeAccessToken()
                                            UserDefaults.standard.removeRefreshToken()
                                            UserDefaults.standard.accessToken = data.detail.access!
                                            UserDefaults.standard.refreshToken = data.detail.refresh!
                                            let logoutRequest = Logout(bearerToken: UserDefaults.standard.accessToken)
                                             APIManager().perform(logoutRequest) { result in
                                                self.hideHUD()
                                                // Your result handling code here
                                                switch result {
                                                case .success(let data):
                                                    if data.detail.status == "success" {
                                                        DispatchQueue.main.async {
                                                            let alert = UIAlertController(title: "Alert", message: data.detail.message, preferredStyle: .alert)
                                                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                                            self.present(alert, animated: true, completion: nil)

                                                            
                                                            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                                                                let loginVc = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                                                                self.navigationController?.pushViewController(loginVc, animated: true)
                                                            }
                                                        }
                                                    }
                                                    else if data.detail.status == "fail" {
                                                        DispatchQueue.main.async {
                                                            let toast = ToastView(text: data.detail.message)
                                                            toast.show(in: self.view, duration: 5.0)
                                                            // Handle the "fail" status here if needed
                                                        }
                                                    } else {
                                                        DispatchQueue.main.async {
                                                            self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                                                            // Handle other unexpected statuses
                                                        }
                                                    }
                                                case .failure(let error):
                                                    print("errrorrrs", error)
                                                    DispatchQueue.main.async {
                                                        var errorMessage = "An error occurred. Please try again later."

                                                        // Check specific error types and provide more informative messages
                                                        if let apiError = error as? APIErrorFormat {
                                                            switch apiError {
                                                            case .networkError:
                                                                errorMessage = "Network error. Please check your internet connection."
                                                            case .invalidResponse:
                                                                errorMessage = "Invalid response from the server. Please try again."
                                                            // Add more cases as needed
                                                            }
                                                        }

                                                        self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                                                    }
                                                }
                                            }
                                        }
                                    } else if data.detail.status == "fail" {
                                        DispatchQueue.main.async {
                                            self.alert(message: data.detail.message, title: "Failed Login")
                                            // Handle the "fail" status here
                                        }
                                    } else {
                                        DispatchQueue.main.async {
                                            self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                                            // Handle other unexpected statuses
                                        }
                                    }
                                case .failure(let error):
                                    print("errrorrrs", error)
                                    DispatchQueue.main.async {
                                        var errorMessage = "An error occurred. Please try again later."

                                        // Check specific error types and provide more informative messages
                                        if let apiError = error as? APIErrorFormat {
                                            switch apiError {
                                            case .networkError:
                                                errorMessage = "Network error. Please check your internet connection."
                                            case .invalidResponse:
                                                errorMessage = "Invalid response from the server. Please try again."
                                            // Add more cases as needed
                                            }
                                        }

                                        self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                                    }
                                }
                            }
                        }
                    }
                   
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."

                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                        // Add more cases as needed
                        }
                    }

                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }

        }
    }
