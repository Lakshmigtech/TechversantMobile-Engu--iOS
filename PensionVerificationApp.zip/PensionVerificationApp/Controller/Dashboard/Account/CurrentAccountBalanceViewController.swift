//
//  CurrentAccountBalanceViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 08/11/23.
//

import UIKit

class CurrentAccountBalanceViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WalletTableViewCell",for: indexPath) as? WalletTableViewCell
        cell?.dateLabel.text = date[indexPath.row]
        cell?.upiLabel.text = upi[indexPath.row]
        cell?.topUpLabel.text = amountMode[indexPath.row]
        cell?.amountLabel.text = amount[indexPath.row]
        cell?.creditLabel.text = credit[indexPath.row]
        if indexPath.item == 1 {
            cell?.amountLabel.textColor = UIColor.red
        }
        else if indexPath.item == 2{
            cell?.amountLabel.textColor = UIColor.red
            
        }
        cell?.view.layer.cornerRadius = 10
        cell?.view.applyShadow()
        cell?.selectionStyle = .none
        return cell!
    }
    var date:[String] = ["15/02/2022","1/7/2023","12/7/2023","12/4/2023"]
    var upi:[String] = ["UPI/123564789652369/@chidi","UPI/123564789652369/@chidi","UPI/123564789652369/@chidi","UPI/123564789652369/@chidi"]
    
    var amountMode:[String] = ["Pension Received","Widthdrawal through bank ATM","Widthdrawal through bank ATM","Pension Received"]
    var amount:[String] = ["N1200","-N150","-N100","N1500"]
    var credit:[String] = ["Credit","Credit","Credit","Credit"]

    @IBOutlet weak var currentAccountBalanceView: UIView!
    @IBOutlet weak var buttonView: UIView!
    @IBOutlet weak var CurrentAccountTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.CurrentAccountTableView.register(UINib(nibName: "WalletTableViewCell", bundle: nil), forCellReuseIdentifier: "WalletTableViewCell")
        CurrentAccountTableView.delegate = self
        CurrentAccountTableView.dataSource = self
        CurrentAccountTableView.separatorStyle = .none
        buttonView.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        currentAccountBalanceView.backgroundColor =
            UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        buttonView.applyCornerRadius(10)
    }
    @IBAction func statementButton(_ sender: Any) {
        let pdfData = createPDFData()
                savePDFToDocuments(pdfData: pdfData)
    }
    func createPDFData() -> Data {
            let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 612, height: 792))
            let pdfData = pdfRenderer.pdfData { (context) in
                for pageIndex in 0..<self.CurrentAccountTableView.numberOfSections {
                    let headerRect = CGRect(x: 0, y: CGFloat(pageIndex) * 792, width: 612, height: 50)
                    let footerRect = CGRect(x: 0, y: CGFloat(pageIndex + 1) * 792 - 50, width: 612, height: 50)

                    context.beginPage()
                    self.drawTableHeader(headerRect, forSection: pageIndex)
                    self.CurrentAccountTableView.scrollRectToVisible(CGRect(x: 0, y: 0, width: 1, height: 1), animated: false)
                    self.CurrentAccountTableView.layer.render(in: context.cgContext)

                    // Draw table footer if needed
                    if footerRect.origin.y < self.CurrentAccountTableView.contentSize.height {
                        self.drawTableFooter(footerRect, forSection: pageIndex)
                    }
                }
            }
            return pdfData
        }

        func drawTableHeader(_ rect: CGRect, forSection section: Int) {
            let headerText = "Section \(section + 1)"
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributes = [
                NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 16),
                NSAttributedString.Key.paragraphStyle: paragraphStyle
            ]
            headerText.draw(with: rect, options: .usesLineFragmentOrigin, attributes: attributes, context: nil)
        }

        func drawTableFooter(_ rect: CGRect, forSection section: Int) {
            let footerText = "Page \(section + 1)"
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributes = [
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12),
                NSAttributedString.Key.paragraphStyle: paragraphStyle
            ]
            footerText.draw(with: rect, options: .usesLineFragmentOrigin, attributes: attributes, context: nil)
        }

        func savePDFToDocuments(pdfData: Data) {
            let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let pdfPath = "\(documentsPath)/output.pdf"
            FileManager.default.createFile(atPath: pdfPath, contents: pdfData, attributes: nil)
            print("PDF saved to: \(pdfPath)")
        }
    
    @IBAction func CurrentBalanceBackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
