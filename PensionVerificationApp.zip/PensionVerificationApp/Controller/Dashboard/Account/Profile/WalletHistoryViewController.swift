//
//  WalletHistoryViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/11/23..
//

import UIKit

class WalletHistoryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var walletTransactionHistoryBackButton: UIButton!
    @IBOutlet weak var walletTableView: UITableView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var amountLabel: UILabel!
    
    let cellHeight: CGFloat = 80
    let cellSpacing: CGFloat = 10
    
    var transactions: [Transaction] = []
    var walletBalance: Double = 0.0 // Add this property
    
    @IBAction func backAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Register the nib for the custom cell
               walletTableView?.register(UINib(nibName: "WalletTableViewCell", bundle: nil), forCellReuseIdentifier: "WalletTableViewCell")
               
               // Set the delegate and datasource
               walletTableView?.delegate = self
               walletTableView?.dataSource = self
               
               // Style configurations
               walletTableView?.backgroundColor = UIColor.clear
               walletTableView?.separatorStyle = .none
               topView?.layer.cornerRadius = 35
               
               // Load transaction history
               transactionHistory()
               updateWalletBalance(walletBalance)
    }
    private func updateWalletBalance(_ balance: Double) {
           walletBalance = balance
           amountLabel.text = "\(walletBalance)"
       }
    func transactionHistory(){
            
            let queryParams = TransactionHistoryRequest.QueryParams(page: 1, limit: 5)
            APIManager().perform(TransactionHistoryRequest(bearerToken: UserDefaults.standard.accessToken, queryParams: queryParams, body: nil)) { [self] result in
                
                switch result {
                case .success(let data):
                    print("API call succeeded with data: \(data)")
                    
                    DispatchQueue.main.async { [self] in
                        DispatchQueue.main.async {
                            // Assign the transaction data from the response
                            self.transactions = data.transactions
                            // Reload the table view to display the transactions
                           
                            walletTableView.reloadData()
                        }
                    }
                
            case .failure(let error):
                handleError(error)
            }
        }
                }
             
        
        func handleError(_ error: Error) {
            print("API call failed with error: \(error.localizedDescription)")
            DispatchQueue.main.async {
                let toast = ToastView(text: error.localizedDescription)
                toast.show(in: self.view, duration: 3.0)
            }
        }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return transactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WalletTableViewCell",for: indexPath) as? WalletTableViewCell
        let transaction = transactions[indexPath.row]
                // Configure the cell with transaction data
                      cell?.dateLabel.text = transaction.transactionDate
                      cell?.upiLabel.text = "\(transaction.stripeTransactionID ?? "")"
                      cell?.amountLabel.text = "\(transaction.amount)"
                     
                      
                cell?.view.layer.cornerRadius = 10
                cell?.view.applyShadow()
                cell?.selectionStyle = .none
                return cell!
                
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
        
    }
    
}
