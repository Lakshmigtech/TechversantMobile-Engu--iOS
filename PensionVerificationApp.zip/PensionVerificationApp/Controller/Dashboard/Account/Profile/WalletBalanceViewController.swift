//
//  WalletBalanceViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 08/11/23.
//

import UIKit

class WalletBalanceViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var bankView: UIView!
    @IBOutlet weak var bankSelectTextField: UITextField!
    @IBOutlet weak var bankTableView: UITableView!
    @IBOutlet weak var topWalletView: UIView!
    @IBOutlet weak var TopUpWalletButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var EnterAmountView: UIView!
    @IBOutlet weak var selectYourBankView: UIView!
    @IBOutlet weak var walletHistoryView: UIView!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var amountTextfield: UITextField!
    @IBOutlet weak var walletBalanceLabel: UILabel!
    @IBOutlet weak var walletBalanceCurrency: UILabel!
    
    var isToggled = false
    var bankName: [String] = []
    private var checkoutURL: String?
    private var selectedBankID: Int?  // Store the selected bank ID
    private var currentWalletBalance: Double = 0.0 // Store the current wallet balance
    private var walletBalanceCurrencys: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        EnterAmountView.addBorder(width: 1, color: UIColor.systemGray4)
        selectYourBankView.addBorder(width: 1, color: UIColor.systemGray4)
        walletHistoryView.addBorder(width: 1, color: UIColor.systemGray4)
        TopUpWalletButton.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        topWalletView.backgroundColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        backButton.backgroundColor = UIColor(displayP3Red: 226/255, green: 255/255, blue: 239/255, alpha: 1.0)
        topWalletView.layer.cornerRadius = 10
        backButton.layer.cornerRadius = 10
        bankTableView.delegate = self
        bankTableView.dataSource = self
        bankView.isHidden = true
        employeDetails()
    }
    @IBAction func backAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    @IBAction func checkButtonClicked(_ sender: Any) {
        checkButton.isSelected = !checkButton.isSelected
        
        if checkButton.isSelected {
            checkButton.setImage(UIImage(systemName: "checkmark.square"), for: .normal)
            checkButton.tintColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        } else {
            checkButton.setImage(UIImage(systemName: "square"), for: .normal)
            checkButton.tintColor = UIColor(displayP3Red: 1/255, green: 134/255, blue: 82/255, alpha: 1.0)
        }
    }
    @IBAction func selectBankButtonClicked(_ sender: Any) {
        employeDetails()
        isToggled.toggle()
        
        if isToggled {
            bankView.isHidden = false
            
        } else {
            bankView.isHidden = true
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bankName.count  // Ensure this is the count of the bank names from the API response
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BanksTableViewCell
        cell.bankNameLabel.text = bankName[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           // Update the text field with the selected bank name
           bankSelectTextField.text = bankName[indexPath.row]
           // Hide the bank view
           bankView.isHidden = true
           // Reset the toggle
           isToggled = false
       }
    func employeDetails() {
        APIManager().perform(DashBoard(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [weak self] result in
            
            guard let self = self else { return } // Capture self weakly to avoid retain cycles

            switch result {
            case .success(let data):
                print("API call succeeded with data: \(data)")
                if data.detail.status == "success" {
                    print("Status is success")
                    DispatchQueue.main.async {
                        // Safely unwrap bankDetail and bankName
                        if let bankDetail = data.detail.bankDetail, let bankNameString = bankDetail.bankName {
                            self.bankName = [bankNameString]  // Only assign if bank name is not nil
                            self.selectedBankID = bankDetail.bankID
                        }
                        self.updateWalletBalance(Double(data.detail.walletBalanceAmount ?? 0))
                        self.walletBalanceCurrencys = data.detail.walletBalanceCurrency
                        self.walletBalanceCurrency.text = self.walletBalanceCurrencys
                        
                        // Reload the table view to display the updated bank names
                        self.bankTableView.reloadData()
                    }
                } else {
                    self.handleFailureStatus(data)
                }
            case .failure(let error):
                self.handleError(error)
            }
        }
    }


    func handleFailureStatus(_ data: DashBoardAPIResponse) {
        print("Status is fail")
        DispatchQueue.main.async {
            if data.detail.tokenStatus == "valid" || data.detail.tokenStatus.lowercased() == "invalid" {
                let toast = ToastView(text: data.detail.message)
                toast.show(in: self.view, duration: 3.0)
            } else if data.detail.tokenStatus == "expired" {
                self.callRefreshToken()
            } else {
                let toast = ToastView(text: "Failed to refresh token")
                toast.show(in: self.view, duration: 3.0)
            }
        }
    }

    func handleError(_ error: Error) {
        print("API call failed with error: \(error.localizedDescription)")
        DispatchQueue.main.async {
            let toast = ToastView(text: error.localizedDescription)
            toast.show(in: self.view, duration: 3.0)
        }
    }


    @IBAction func topUpButtonClicked(_ sender: Any) {
        // Ensure the amountTextfield has a valid value
                  guard let amountText = amountTextfield.text, let amount = Double(amountText) else {
                      print("Invalid amount entered")
                      return
                  }
        // Ensure that the bank ID is available
                     guard let bankID = selectedBankID else {
                         print("Bank ID not selected")
                         return
                     }
                  // Prepare WalletDetails using the amount from the text field
                  let walletDetails = WalletDetails.Body(
                    userId: UserDefaults.standard.userId,
                      bankId: bankID,
                      amount: amount, // Pass the amount from the text field
                      currency: "ngn",
                      description: "Top-up for user wallet"
                  )
               
        let walletRequest = WalletDetails(bearerToken:  UserDefaults.standard.accessToken, body: walletDetails)
                   // Call API to get Checkout URL
               showHUD(message: "")
               APIManager.shared.perform(walletRequest) { [weak self] (result: Result<WalletResponse, Error>) in
                   self!.hideHUD()
                   switch result {
                  
                   case .success(let walletResponse):
                       // Ensure this code runs on the main thread
                       DispatchQueue.main.async {
                           self?.checkoutURL = walletResponse.checkoutURL
                           self?.presentStripePaymentViewController()
                           self?.amountTextfield.text = ""
                       }
                       
                   case .failure(let error):
                       print("Error creating PaymentIntent: \(error.localizedDescription)")
                   }
               }
           }
           
           private func presentStripePaymentViewController() {
               guard let checkoutURL = checkoutURL else {
                   print("Checkout URL is missing or invalid")
                   return
               }
               
               let stripePaymentVC = StripePaymentViewController()
               stripePaymentVC.checkoutURL = checkoutURL
               
               // Set up the closure to receive the payment status message
               stripePaymentVC.onPaymentStatusReceived = { [weak self] message in
                   self?.showAlert(message: message)
                  DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                   self?.employeDetails()  // Call employeDetails to refresh wallet balance
                     }
                   
               }
              
               stripePaymentVC.modalPresentationStyle = .fullScreen
               present(stripePaymentVC, animated: true, completion: nil)
           }
    private func updateWalletBalance(_ balance: Double) {
            currentWalletBalance = balance
            walletBalanceLabel.text = "\(currentWalletBalance)"
        }
           
           // Function to display an alert with the received message
           private func showAlert(message: String) {
               DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                   let alert = UIAlertController(title: "Payment Status", message: message, preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                   self.present(alert, animated: true, completion: nil)
               }
           }
    
    
    @IBAction func walletHistoryButtonTapped(_ sender: Any) {
        
        if let nextViewController = storyboard?.instantiateViewController(withIdentifier: "WalletHistoryViewController") as? WalletHistoryViewController {
            // Pass the wallet balance
            nextViewController.walletBalance = currentWalletBalance
            navigationController?.pushViewController(nextViewController, animated: true)
        }
        
        
    }
    

    }
    
    

