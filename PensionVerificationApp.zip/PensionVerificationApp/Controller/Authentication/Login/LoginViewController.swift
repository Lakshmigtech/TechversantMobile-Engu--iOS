//
//  LoginViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//

import UIKit
enum APIErrorFormat: Error {
    case networkError
    case invalidResponse
   
    // Add more cases as needed
}
class LoginViewController: UIViewController {
    //MARK: -------------------- Outlet --------------------
    @IBOutlet weak var contentScrollView: UIScrollView!
    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var countryCodeButton: UIButton!
    @IBOutlet weak var countryCodeLabel: UILabel!
    @IBOutlet weak var phonenumberTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordShowButton: UIButton!
    
    //MARK: -------------------- Life Cycle Method --------------------
    var countriesViewController = CountriesViewController()
    var countryCode: String?
    var isPasswordHidden = true
    
    // Define a variable to store the initial text of nextofKinPhoneTextField
    var initialText = ""
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initalSetup()
        setupCountryPicker()
        passwordShowButton.setTitle("", for: .normal)
        resetCountryCode()
        phonenumberTextField.delegate = self
        passwordTextField.delegate = self
        emailTextField.delegate = self
        phonenumberTextField.delegate = self
     
        
        phonenumberTextField.keyboardType = .numberPad  // Set the keyboard type to number pad
        phonenumberTextField.returnKeyType = .done  // Optionally set the return key type
        
        // Add gestures to emailTextField
          addTapGestures(to: emailTextField)
          
          // Add gestures to phoneNumberTextField
          addTapGestures(to: phonenumberTextField)
          
          // Add gestures to passwordTextField
          addTapGestures(to: passwordTextField)
      }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Handle special logic for nextofKinPhoneTextField
           if textField == phonenumberTextField {
               // Set initial text if it hasn't been set yet
               if initialText.isEmpty {
                   initialText = textField.text ?? ""
               }
               
               // Detect backspace (if the replacement string is empty)
               if string.isEmpty {
                   // Prevent deleting initial text
                   if range.location < initialText.count {
                       return false
                   }
               }
           }
          
           return true
       }
    

      func addTapGestures(to textField: UITextField) {
          // Add Tap Gesture Recognizer
          let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
          tapGesture.numberOfTapsRequired = 1 // Single tap
          textField.addGestureRecognizer(tapGesture)
          
          // Add Double Tap Gesture Recognizer
          let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
          doubleTapGesture.numberOfTapsRequired = 2 // Double tap
          textField.addGestureRecognizer(doubleTapGesture)
          
          // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
          tapGesture.require(toFail: doubleTapGesture)
      }

      @objc func handleTap(gesture: UITapGestureRecognizer) {
          guard let textField = gesture.view as? UITextField else { return }
          
          // Make sure the text field becomes the first responder
          textField.becomeFirstResponder()
          
          // Calculate the location of the tap
          let location = gesture.location(in: textField)
          
          // Get the closest position to the tap
          if let position = textField.closestPosition(to: location) {
              textField.selectedTextRange = textField.textRange(from: position, to: position)
          }
      }

      @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
          guard let textField = gesture.view as? UITextField else { return }
          
          // Make sure the text field becomes the first responder
          textField.becomeFirstResponder()
          
          // Select the entire text in the text field
          if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
              textField.selectedTextRange = textRange
          }
      }
    func accountStatusApi() {
        APIManager().perform(AccountStatus(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            
            switch result {
            case .success(let data):
               
                if data.detail.status == "success" {
                   
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                        let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
                        self.addChild(popup)
                        popup.view.frame = self.view.frame
                        self.view.addSubview(popup.view)
                        popup.didMove(toParent: self)
                        popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
   
                }
                } else if data.detail.status == "fail" {
                    DispatchQueue.main.async {
                        let popup = UIStoryboard(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "ServiceViewController") as! ServiceViewController
                        self.addChild(popup)
                        popup.view.frame = self.view.frame
                        self.view.addSubview(popup.view)
                        popup.didMove(toParent: self)
                        popup.modalPresentationStyle = .overCurrentContext
                    }
                } else {
                    print("Unexpected status: \(data.detail.status)")
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("API call failed with error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    // Handle API call failure
                    let toast = ToastView(text: error.localizedDescription)
                    toast.show(in: self.view, duration: 3.0)
                }
            }

        }
    }
   /* func userGovetStatus() {
        APIManager().perform(UserGovtStatus(bearerToken: UserDefaults.standard.accessToken, queryParams: nil, body: nil)) { [self] result in
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    if data.detail.userGovtVerified == "True"{
                       
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                            let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
       
                    }
                    }else if data.detail.userGovtVerified == "False"{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
                            let popup = UIStoryboard(name: Storyboards.Dashboard, bundle: nil).instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
                            self.addChild(popup)
                            popup.view.frame = self.view.frame
                            self.view.addSubview(popup.view)
                            popup.didMove(toParent: self)
                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
       
                    }
//                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Delay
//                            let popup = UIStoryboard(name: Storyboards.Services, bundle: nil).instantiateViewController(withIdentifier: "NotGovtVerifiedViewController") as! NotGovtVerifiedViewController
//                            self.addChild(popup)
//                            popup.view.frame = self.view.frame
//                            self.view.addSubview(popup.view)
//                            popup.didMove(toParent: self)
//                            popup.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
//                         
//                        }
                    }
                     
                } else if data.detail.status == "fail" {
                    if data.detail.tokenStatus == "valid" {
                        
                    } else if data.detail.tokenStatus == "expired" {
                        DispatchQueue.main.async {
                            self.callRefreshToken()
                        }
                    } else if data.detail.tokenStatus == "Invalid" {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: data.detail.message)
                            toast.show(in: self.view, duration: 3.0)
                        }
                    } else {
                        DispatchQueue.main.async {
                            let toast = ToastView(text: "Failed to refresh token")
                            toast.show(in: self.view, duration: 3.0)
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        let toast = ToastView(text: "Unexpected status: \(data.detail.status)")
                        toast.show(in: self.view, duration: 3.0)
                        // Handle other unexpected statuses
                    }
                }

            case .failure(let error):
                // Handle API call failure
                DispatchQueue.main.async {
                    let popup = UIStoryboard(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "ServiceViewController") as! ServiceViewController
                    self.addChild(popup)
                    popup.view.frame = self.view.frame
                    self.view.addSubview(popup.view)
                    popup.didMove(toParent: self)
                    popup.modalPresentationStyle = .overCurrentContext
                }
            }
        }
    }*/

    func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
      
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    // MARK:- Keyboard delegate Methods
    /// method will be call when keyboard will appear
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
    // method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    
    
    @IBAction func passwordShowButtonAction(_ sender: Any) {
        isPasswordHidden.toggle()
        if isPasswordHidden {
            passwordTextField.isSecureTextEntry = true
            passwordShowButton.setImage(UIImage(named: "closedEye"), for: .normal)
        } else {
            passwordTextField.isSecureTextEntry = false
            passwordShowButton.setImage(UIImage(named: "openEye"), for: .normal)
        }
    }
    
    @IBAction func countryCodeButtonAction(_ sender: Any) {
        DispatchQueue.main.async {
          CountriesViewController.show(countriesViewController: self.countriesViewController, toVar: self)
        }
    }
    func setupCountryPicker(){
        self.countriesViewController = CountriesViewController()
        self.countriesViewController.delegate = self
        self.countriesViewController.allowMultipleSelection = false
        if let info = self.getCountryAndName() {
            countryCode = info.countryCode!
           // self.lblFlag.text = info.countryFlag!
           // self.countryCodeLabel.text = "("+info.countryShortName!+")"+info.countryCode!
            self.countryCodeLabel.text = "("+info.countryShortName!+")"
            self.phonenumberTextField.text = info.countryCode!
        }
    }
    //Method is used for getiing country data which is stored in json file
    private func getCountryAndName(_ countryParam: String? = nil) -> CountryModel? {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonObj = JSON(data)
                let countryData = CountryListModel.init(jsonObj.arrayValue)
                let locale: Locale = Locale.current
                var countryCode: String?
                if countryParam != nil {
                    countryCode = countryParam
                } else {
                    countryCode = locale.regionCode
                }
                let currentInfo = countryData.country?.filter({ (cm) -> Bool in
                    return cm.countryShortName?.lowercased() == countryCode?.lowercased()
                })
                
                if currentInfo!.count > 0 {
                    return currentInfo?.first
                } else {
                    return nil
                }
                
            } catch {
                // handle error
            }
        }
        return nil
    }
    @IBAction func forgetPasswordAction(_ sender: Any) {
        let forgetVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "ForgetPasswordViewController") as! ForgetPasswordViewController
        self.navigationController?.pushViewController(forgetVC, animated: true)
    }
    @IBAction func signUpAction(_ sender: Any) {
        let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        self.navigationController?.pushViewController(signUpVC, animated: true)
    }
    @IBAction func loginAction(_ sender: Any) {
        view.endEditing(true)
        let email = emailTextField.text ?? ""
        let phoneNumber = phonenumberTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        if email.isEmpty && phoneNumber.isEmpty {
            alert(message: "Please type email or phone number.", title: "Mandatory Field")
        } else if !email.isEmpty && !email.isValidEmail {
            alert(message: "Please enter a valid email.", title: "Mandatory Field")
             
        } 
//        else if !phoneNumber.isEmpty && !phoneNumber.isValidPhone {
//            alert(message: "Please enter a valid phone number.", title: "Mandatory Field")
//                 
//        } 
        else if password.isEmpty && !password.isValidPassword{
            alert(message: "Please type password.", title: "Mandatory Field")
                 
               }
        else{
            // Check if either email or phone number is provided
//            if !email.isEmpty || !phoneNumber.isEmpty {
//                alert(message: "Please provide a valid Email Address or phone number", title: "Email Validation")
//                return
//            }
    }
//        guard let email = emailTextField.text, !email.isEmpty ||
//              let phoneNumberVal = phoneNumberTextField.text, !phoneNumber.isEmpty else {
//            // Handle error, either email or phone number should be provided
//            return
//        }
        // Assuming Login.Body is a struct or class with emailorphone and password properties
        let loginParams: Login.Body
        // Set email or phone and password
        if let email = emailTextField.text, !email.isEmpty {
            loginParams = Login.Body(emailorphone: email, password: passwordTextField.text ?? "")
        } else {
            loginParams = Login.Body(emailorphone: phoneNumber, password: passwordTextField.text ?? "")
        }
        
        self.showHUD(message: "Logging...")
        APIManager().perform(Login(queryParams: nil, body: loginParams)) { [self] result in
            self.hideHUD()
            // Your result handling code here
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    UserDefaults.standard.accessToken = data.detail.accessToken!
                    UserDefaults.standard.refreshToken = data.detail.refreshToken!
                    UserDefaults.standard.userId = data.detail.userID!
                    
                    let hasCalledBankApi = UserDefaults.standard.bool(forKey: "bankApiCalled")

                    DispatchQueue.main.async {
                    //let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "ServiceViewController") as! ServiceViewController
                    //self.navigationController?.pushViewController(signUpVC, animated: true)
                 
                        
                        self.accountStatusApi()
                        
                     
                        
                    }
                } else if data.detail.status == "fail"{
                    
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message, title: "Failed Login")
                        // Handle the "fail" status here
                    }
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    } else if let nsError = error as NSError? {
                        // Check if the error is related to being offline
                        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                            errorMessage = "You are offline. Please check your internet connection."
                        }
                    }
                    
                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }
    }
}

extension LoginViewController: CountriesViewControllerDelegate,UITextFieldDelegate {
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountries countries: [Country]) {
        
        countries.forEach { co in
            //            Logger.println(co.name)
        }
    }
    func countriesViewControllerDidCancel(_ countriesViewController: CountriesViewController) {
        
        //        Logger.println("user hass been tap cancel")
        
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountry country: Country) {
        if let info = self.getCountryAndName(country.countryCode) {
            countryCode = info.countryCode!
          //  self.lblFlag.text = info.countryFlag!
            self.countryCodeLabel.text = "("+info.countryShortName!+")"
            self.phonenumberTextField.text = info.countryCode!
        }
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didUnselectCountry country: Country) {
        
        //        Logger.println(country.name + " unselected")
        
    }
    func resetCountryCode() {
        self.phonenumberTextField.text = "+91"
        self.countryCodeLabel.text = "(IN)"
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       textField.resignFirstResponder()
    }
    
}

