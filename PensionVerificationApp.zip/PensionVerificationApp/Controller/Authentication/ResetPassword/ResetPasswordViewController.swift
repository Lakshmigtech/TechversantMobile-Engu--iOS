//
//  ResetPasswordViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 27/11/23.
//

import UIKit

class ResetPasswordViewController: UIViewController {
    var resetTokenVal : String?
   var verifyOtpVal : String?
    @IBOutlet weak var newPasswordTextFiled: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        initalSetup()
        newPasswordTextFiled.delegate = self
        confirmPasswordTextField.delegate = self
    
        addTapGestures(to: newPasswordTextFiled)
        addTapGestures(to: confirmPasswordTextField)

    }

    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
  
        
        
        
    func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
      
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    // MARK:- Keyboard delegate Methods
    /// method will be call when keyboard will appear
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
    // method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    @IBAction func submitAction(_ sender: Any)
    {
            
            guard let password = newPasswordTextFiled.text, !password.isEmpty else {
                alert(message: "Please enter Password", title: "Mandatory Field")
                return
            }
            if !password.isValidPassword {
                alert(message: "Pasword must contain at least one uppercase letter, one lowercase letter, one numeric digit and at least 8 characters long", title: "Password Validation")
                return
            }
            guard let confirmPassword = confirmPasswordTextField.text, !confirmPassword.isEmpty else {
                alert(message: "Please enter Re-enter Password", title: "Mandatory Field")
                return
            }
            if password != confirmPassword {
                alert(message: "Password & Re-enter Password mis-match", title: "Password Validation")
                return
            }
            APIManager().perform(ResetPassword(queryParams: nil, body: ResetPassword.Body(otp: verifyOtpVal ?? "", token: resetTokenVal ?? "", password: password))) { result in
                self.hideHUD()
                // Your result handling code here
                switch result {
                case .success(let data):
                    if data.detail.status == "success" {
                        DispatchQueue.main.async {
                            self.showAlert(title: "Success", message: data.detail.message, options: "Ok") { option in
                                let loginVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                                self.navigationController?.pushViewController(loginVC, animated: true)
                            }
                        }
                    } else if data.detail.status == "fail" {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Failed Login")
                            // Handle the "fail" status here
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                            // Handle other unexpected statuses
                        }
                    }
                case .failure(let error):
                    print("errrorrrs", error)
                    DispatchQueue.main.async {
                        var errorMessage = "An error occurred. Please try again later."
                        
                        // Check specific error types and provide more informative messages
                        if let apiError = error as? APIErrorFormat {
                            switch apiError {
                            case .networkError:
                                errorMessage = "Network error. Please check your internet connection."
                            case .invalidResponse:
                                errorMessage = "Invalid response from the server. Please try again."
                                // Add more cases as needed
                            }
                        } else if let nsError = error as NSError? {
                            // Check if the error is related to being offline
                            if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                                errorMessage = "You are offline. Please check your internet connection."
                            }
                        }
                        
                        self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                    }
                }
            }
        }
    
    
    @IBAction func backAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Authentication", bundle: nil) // "Main" is the default name of the storyboard, change it if needed
                // Instantiate the destination view controller using its identifier
                if let vc = storyboard.instantiateViewController(withIdentifier: "ForgetPasswordViewController") as? ForgetPasswordViewController {
                    // Push the destination view controller onto the navigation stack
                    self.navigationController?.popViewController(animated: true)
    }
}
}
extension ResetPasswordViewController: UITextFieldDelegate {
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
}
