//
//  ForgetPasswordViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//

import UIKit

class ForgetPasswordViewController: UIViewController {
    //MARK: -------------------- Outlet --------------------
    var tokenVal : String?
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var countryCodeButton: UIButton!
    @IBOutlet weak var countryCodeLabel: UILabel!
   
    //MARK: -------------------- Life Cycle Method --------------------
    var countriesViewController = CountriesViewController()
    var countryCode: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        initalSetup()
        setupCountryPicker()
        phoneNumberTextField.delegate = self
        emailTextField.delegate = self
        addTapGestures(to: phoneNumberTextField)
        addTapGestures(to: emailTextField)

    }

    func addTapGestures(to textField: UITextField) {
        // Add Tap Gesture Recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
        tapGesture.numberOfTapsRequired = 1 // Single tap
        textField.addGestureRecognizer(tapGesture)
        
        // Add Double Tap Gesture Recognizer
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2 // Double tap
        textField.addGestureRecognizer(doubleTapGesture)
        
        // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
        tapGesture.require(toFail: doubleTapGesture)
    }

    @objc func handleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Calculate the location of the tap
        let location = gesture.location(in: textField)
        
        // Get the closest position to the tap
        if let position = textField.closestPosition(to: location) {
            textField.selectedTextRange = textField.textRange(from: position, to: position)
        }
    }

    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
        guard let textField = gesture.view as? UITextField else { return }
        
        // Make sure the text field becomes the first responder
        textField.becomeFirstResponder()
        
        // Select the entire text in the text field
        if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
            textField.selectedTextRange = textRange
        }
    }
  
    
    
    func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
      
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    // MARK:- Keyboard delegate Methods
    /// method will be call when keyboard will appear
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
    // method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    @IBAction func sendRequestAction(_ sender: Any) 
    {
        /*  let email = emailTextField.text ?? ""
         let phoneNumber = phoneNumberTextField.text ?? ""
         if email.isEmpty && phoneNumber.isEmpty {
         alert(message: "Please type email or phone number.", title: "Mandatory Field")
         } else if !email.isEmpty && !email.isValidEmail {
         alert(message: "Please enter a valid email.", title: "Mandatory Field")
         
         }
         else if !phoneNumber.isEmpty && !phoneNumber.isValidPhone {
         alert(message: "Please enter a valid phone number.", title: "Mandatory Field")
         
         #imageLiteral(resourceName: "simulator_screenshot_1A6DEEC3-549A-44A0-A190-F2DAA7E564C4.png")
         }
         else{
         
         let emailOrPhone = !email.isEmpty ? email : phoneNumber
         UserDefaults.standard.set(emailOrPhone, forKey: "emailOrPhone") // Save value to UserDefaults
         
         // Proceed with API call and navigation as before
         
         
         }
         // Assuming Login.Body is a struct or class with emailorphone and password properties
         let loginParams: forgetPassword.Body
         
         // Set email or phone and password
         if let email = emailTextField.text, !email.isEmpty {
         loginParams = forgetPassword.Body(emailorphone:email)
         } else {
         loginParams = forgetPassword.Body(emailorphone:phoneNumber)
         }
         APIManager().perform(forgetPassword(queryParams: nil, body: loginParams)) { result in
         self.hideHUD()
         // Your result handling code here
         switch result {
         case .success(let data):
         if data.detail.status == "success"{
         DispatchQueue.main.async {
         self.showAlert(title: "Success", message: data.detail.message, options: "Ok"){ [self] option in
         let verifyEmailVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
         verifyEmailVC.isFromForget = true
         tokenVal = data.detail.uniqueToken
         verifyEmailVC.verifyTokenVal = tokenVal
         verifyEmailVC.emailValue = email
         self.navigationController?.pushViewController(verifyEmailVC, animated: true)
         }
         }
         }else if data.detail.status == "fail" {
         DispatchQueue.main.async {
         self.alert(message: data.detail.message, title: "Fail")
         // Handle the "fail" status here
         }
         }
         else {
         DispatchQueue.main.async {
         self.alert(message: data.detail.message, title: "Exception")
         }
         }
         case .failure(let error):
         print("errrorrrs", error)
         DispatchQueue.main.async {
         var errorMessage = "An error occurred. Please try again later."
         
         // Check specific error types and provide more informative messages
         if let apiError = error as? APIErrorFormat {
         switch apiError {
         case .networkError:
         errorMessage = "Network error. Please check your internet connection."
         case .invalidResponse:
         errorMessage = "Invalid response from the server. Please try again."
         // Add more cases as needed
         }
         } else if let nsError = error as NSError? {
         // Check if the error is related to being offline
         if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
         errorMessage = "You are offline. Please check your internet connection."
         }
         }
         
         self.showAlert(title: "Error", message: errorMessage, options: "Ok")
         }
         }
         }*/
        
        let email = emailTextField.text ?? ""
        let phoneNumber = phoneNumberTextField.text ?? ""
        
        if email.isEmpty && phoneNumber.isEmpty {
            alert(message: "Please type email or phone number.", title: "Mandatory Field")
        } else if !email.isEmpty && !email.isValidEmail {
            alert(message: "Please enter a valid email.", title: "Mandatory Field")
        } else if !phoneNumber.isEmpty && !phoneNumber.isValidPhone {
            alert(message: "Please enter a valid phone number.", title: "Mandatory Field")
        } else {
            let emailOrPhone = !email.isEmpty ? email : phoneNumber
            UserDefaults.standard.set(emailOrPhone, forKey: "emailOrPhone")
            UserDefaults.standard.set(!email.isEmpty ? "email" : "phone", forKey: "emailOrPhoneType") // Save type
            
            // Continue with the API call and navigation as before
            let loginParams: forgetPassword.Body = forgetPassword.Body(emailorphone: emailOrPhone)
            
            APIManager().perform(forgetPassword(queryParams: nil, body: loginParams)) { result in
                self.hideHUD()
                switch result {
                case .success(let data):
                    if data.detail.status == "success" {
                        DispatchQueue.main.async {
                            self.showAlert(title: "Success", message: data.detail.message, options: "Ok") { [self] option in
                                let verifyEmailVC = UIStoryboard(name: Storyboards.Authentication, bundle: nil)
                                    .instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
                                verifyEmailVC.isFromForget = true
                                tokenVal = data.detail.uniqueToken
                                verifyEmailVC.verifyTokenVal = tokenVal
                                verifyEmailVC.emailValue = emailOrPhone
                                self.navigationController?.pushViewController(verifyEmailVC, animated: true)
                            }
                        }
                    } else if data.detail.status == "fail" {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Fail")
                            // Handle the "fail" status here
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message, title: "Exception")
                        }
                    }
                case .failure(let error):
                    print("errrorrrs", error)
                    DispatchQueue.main.async {
                        var errorMessage = "An error occurred. Please try again later."
                        
                        // Check specific error types and provide more informative messages
                        if let apiError = error as? APIErrorFormat {
                            switch apiError {
                            case .networkError:
                                errorMessage = "Network error. Please check your internet connection."
                            case .invalidResponse:
                                errorMessage = "Invalid response from the server. Please try again."
                                // Add more cases as needed
                            }
                        } else if let nsError = error as NSError? {
                            // Check if the error is related to being offline
                            if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                                errorMessage = "You are offline. Please check your internet connection."
                            }
                        }
                        
                        self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                    }
                }
            }
            
        }}
        
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
//    {
//        let verifyEmailVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
//        self.navigationController?.pushViewController(verifyEmailVC, animated: true)
//    }
    
    @IBAction func countryCodeAction(_ sender: Any) {
        DispatchQueue.main.async {
          CountriesViewController.show(countriesViewController: self.countriesViewController, toVar: self)
        }
    }
    func setupCountryPicker(){
        self.countriesViewController = CountriesViewController()
        self.countriesViewController.delegate = self
        self.countriesViewController.allowMultipleSelection = false
        if let info = self.getCountryAndName() {
            countryCode = info.countryCode!
           // self.lblFlag.text = info.countryFlag!
            self.countryCodeLabel.text = "("+info.countryShortName!+")"
           // self.phoneNumberTextField.text = info.countryCode!
        }
    }
    //Method is used for getiing country data which is stored in json file
    private func getCountryAndName(_ countryParam: String? = nil) -> CountryModel? {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonObj = JSON(data)
                let countryData = CountryListModel.init(jsonObj.arrayValue)
                let locale: Locale = Locale.current
                var countryCode: String?
                if countryParam != nil {
                    countryCode = countryParam
                } else {
                    countryCode = locale.regionCode
                }
                let currentInfo = countryData.country?.filter({ (cm) -> Bool in
                    return cm.countryShortName?.lowercased() == countryCode?.lowercased()
                })
                
                if currentInfo!.count > 0 {
                    return currentInfo?.first
                } else {
                    return nil
                }
                
            } catch {
                // handle error
            }
        }
        return nil
    }
    @IBAction func backAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
    
}
extension ForgetPasswordViewController: CountriesViewControllerDelegate {
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountries countries: [Country]) {
        
        countries.forEach { co in
            //            Logger.println(co.name)
        }
    }
    func countriesViewControllerDidCancel(_ countriesViewController: CountriesViewController) {
        
        //        Logger.println("user hass been tap cancel")
        
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountry country: Country) {
        if let info = self.getCountryAndName(country.countryCode) {
            countryCode = info.countryCode!
          //  self.lblFlag.text = info.countryFlag!
            self.countryCodeLabel.text = "("+info.countryShortName!+")"
            self.phoneNumberTextField.text = info.countryCode!
        }
    }
    func countriesViewController(_ countriesViewController: CountriesViewController, didUnselectCountry country: Country) {
        
        //        Logger.println(country.name + " unselected")
        
    }
}
extension ForgetPasswordViewController: UITextFieldDelegate {
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
}
