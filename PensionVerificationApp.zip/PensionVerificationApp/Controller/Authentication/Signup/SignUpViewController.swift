//
//  SignUpViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 18/10/23.
//

import UIKit

class SignUpViewController: UIViewController {
    //MARK: -------------------- Outlet --------------------
    
    
    @IBOutlet weak var passwordShowButton: UIButton!
    @IBOutlet weak var RePasswordShowButton: UIButton!
    @IBOutlet weak var phoneTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var contentScrollView: UIScrollView!
    @IBOutlet weak var usernameTextfield: UITextField!
    @IBOutlet weak var reEnterTextfield: UITextField!
    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var lblCountryCode: UILabel!
    @IBOutlet weak var btnCountryCode: UIButton!
    //MARK: -------------------- Life Cycle Method --------------------
    var countriesViewController = CountriesViewController()
    var countryCode: String?
    
    var initialText = ""

    var isPasswordHidden = true
    var isRePasswordHidden = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        initalSetup()
        setupCountryPicker()
        passwordShowButton.setTitle("", for: .normal)
        RePasswordShowButton.setTitle("", for: .normal)
        resetCountryCode()
        
        phoneTextfield.delegate = self
        passwordTextfield.delegate = self
        emailTextfield.delegate = self
        usernameTextfield.delegate = self
        reEnterTextfield.delegate = self
        phoneTextfield.delegate = self
        
        phoneTextfield.keyboardType = .numberPad  // Set the keyboard type to number pad
        phoneTextfield.returnKeyType = .done  // Optionally set the return key type

        // Add gestures to emailTextField
          addTapGestures(to: phoneTextfield)
          
          // Add gestures to phoneNumberTextField
          addTapGestures(to: emailTextfield)
          
          // Add gestures to passwordTextField
          addTapGestures(to: passwordTextfield)
          addTapGestures(to: usernameTextfield)
          addTapGestures(to: reEnterTextfield)

      }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // Validation for usernameTextField to allow only alphabets and spaces
        if textField == usernameTextfield {
            let allowedCharacters = CharacterSet.letters.union(.whitespaces)
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
        
        // Validation for phoneTextField to prevent deleting initial text and to allow only 10 digits
        if textField == phoneTextfield {
            // Set initial text if it hasn't been set yet
            if initialText.isEmpty {
                initialText = textField.text ?? ""
            }
            
            // Detect backspace (if the replacement string is empty)
            if string.isEmpty {
                // Prevent deleting initial text
                if range.location < initialText.count {
                    return false
                }
            }
            
            // Limit input to 10 digits
            let currentText = textField.text ?? ""
            let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
            let isNumeric = CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: string))
            let maxDigits = 13

            if isNumeric {
                return newText.count <= maxDigits
            } else {
                return false
            }
        }
        
        return true
    }
    
    

  /*  func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // Validation for usernameTextfield to allow only alphabets and space
        if textField == usernameTextfield {
            let allowedCharacters = CharacterSet.letters.union(.whitespaces)
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
        
        // Validation for phoneTextfield to prevent deleting initial text
        if textField == phoneTextfield {
            // Set initial text if it hasn't been set yet
            if initialText.isEmpty {
                initialText = textField.text ?? ""
            }
            
            // Detect backspace (if the replacement string is empty)
            if string.isEmpty {
                // Prevent deleting initial text
                if range.location < initialText.count {
                    return false
                }
            }
        }
        
        return true
    }*/

      func addTapGestures(to textField: UITextField) {
          // Add Tap Gesture Recognizer
          let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(gesture:)))
          tapGesture.numberOfTapsRequired = 1 // Single tap
          textField.addGestureRecognizer(tapGesture)
          
          // Add Double Tap Gesture Recognizer
          let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
          doubleTapGesture.numberOfTapsRequired = 2 // Double tap
          textField.addGestureRecognizer(doubleTapGesture)
          
          // Ensure the single tap gesture recognizer waits until the double tap gesture recognizer fails
          tapGesture.require(toFail: doubleTapGesture)
      }

      @objc func handleTap(gesture: UITapGestureRecognizer) {
          guard let textField = gesture.view as? UITextField else { return }
          
          // Make sure the text field becomes the first responder
          textField.becomeFirstResponder()
          
          // Calculate the location of the tap
          let location = gesture.location(in: textField)
          
          // Get the closest position to the tap
          if let position = textField.closestPosition(to: location) {
              textField.selectedTextRange = textField.textRange(from: position, to: position)
          }
      }

      @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
          guard let textField = gesture.view as? UITextField else { return }
          
          // Make sure the text field becomes the first responder
          textField.becomeFirstResponder()
          
          // Select the entire text in the text field
          if let textRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument) {
              textField.selectedTextRange = textRange
          }
      }
    
    @IBAction func passwordShowButtonTapped(_ sender: Any) {
        isPasswordHidden.toggle()
        if isPasswordHidden {
            passwordTextfield.isSecureTextEntry = true
            passwordShowButton.setImage(UIImage(named: "closedEye"), for: .normal)
        } else {
            passwordTextfield.isSecureTextEntry = false
            passwordShowButton.setImage(UIImage(named: "openEye"), for: .normal)
        }
    }
   
    @IBAction func rePasswordShowButtonTapped(_ sender: Any) {
        
        isRePasswordHidden.toggle()
        if isRePasswordHidden {
            reEnterTextfield.isSecureTextEntry = true
            RePasswordShowButton.setImage(UIImage(named: "closedEye"), for: .normal)
        } else {
            reEnterTextfield.isSecureTextEntry = false
            RePasswordShowButton.setImage(UIImage(named: "openEye"), for: .normal)
        }
    }
   
    func initalSetup(){
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyBord))
        view.addGestureRecognizer(tap)
      
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    // MARK:- Keyboard delegate Methods
    /// method will be call when keyboard will appear
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    @objc func dismissKeyBord(){
        self.view.endEditing(true)
    }
    // method will be call when keyboard will close
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    @IBAction func loginAction(_ sender: Any) {
        let loginVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    @IBAction func countryCodeAction(_ sender: Any) {
        DispatchQueue.main.async {
          CountriesViewController.show(countriesViewController: self.countriesViewController, toVar: self)
        }
    }
    func setupCountryPicker(){
        self.countriesViewController = CountriesViewController()
        self.countriesViewController.delegate = self
        self.countriesViewController.allowMultipleSelection = false
        if let info = self.getCountryAndName() {
            countryCode = info.countryCode!
           // self.lblFlag.text = info.countryFlag!
           // self.lblCountryCode.text = "("+info.countryShortName!+")"+info.countryCode!
            
           // self.lblCountryCode.text = "(\(info.countryShortName!)) \(info.countryCode!)"


        }
    }
    //Method is used for getiing country data which is stored in json file
    private func getCountryAndName(_ countryParam: String? = nil) -> CountryModel? {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonObj = JSON(data)
                let countryData = CountryListModel.init(jsonObj.arrayValue)
                let locale: Locale = Locale.current
                var countryCode: String?
                if countryParam != nil {
                    countryCode = countryParam
                } else {
                    countryCode = locale.regionCode
                }
                let currentInfo = countryData.country?.filter({ (cm) -> Bool in
                    return cm.countryShortName?.lowercased() == countryCode?.lowercased()
                })
                
                if currentInfo!.count > 0 {
                    return currentInfo?.first
                } else {
                    return nil
                }
                
            } catch {
                // handle error
            }
        }
        return nil
    }
    @IBAction func signupAction(_ sender: Any){
        
//        let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
//        self.navigationController?.pushViewController(signUpVC, animated: true)
        
        guard let userName = usernameTextfield.text, !userName.isEmpty else {
            alert(message: "Please enter UserName", title: "Mandatory Field")
            return
        }
        guard let email = emailTextfield.text, !email.isEmpty else {
            alert(message: "Please enter Email Address", title: "Mandatory Field")
            return
        }
        if !email.isValidEmail {
            alert(message: "Please provide a valid Email Address", title: "Email Validation")
            return
        }
        guard let phoneNumber = phoneTextfield.text, !phoneNumber.isEmpty else {
            alert(message: "Please enter Phone Number", title: "Mandatory Field")
            return
        }
        guard let password = passwordTextfield.text, !password.isEmpty else {
            alert(message: "Please enter Password", title: "Mandatory Field")
            return
        }
        if !password.isValidPassword {
            alert(message: "Pasword must contain at least one uppercase letter, one lowercase letter, one numeric digit and at least 8 characters long", title: "Password Validation")
            return
        }
        guard let confirmPassword = reEnterTextfield.text, !confirmPassword.isEmpty else {
            alert(message: "Please enter Re-enter Password", title: "Mandatory Field")
            return
        }
        if password != confirmPassword {
            alert(message: "Password & Re-enter Password mis-match", title: "Password Validation")
            return
        }
        
        self.showHUD(message: "")
        APIManager().perform(Register(queryParams: nil, body: Register.Body(username: userName, email: email, phone_number: phoneNumber, password: password, confirm_password: confirmPassword))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                if data.detail.status == "success"{
                    DispatchQueue.main.async {
                        self.showAlert(title: "Success", message: data.detail.message, options: "Ok"){ option in
                            let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "VerifyEmailViewController") as! VerifyEmailViewController
                                                       signUpVC.emailValue = email
                                                    self.navigationController?.pushViewController(signUpVC, animated: true)
                        }
                    }
                } else if data.detail.status == "fail" &&  data.detail.token_status == "expired"   {
                    DispatchQueue.main.async {
                        self.callRefreshToken()
                        // Handle the "fail" status here
                    }
                }
                else {
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message, title: "Exception")
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    var errorMessage = "An error occurred. Please try again later."
                    
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    } else if let nsError = error as NSError? {
                        // Check if the error is related to being offline
                        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                            errorMessage = "You are offline. Please check your internet connection."
                        }
                    }
                    
                    self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                }
            }
        }
        
    }
}
extension SignUpViewController: CountriesViewControllerDelegate {
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountries countries: [Country]) {
        countries.forEach { co in
            //            Logger.println(co.name)
        }
    }
    
    func countriesViewControllerDidCancel(_ countriesViewController: CountriesViewController) {
        //        Logger.println("user has tapped cancel")
    }
    
    func countriesViewController(_ countriesViewController: CountriesViewController, didSelectCountry country: Country) {
        if let info = self.getCountryAndName(country.countryCode) {
            countryCode = info.countryCode!
            //  self.lblFlag.text = info.countryFlag!
            self.lblCountryCode.text = "(\(info.countryShortName!)) \(info.countryCode!)"

        }
    }
    
    func countriesViewController(_ countriesViewController: CountriesViewController, didUnselectCountry country: Country) {
        //        Logger.println(country.name + " unselected")
    }
    
    // Function to reset country code
    func resetCountryCode() {
        self.lblCountryCode.text = "(IN)"
        self.phoneTextfield.text = "+91"
    }
    
    // This function should be called when the view controller is loaded to avoid showing a default country code
    
}
extension SignUpViewController: UITextFieldDelegate {
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      textField.resignFirstResponder()
   }
}
