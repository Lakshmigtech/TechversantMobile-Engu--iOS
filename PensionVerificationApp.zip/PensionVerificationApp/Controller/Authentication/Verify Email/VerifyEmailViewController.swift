//
//  VerifyEmailViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//

import UIKit

class VerifyEmailViewController: UIViewController {
    var emailValue : String?
    var otp = ""
    var isFromForget = false
    var verifyTokenVal : String?
   
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var buttonStackView: UIStackView!
    @IBOutlet weak var verifyLabeldescription: UILabel!
    //MARK: -------------------- Outlet --------------------
    @IBOutlet weak var tF1: CustomBorderTextField!
    @IBOutlet weak var tF2: CustomBorderTextField!
    @IBOutlet weak var tF3: CustomBorderTextField!
    @IBOutlet weak var tF4: CustomBorderTextField!
    @IBOutlet weak var tF5: CustomBorderTextField!
    @IBOutlet weak var tF6: CustomBorderTextField!
    //MARK: -------------------- Life Cycle Method --------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Set title based on the email or phone input
            let type = UserDefaults.standard.string(forKey: "emailOrPhoneType") ?? ""
            if type == "email" {
                titleLabel.text = "VERIFY YOUR EMAIL"
                verifyLabeldescription.text = "Please enter the 6 digit verification code sent to \(emailValue ?? "")to confirm your email address."
            } else if type == "phone" {
                titleLabel.text = "VERIFY YOUR NUMBER"
                verifyLabeldescription.text = "Please enter the 6 digit verification code sent to \(emailValue ?? "")to confirm your Phone Number."
            }
        
        
        
      
        tF1.delegate = self
        tF2.delegate = self
        tF3.delegate = self
        tF4.delegate = self
        tF5.delegate = self
        tF6.delegate = self
        loginView.isHidden = true
    }
    func clearTextFields() {
        self.tF1.text = ""
        self.tF2.text = ""
        self.tF3.text = ""
        self.tF4.text = ""
        self.tF5.text = ""
        self.tF6.text = ""
    }
    
    
    @IBAction func loginButtonClicked(_ sender: Any) {
        let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
          self.navigationController?.pushViewController(signUpVC, animated: true)
    }
    
    @IBAction func resendOTPAction(_ sender: Any) {
       self.clearTextFields() // Clear the OTP fields
        self.showHUD(message: "")
        APIManager().perform(ReVerifyOTP(queryParams: nil, body:ReVerifyOTP.Body(email: emailValue ?? ""))) { result in
            self.hideHUD()
            switch result {
            case .success(let data):
                print(data)
                if data.detail.status == "success"{
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message!, title: "Resend OTP")
//                        self.showAlert(title: "Success", message: data.detail.message!, options: "Ok"){ option in
//                        }
                    }
                }else if data.detail.status == "fail" {
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message!, title: "Fail")
                        // Handle the "fail" status here
                    }
                }
                else {
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message!, title: "Exception")
                    }
                }
            case .failure(let error):
                print("errrorrrs",error)
                DispatchQueue.main.async {
                    self.alert(message: error.localizedDescription, title: "Exceptionsss")
                }
            }
            
        }
       
        }
    @IBAction func verifyEmailAction(_ sender: Any) {
        if isFromForget == true {
            self.showHUD(message: "")
                let otpVal = "\(tF1.text!)\(tF2.text!)\(tF3.text!)\(tF4.text!)\(tF5.text!)\(tF6.text!)"
            let emailOrPhone = UserDefaults.standard.string(forKey: "emailOrPhone")
            
            APIManager().perform(ForgetOTPVerify(queryParams: nil, body: ForgetOTPVerify.Body(email_or_phone_number: emailOrPhone!, otp: otpVal))) { [self] result in
                self.hideHUD()
                switch result {
                case .success(let data):
                    print(data)
                    if data.detail.status == "success"{
                        DispatchQueue.main.async {
                            self.showAlert(title: "Success", message: data.detail.message!, options: "Ok"){ [self] option in
                                let resetVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "ResetPasswordViewController") as! ResetPasswordViewController
                                resetVC.resetTokenVal = self.verifyTokenVal;                       self.navigationController?.pushViewController(resetVC, animated: true)
                                loginView.isHidden = true
                            }}
                       
                    }else if data.detail.status == "fail" {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message!, title: "Failed Signup")
                            // Handle the "fail" status here
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message!, title: "Exception")
                        }
                    }
                case .failure(let error):
                    print("errrorrrs",error)
                    DispatchQueue.main.async {
                        self.alert(message: error.localizedDescription, title: "Exceptionsss")
                    }
                }
            }
        }
        else if isFromForget == false {
            self.showHUD(message: "")
                let otpVal = "\(tF1.text!)\(tF2.text!)\(tF3.text!)\(tF4.text!)\(tF5.text!)\(tF6.text!)"
                let email = emailValue
           
            APIManager().perform(VerifyOTP(queryParams: nil, body: VerifyOTP.Body(email: email ?? "", otp: otpVal))) { [self] result in
                self.hideHUD()
                switch result {
                case .success(let data):
                    print(data)
                    if data.detail.status == "success"{
                       
                            DispatchQueue.main.async {
                                self.showAlert(title: "Success", message: data.detail.message!, options: "Ok"){ [self] option in
                                  /*  let signUpVC = UIStoryboard.init(name: Storyboards.Authentication, bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                                    self.navigationController?.pushViewController(signUpVC, animated: true)*/
                                    loginView.isHidden = false
                                    buttonStackView.isHidden = true
                                }}
                    }else if data.detail.status == "fail" {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message!, title: "Failed Signup")
                            // Handle the "fail" status here
                        }
                    }
                    else {
                        DispatchQueue.main.async {
                            self.alert(message: data.detail.message!, title: "Exception")
                        }
                    }
                case .failure(let error):
                    print("errrorrrs", error)
                    DispatchQueue.main.async {
                        var errorMessage = "An error occurred. Please try again later."
                        
                        // Check specific error types and provide more informative messages
                        if let apiError = error as? APIErrorFormat {
                            switch apiError {
                            case .networkError:
                                errorMessage = "Network error. Please check your internet connection."
                            case .invalidResponse:
                                errorMessage = "Invalid response from the server. Please try again."
                                // Add more cases as needed
                            }
                        } else if let nsError = error as NSError? {
                            // Check if the error is related to being offline
                            if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorNotConnectedToInternet {
                                errorMessage = "You are offline. Please check your internet connection."
                            }
                        }
                        
                        self.showAlert(title: "Error", message: errorMessage, options: "Ok")
                    }
                }
            }
        }
    }
    @IBAction func backAction(_ sender: Any) {
        if let _ = navigationController?.popViewController(animated: true) {
            
        } else {
            dismiss(animated: true, completion: nil)
        }
    }
}
extension VerifyEmailViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == tF1 || textField == tF2 || textField == tF3 || textField == tF4 || textField == tF5 || textField == tF6{
            let newLength = (textField.text?.count ?? 0) + string.count - range.length
            if newLength > 1 {
                switch textField {
                case tF1:
                    tF2.becomeFirstResponder()
                    tF2.text = string
                case tF2:
                    tF3.becomeFirstResponder()
                    tF3.text = string
                case tF3:
                    tF4.becomeFirstResponder()
                    tF4.text = string
                case tF4:
                    tF5.becomeFirstResponder()
                    tF5.text = string
                case tF5:
                    tF6.becomeFirstResponder()
                    tF6.text = string
                    tF6.resignFirstResponder()
                    // updateVerifyButtonUI(enabled: true)
                default:
                    break
                }
                // Return false to prevent further processing of the input
                return false
            }
        }
        return true
    }
    
    
    
}
