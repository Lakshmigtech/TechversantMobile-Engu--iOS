//
//  SplashSecondViewController.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 18/10/23.
//

import UIKit

class SplashSecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
