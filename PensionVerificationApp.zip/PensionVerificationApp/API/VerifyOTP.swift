//
//  VerifyOTP.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 30/11/23.
//

import Foundation

struct VerifyOTP: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let email: String
        let otp: String

        enum CodingKeys: String, CodingKey {
            case email = "email"
            case otp = "otp"
        }
    }
    
    typealias SuccessResponseType = VerifyOTPResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: VerifyOTP.QueryParams?
    var body: VerifyOTP.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "registration_verify"
    }
    
}
