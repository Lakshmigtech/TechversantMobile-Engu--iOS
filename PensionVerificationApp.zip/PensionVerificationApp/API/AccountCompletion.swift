//
//  AccountCompletion.swift
//  PensionVerificationApp
//
//  Created by Admin on 19/02/24.
//

import Foundation

struct AccountCompletion: APIRequest {
    
    struct QueryParams: Encodable { }
    
    struct Body: Encodable {
        let country: String
        
        
        enum CodingKeys: String, CodingKey {
            case country = "country"
            
        }
    }
    typealias SuccessResponseType = AccountCompletionResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    
    var queryParams: AccountCompletion.QueryParams?
    var body: AccountCompletion.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "account_completion/details"
    }
    
}
