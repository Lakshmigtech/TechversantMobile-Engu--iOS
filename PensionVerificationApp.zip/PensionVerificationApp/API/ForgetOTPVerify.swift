//
//  ForgetOTPVerify.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/03/24.
//

import Foundation

struct ForgetOTPVerify: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  email_or_phone_number: String
        let  otp: String
        
        
        enum CodingKeys: String, CodingKey {
            case email_or_phone_number = "email_or_phone_number"
            case  otp = "otp"
            
        }
    }
    typealias SuccessResponseType = ForgetOTPVerifyResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    
    var queryParams: ForgetOTPVerify.QueryParams?
    var body: ForgetOTPVerify.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "forgot_password_verify"
    }
    
}
