//
//  ResetPassword.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 11/01/24.
//

import Foundation

struct ResetPassword: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
            let otp:String
            let token: String
            let password: String
            
            enum CodingKeys: String, CodingKey {
                case otp = "otp"
                case token = "unique_token"
                case password = "password"
            }
        }
    
    typealias SuccessResponseType = ResetPasswordResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: ResetPassword.QueryParams?
    var body: ResetPassword.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "reset-password"
    }
}
