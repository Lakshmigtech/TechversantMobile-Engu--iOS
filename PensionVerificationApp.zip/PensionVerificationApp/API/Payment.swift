//
//  Payment.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 13/11/24.
//

import Foundation

struct PaymentDetails: APIRequest {
   
    
    
    struct QueryParams: Encodable { }
    
    struct Body: Encodable {
        let amount: Double
        let description: String
        let currency: String // Add currency field

        enum CodingKeys: String, CodingKey {
            case amount
            case description
            case currency // Add currency to CodingKeys
        }
  
    }
    
    typealias SuccessResponseType = PaymentResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String

    var queryParams: PaymentDetails.QueryParams?
    var body: PaymentDetails.Body?
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken, // Set the bearer token here
            authorizationKey: .bearer,
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .post
    }
    
    var resourceName: String? {
        return "transfer-to-final-account"
    }
}
