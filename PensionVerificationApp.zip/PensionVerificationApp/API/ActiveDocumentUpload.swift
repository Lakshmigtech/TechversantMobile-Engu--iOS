
import Foundation

struct ActiveDocumentUpload: APIRequest {
    
    struct QueryParams: Encodable { }
    
    struct Body: Encodable {
        let application_form_file: Data
        let promotion_letter_transfer_letter_file: Data
        let id_card_file: Data
        let passport_photo_file: Data
        let clearance_form_file: Data
        
        enum CodingKeys: String, CodingKey {
            case application_form_file = "application_form_file"
            case  promotion_letter_transfer_letter_file = "promotion_letter_transfer_letter_file"
            case  id_card_file = "id_card_file"
            case   passport_photo_file = "passport_photo_file"
            case  clearance_form_file = "clearance_form_file"
        }
    }
    let bearerToken: String
    
    typealias SuccessResponseType = ActiveDocumentUploadResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    var queryParams: ActiveDocumentUpload.QueryParams?
    var body: ActiveDocumentUpload.Body?
    
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken,
            authorizationKey: .bearer,
            contentType: ContentType.formData,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .post
    }
    
    var resourceName: String? {
        return "account_completion/doc_upload_active"
    }
}
/*import Foundation

// Define ActiveDocumentUpload struct
struct ActiveDocumentUpload {
    struct Body {
        let application_form: Data
        let promotion_letter_transfer_letter: Data
        let id_card: Data
        let passport_photo: Data
        let clearance_form: Data
    }
    
    let bearerToken: String
    let body: Body
    
    func createParameters() -> [String: Data] {
        return [
            "application_form": body.application_form,
            "promotion_letter_transfer_letter": body.promotion_letter_transfer_letter,
            "id_card": body.id_card,
            "passport_photo": body.passport_photo,
            "clearance_form": body.clearance_form
        ]
    }
}

// Example usage
// Load data from files on your phone
let applicationFormData = try! Data(contentsOf: URL(fileURLWithPath: "path_to_application_form_file"))
let promotionLetterData = try! Data(contentsOf: URL(fileURLWithPath: "path_to_promotion_letter_file"))
let idCardData = try! Data(contentsOf: URL(fileURLWithPath: "path_to_id_card_file"))
let passportPhotoData = try! Data(contentsOf: URL(fileURLWithPath: "path_to_passport_photo_file"))
let clearanceFormData = try! Data(contentsOf: URL(fileURLWithPath: "path_to_clearance_form_file"))

// Create an instance of ActiveDocumentUpload.Body
let body = ActiveDocumentUpload.Body(application_form: applicationFormData,
                                     promotion_letter_transfer_letter: promotionLetterData,
                                     id_card: idCardData,
                                     passport_photo: passportPhotoData,
                                     clearance_form: clearanceFormData)

// Create an instance of ActiveDocumentUpload
let activeDocumentUpload = ActiveDocumentUpload(bearerToken: "your_token_here", body: body)

// Create parameters for API request
let parameters = activeDocumentUpload.createParameters()

// Now you can use parameters for your API request*/


