//
//  DashBoard.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/06/24.
//

import Foundation

struct DashBoard: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
    }
    
    typealias SuccessResponseType = DashBoardAPIResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    // Add a property for the bearer token
    let bearerToken: String
    
    var queryParams: DashBoard.QueryParams?
    var body: DashBoard.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .get
    }
    
    var resourceName: String?{
        return "profile/dashboard_details"
    }
    
}
