//
//  Wallet.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 29/08/24.
//
import Foundation

struct WalletDetails: APIRequest {
    
    struct QueryParams: Encodable { }
    
    struct Body: Encodable {
        
        let userId: Int
        let bankId: Int
        let amount: Double
        let currency: String
        let description: String
       
        enum CodingKeys: String, CodingKey {
           
            case userId = "user_id"
            case bankId = "bank_id"
            case amount
            case currency
            case description
        }
    }
    
    typealias SuccessResponseType = WalletResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String

    var queryParams: WalletDetails.QueryParams?
    var body: WalletDetails.Body?
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken, // Set the bearer token here
            authorizationKey: .bearer,
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .post
    }
    
    var resourceName: String? {
        return "topup"
    }
}
