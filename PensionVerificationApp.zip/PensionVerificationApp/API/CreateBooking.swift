//
//  CreateBooking.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 24/09/24.
//
//

import Foundation

struct CreateBooking: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  booking_date: String
        let  booking_slot_id: Int

        enum CodingKeys: String, CodingKey {
            case  booking_date = "booking_date"
            case  booking_slot_id = "booking_slot_id"

        }
    }
    typealias SuccessResponseType = CreateBookingResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String
    
    var queryParams: CreateBooking.QueryParams?
    var body: CreateBooking.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "booking/create-booking/"
    }
    
}
