//
//  Login.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 29/12/23.
//

import Foundation

struct Login: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let emailorphone: String
        let password: String

        enum CodingKeys: String, CodingKey {
            case emailorphone = "email_or_phone_number"
            case password = "password"
        }
    }
    
    typealias SuccessResponseType = LoginResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: Login.QueryParams?
    var body: Login.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "token"
    }
    
}
