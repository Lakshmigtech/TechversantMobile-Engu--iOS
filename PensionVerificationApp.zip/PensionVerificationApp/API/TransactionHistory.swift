//
//  TransactionHistory.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/09/24.
//

import Foundation


struct TransactionHistoryRequest: APIRequest {
    
    struct QueryParams: Encodable {
        let page: Int
        let limit: Int
    }
    
    struct Body: Encodable {}
    
    
    typealias SuccessResponseType = TransactionHistoryResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String
    
    var queryParams: TransactionHistoryRequest.QueryParams?
    var body: TransactionHistoryRequest.Body?
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken, // Set the bearer token here
            authorizationKey: .bearer,
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .get
    }
    
    var resourceName: String? {
        return "transaction-details"
    }
    
    // Updated initializer to include bearerToken
        init(bearerToken: String, queryParams: QueryParams?, body: Body?) {
            self.bearerToken = bearerToken
            self.queryParams = queryParams
            self.body = body
        }
}
