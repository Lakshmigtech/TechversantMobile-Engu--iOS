//
//  RefreshToken.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 31/01/24.
//

import Foundation

struct RefreshToken: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let refresh_token: String
        
        enum CodingKeys: String, CodingKey {
            case refresh_token = "refresh_token"
        }
    }
    
    typealias SuccessResponseType = RefreshTokenResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: RefreshToken.QueryParams?
    var body: RefreshToken.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "token/refresh"
    }
    
}
