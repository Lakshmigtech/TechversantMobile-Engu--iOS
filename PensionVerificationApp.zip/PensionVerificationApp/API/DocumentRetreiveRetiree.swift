//
//  DocumentRetreiveRetiree.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 15/05/24.
//

import Foundation

struct DocumentRetreiveRetiree: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
    }
    
    typealias SuccessResponseType = DocumentRetreiveRetireeResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    // Add a property for the bearer token
    let bearerToken: String
    
    var queryParams: DocumentRetreiveRetiree.QueryParams?
    var body: DocumentRetreiveRetiree.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .get
    }
    
    var resourceName: String?{
        return "account_completion/doc_retrieve_retired"
    }
    
}

