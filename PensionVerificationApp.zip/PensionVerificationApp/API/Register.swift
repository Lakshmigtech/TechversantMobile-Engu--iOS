//
//  Register.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation

struct Register: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let username: String
        let email: String
        let phone_number: String
        let password: String
        let confirm_password: String

        enum CodingKeys: String, CodingKey {
            case username = "username"
            case email = "email"
            case phone_number = "phone_number"
            case password = "password"
            case confirm_password = "confirm_password"
        }
    }
    
    typealias SuccessResponseType = RegisterResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: Register.QueryParams?
    var body: Register.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "register"
    }
    
}
