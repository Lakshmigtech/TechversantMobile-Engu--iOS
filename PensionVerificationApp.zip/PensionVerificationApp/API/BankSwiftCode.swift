//
//  BankSwiftCode.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 28/02/24.
//

import Foundation

struct SwiftCode: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  swift_code: String
        
        enum CodingKeys: String, CodingKey {
            case swift_code = "swift_code"
        }
    }
    
    let bearerToken: String
    
    typealias SuccessResponseType = SwiftCodeBankResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

        
        var queryParams: SwiftCode.QueryParams?
        var body: SwiftCode.Body?
        var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "get_bank_details"
    }
    
}





