//
//  VerifyBankAccount.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/07/24.
//

//
//  DashBoard.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/06/24.
//

/*import Foundation

struct VerifyBankAccount: APIRequest {
    struct QueryParams: Encodable {
        let account_number: String
        let bank_code: String
        
        enum CodingKeys: String, CodingKey {
            case account_number = "account_number"
            case bank_code = "bank_code"    
        }
    }
    struct Body: Encodable { }
    
    typealias SuccessResponseType = VerifyBankAccountResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String
    
    var queryParams: VerifyBankAccount.QueryParams?
    var body: VerifyBankAccount.Body?
    
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken,
            authorizationKey: .bearer,
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .post
    }
    var resourceName: String? {
        return "verify_bank_account"
    }
    var fullURL: URL? {
        guard var components = URLComponents(url: baseEndpointUrl.appendingPathComponent(resourceName ?? ""), resolvingAgainstBaseURL: false) else {
            return nil
        }
        if let queryParams = queryParams {
            components.queryItems = [
                URLQueryItem(name: "account_number", value: queryParams.account_number),
                URLQueryItem(name: "bank_code", value: queryParams.bank_code)
            ]
        }
        return components.url
    }
}*/

import Foundation

struct VerifyBankAccount: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  account_number: String
        let  bank_code: String
        enum CodingKeys: String, CodingKey {
            case  account_number = "account_number"
            case  bank_code = "bank_code"
        }
    }
    typealias SuccessResponseType = VerifyBankAccountResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String
    
    var queryParams: VerifyBankAccount.QueryParams?
    var body: VerifyBankAccount.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "verify_bank_account"
    }
    
}

