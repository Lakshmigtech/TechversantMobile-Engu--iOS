//
//  EINSave.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 29/05/24.
//

import Foundation

struct EINSave: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  ein: String
        
        enum CodingKeys: String, CodingKey {
            case  ein = "ein"
            
        }
    }
    typealias SuccessResponseType = EINResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    let bearerToken: String
    
    var queryParams: EINSave.QueryParams?
    var body: EINSave.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "save_ein"
    }
    
}
