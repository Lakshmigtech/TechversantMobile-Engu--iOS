//
//  BookingDateRange.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 09/09/24.
//



import Foundation

struct BookingDateRangeAPI: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
    }
    
    typealias SuccessResponseType = BookingDateRangeResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    // Add a property for the bearer token
    
    var queryParams: BookingDateRangeAPI.QueryParams?
    var body: BookingDateRangeAPI.Body?
    var header: APIHeader? {
            return APIHeader(
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .get
    }
    
    var resourceName: String?{
        return "booking/booking-date-range/"
    }
    
}
