//
//  Logout.swift
//  PensionVerificationApp
//
//  Created by Admin on 22/01/24.
//


import Foundation

struct Logout: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
    }
    
    typealias SuccessResponseType = LogoutResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    // Add a property for the bearer token
    let bearerToken: String
    
    var queryParams: Logout.QueryParams?
    var body: Logout.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "token/logout"
    }
    
}
