//
//  RetireeAccountCompletion.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 28/02/24.
//


import Foundation

struct RetireeAccountCompletion: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let  user_type: String
        let  first_name: String
        let  middle_name: String
        let  last_name: String
        let  dob: String
        
        let  sex: String
        let  address: String
        let  pincode : String
        let  country: String
        let  lga_id: Int
        
        let  next_of_kin_name: String
        let  next_of_kin_email: String
        let  next_of_kin_phone_number: String
        let  next_of_kin_address: String
        let  next_of_kin_pincode: String
        let local_government_pension_board_id: Int
        
        let  sub_treasury_id: Int
        let  date_of_appointment: String
        let  last_promotion_year: Int
        let  grade_level: Int
        
        let  date_of_retirement: String
        let  position_held_last_id_or_other: String
       
        enum CodingKeys: String, CodingKey {
           
            case user_type = "user_type"
            case first_name = "first_name"
            case  middle_name = "middle_name"
            case  last_name = "last_name"
            case  dob  = "dob"
            
            case sex = "sex"
            case  address = "address"
            case  pincode =  "pincode"
            case  country = "country"
            case  lga_id  = "lga_id"
            
            case next_of_kin_name = "next_of_kin_name"
            case  next_of_kin_email = "next_of_kin_email"
            case  next_of_kin_phone_number = "next_of_kin_phone_number"
            case  next_of_kin_address  = "next_of_kin_address"
            case next_of_kin_pincode =  "next_of_kin_pincode"
            case local_government_pension_board_id = "local_government_pension_board_id"
            
            case sub_treasury_id = "sub_treasury_id"
            case  date_of_appointment = "date_of_appointment"
            case  last_promotion_year = "last_promotion_year"
            case  grade_level  = "grade_level"
            
            case date_of_retirement = "date_of_retirement"
            case  position_held_last_id_or_other  = "position_held_last_id_or_other"
           
        }
    }
    
    let bearerToken: String
    
    typealias SuccessResponseType = RetireeAccountCompletionResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

        
        var queryParams: RetireeAccountCompletion.QueryParams?
        var body: RetireeAccountCompletion.Body?
        var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "account_completion/retiree"
    }
    
}





