//
//  ReVerifyOTP.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 30/11/23.
//

import Foundation

struct ReVerifyOTP: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        let email: String

        enum CodingKeys: String, CodingKey {
            case email = "email"
        }
    }
    
    typealias SuccessResponseType = ReVerifyOTPResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: ReVerifyOTP.QueryParams?
    var body: ReVerifyOTP.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "reverify"
    }
}
