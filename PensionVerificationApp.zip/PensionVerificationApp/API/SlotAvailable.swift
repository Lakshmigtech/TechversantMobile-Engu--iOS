//
//  SlotAvailable.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/09/24.
//

//
//  VerifyBankAccount.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/07/24.
//

//
//  DashBoard.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/06/24.
//



import Foundation

struct SlotAvailable: APIRequest {
    
    struct QueryParams: Encodable {
           let selectedDay: String

           enum CodingKeys: String, CodingKey {
               case selectedDay = "selected_day"
           }
       }
    struct Body: Encodable {
        
    }
    typealias SuccessResponseType = SlotAvailableResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    
    
    var queryParams: SlotAvailable.QueryParams?
    var body: SlotAvailable.Body?
    var header: APIHeader? {
            return APIHeader(
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .get
    }
    
    var resourceName: String?{
        return "booking/list-slots/"
    }
    
}

