//
//  forgetPassword.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 04/01/24.
//

import Foundation

struct forgetPassword: APIRequest {
    
    struct QueryParams: Encodable { }
    struct Body: Encodable {
        let emailorphone: String

        enum CodingKeys: String, CodingKey {
            case emailorphone = "email_or_phone_number"
        }
    }
    
    typealias SuccessResponseType = forgetPasswordResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

    
    var queryParams: forgetPassword.QueryParams?
    var body: forgetPassword.Body?
    var header: APIHeader? {
        return APIHeader(
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "forgot-password"
    }
}
