//
//  UserGovtStatus.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 04/06/24.
//

import Foundation

struct UserGovtStatus: APIRequest {
   
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
    }
    
    typealias SuccessResponseType = UserGovtStatusResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    // Add a property for the bearer token
    let bearerToken: String
    
    var queryParams: UserGovtStatus.QueryParams?
    var body: UserGovtStatus.Body?
    var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
        }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .get
    }
    
    var resourceName: String?{
        return "users_govt_verification_status"
    }          
}
