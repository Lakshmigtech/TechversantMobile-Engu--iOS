//
//  BankDetails.swift
//  PensionVerificationApp
//
//  Created by Admin on 09/02/24.
//


import Foundation

struct BankDetails: APIRequest {
    
    struct QueryParams: Encodable { }
  
    struct Body: Encodable {
        
        let  bank_id : String
        let  account_number: String
        let  re_enter_account_number: String
        let  account_holder_name: String
        let  account_type: String
        let  swift_code: String
        let  bank_code: String
        let  auto_renewal : Bool?
       // let  user_id : String
        
        enum CodingKeys: String, CodingKey {
            
            case  bank_id =  "bank_id"
            case account_number = "account_number"
            case  re_enter_account_number = "re_enter_account_number"
            case  account_holder_name = "account_holder_name"
            case  account_type  = "account_type"
            case  swift_code   = "swift_code"
            case  bank_code    = "bank_code"
            case  auto_renewal = "auto_renewal"
           // case  user_id =  "user_id"
        }
    }
    
    let bearerToken: String
    
    typealias SuccessResponseType = BankDetailsResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body

        
        var queryParams: BankDetails.QueryParams?
        var body: BankDetails.Body?
        var header: APIHeader? {
            return APIHeader(
                authorization: bearerToken, // Set the bearer token here
                authorizationKey: .bearer,
                contentType: ContentType.json,
                acceptType: ContentType.json
            )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod{
        return .post
    }
    
    var resourceName: String?{
        return "create-or-update-bank-details"
    }
    
}



