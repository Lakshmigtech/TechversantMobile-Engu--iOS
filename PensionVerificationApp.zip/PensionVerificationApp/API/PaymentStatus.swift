//
//  PaymentStatus.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 29/08/24.
//

import Foundation

struct PaymentStatusRequest: APIRequest {
    
    struct QueryParams: Encodable {
        let session_id: String // Use `session_id` instead of `sessionId
        
    }
    
    struct Body: Encodable {}
    
    typealias SuccessResponseType = PaymentStatusResponse
    typealias QueryParamsType = QueryParams
    typealias BodyType = Body
    let bearerToken : String
    
    var queryParams: PaymentStatusRequest.QueryParams?
    var body: PaymentStatusRequest.Body?
    var header: APIHeader? {
        return APIHeader(
            authorization: bearerToken, // Set the bearer token here
            authorizationKey: .bearer,
            contentType: ContentType.json,
            acceptType: ContentType.json
        )
    }
    
    var baseEndpointUrl: URL {
        return NetworkEnvironment.baseURL
    }
    
    var method: HTTPMethod {
        return .get
    }
    
    var resourceName: String? {
        return "checkout/success"
    }
    
    // Updated initializer to include bearerToken
            init(bearerToken: String, queryParams: QueryParams?, body: Body?) {
                self.bearerToken = bearerToken
                self.queryParams = queryParams
                self.body = body
            }
}
