//
//  Constants.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//

import Foundation
import UIKit


class Constants {
    
    static let baseurlActive = "https://pension-distributor.demoserver.work/api/v1/account_completion/doc_upload_active"
    static let baseurlRetiree = "https://pension-distributor.demoserver.work/api/v1/account_completion/doc_upload_retired"
}


struct Storyboards {
    static let Main = "Main"
    static let Authentication = "Authentication"
    static let Services = "Services"
    static let Dashboard = "Dashboard"
}

struct AppFonts {
    static let NunitoSansRegular =  "NunitoSans_10pt-Regular"
    static let NunitoSansMedium =  "NunitoSans_10pt-Medium"
    static let NunitoSansBold =  "NunitoSans_10pt-Bold"
    static let NunitoSansSemiBold =  "NunitoSans_10pt-SemiBold"
}
enum Color {
   static let appTextBlack = UIColor.UIColorFromHex(rgbValue: 0x191F33)
   static let appTextGrey = UIColor.UIColorFromHex(rgbValue: 0x767E94)
   static let darkGreen = UIColor.UIColorFromHex(rgbValue: 0x018652)
    static let lightGreen = UIColor.UIColorFromHex(rgbValue: 0xE2FFEF)
    static let gradientGreen = UIColor.UIColorFromHex(rgbValue: 0x4CA748)
}
