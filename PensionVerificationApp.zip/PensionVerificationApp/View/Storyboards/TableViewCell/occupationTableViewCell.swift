//
//  occupationTableViewCell.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 06/02/24.
//

import UIKit

class occupationTableViewCell: UITableViewCell {

    @IBOutlet weak var occupationLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
