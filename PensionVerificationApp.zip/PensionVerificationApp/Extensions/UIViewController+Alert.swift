//
//  UIViewController+Alert.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/11/23.
//

import UIKit
extension UIViewController {
    
    func showAlert(title: String, message: String, options: String..., completion: ((String) -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for (index, option) in options.enumerated() {
            alertController.addAction(UIAlertAction.init(title: option, style: .default, handler: { (action) in
                completion?(options[index])
            }))
        }
        self.present(alertController, animated: true, completion: nil)
    }
    
    func showNetworkReachabilityAlert() {
        showAlert(title: "No Internet Connection", message: "Make sure your device is connected to the internet.", options: "OK")
    }
    func alert(message: String, defaultAction:Bool = true, title: String = "", actions: UIAlertAction...) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if defaultAction{
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(action)
        }
        if !actions.isEmpty {
            actions.forEach{alertController.addAction($0)}
        }
        self.present(alertController, animated: true, completion: nil)
    }
    
   func callRefreshToken(){
        // showHUD(message: "")
        let refresh_TokenVal = UserDefaults.standard.refreshToken
        APIManager().perform(RefreshToken(queryParams: nil,body: RefreshToken.Body(refresh_token: refresh_TokenVal))) { result in
            //  self.hideHUD()
            // Your result handling code here
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        UserDefaults.standard.removeAccessToken()
                        UserDefaults.standard.removeRefreshToken()
                        UserDefaults.standard.accessToken = data.detail.access!
                        UserDefaults.standard.refreshToken = data.detail.refresh!
                    }
                } else if data.detail.status == "fail" {
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message, title: "Failed Login")
                        // Handle the "fail" status here
                    }
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: "Unexpected status: \(data.detail.status)", title: "Exception")
                        // Handle other unexpected statuses
                    }
                }
            case .failure(let error):
                print("errrorrrs", error)
                DispatchQueue.main.async {
                    // Check specific error types and provide more informative messages
                    if let apiError = error as? APIErrorFormat {
                        switch apiError {
                        case .networkError:
                            let errorMessage = "Network error. Please check your internet connection."
                        case .invalidResponse:
                            let errorMessage = "Invalid response from the server. Please try again."
                            // Add more cases as needed
                        }
                    }
                }
            }
        }
       
    }
    
    
   /* func callRefreshToken(completion: @escaping (Bool) -> Void) {
        let refreshToken = UserDefaults.standard.refreshToken
        APIManager().perform(RefreshToken(queryParams: nil, body: RefreshToken.Body(refresh_token: refreshToken))) { result in
            switch result {
            case .success(let data):
                if data.detail.status == "success" {
                    DispatchQueue.main.async {
                        UserDefaults.standard.removeAccessToken()
                        UserDefaults.standard.removeRefreshToken()
                        UserDefaults.standard.accessToken = data.detail.access!
                        UserDefaults.standard.refreshToken = data.detail.refresh!
                        completion(true)  // Token refresh succeeded
                    }
                } else {
                    DispatchQueue.main.async {
                        self.alert(message: data.detail.message, title: "Failed Login")
                        completion(false)  // Token refresh failed
                    }
                }
            case .failure(let error):
                print("Error during token refresh: ", error)
                DispatchQueue.main.async {
                    self.alert(message: "Could not refresh token. Please try again.", title: "Error")
                    completion(false)
                }
            }
        }
    }*/
 
}
