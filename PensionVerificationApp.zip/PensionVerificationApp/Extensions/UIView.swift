//
//  UIView+Extension.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//
import UIKit

extension UIView {
    
    @IBInspectable var cornerRadius: CGFloat {
        get { return layer.cornerRadius  }
        set { self.layer.cornerRadius = newValue }
    }
    
    @IBInspectable var borderColor: UIColor {
        get { self.borderColor }
        set { self.layer.borderColor = newValue.cgColor }
    }
    
    @IBInspectable var borderWidth: CGFloat {
        get { self.borderWidth }
        set { self.layer.borderWidth = newValue }
    }
    
    @IBInspectable var shadowRadius: CGFloat {
        get { self.shadowRadius }
        set { self.layer.shadowRadius = newValue }
    }
    
    @IBInspectable var shadowOffset: CGSize {
        get { self.shadowOffset }
        set { self.layer.shadowOffset = newValue }
    }
    
    @IBInspectable var shadowColor: UIColor {
        get { self.shadowColor }
        set { self.layer.shadowColor = newValue.cgColor }
    }
    
    @IBInspectable var shadowOpacity: Float {
        get { self.shadowOpacity }
        set { self.layer.shadowOpacity = newValue }
    }
    var isClippedCorner : Bool{
        get{
            return self.layer.cornerRadius != 0
        }
        set(newValue){
            if newValue{
                self.clipsToBounds = true
                self.layer.cornerRadius = self.frame.height * (8/100)
            }else{
                self.layer.cornerRadius = 0
            }
        }
    }
    func applyShadow(color: UIColor = .black,
                     alpha: Float = 0.2,
                     xOffset: CGFloat = 2,
                     yOffset: CGFloat = 2,
                     spread: CGFloat = 0) {
        
        layer.shadowColor = color.cgColor
        layer.shadowOpacity = alpha
        layer.shadowOffset = CGSize(width: xOffset, height: yOffset)
        layer.shadowRadius = 10
        if spread == 0 {
            layer.shadowPath = nil
        } else {
            let rect = bounds.insetBy(dx: -spread, dy: -spread)
            layer.shadowPath = UIBezierPath(rect: rect).cgPath
        }
    }
    func applyDarkGreenToLightGreenGradient() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = [Color.gradientGreen, Color.darkGreen]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        layer.insertSublayer(gradientLayer, at: 0)
    }
    func addDarkOrangeToLightOrangeGradient() {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        gradientLayer.colors = [UIColor.lightOrange.cgColor, UIColor.darkOrange.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        layer.insertSublayer(gradientLayer, at: 0)
    }
    func makeRound() {
        layer.cornerRadius = bounds.width / 2
        clipsToBounds = true
    }
    func applyCornerRadius(_ radius: CGFloat) {
        self.layer.cornerRadius = radius
    }
    func applyLinearGradient() {
               let gradientLayer = CAGradientLayer()
               gradientLayer.frame = bounds

               // Define the colors for your gradient
        guard let darkGreen = UIColor(named: "018652")?.cgColor,
              let lightGreen = UIColor(named: "4CA748")?.cgColor else {
                   return
               }

               gradientLayer.colors = [darkGreen, lightGreen]

               // Specify the direction of the gradient (you can customize this)
               let angle: Double = 3.0 // in degrees
               let radians = angle * .pi / 180.0
               let x = cos(radians)
               let y = sin(radians)

               // Use the bounds from self, not the bounds directly
               let gradientBounds = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
               gradientLayer.frame = gradientBounds

               gradientLayer.startPoint = CGPoint(x: CGFloat(0.5 - x), y: CGFloat(0.5 + y))
               gradientLayer.endPoint = CGPoint(x: CGFloat(0.5 + x), y: CGFloat(0.5 - y))

               layer.insertSublayer(gradientLayer, at: 0)
           }
    func addRoundedBottomCorners(radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: [.bottomLeft, .bottomRight], cornerRadii: CGSize(width: radius, height: radius))
        let maskLayer = CAShapeLayer()
        maskLayer.path = path.cgPath
        self.layer.mask = maskLayer
    }
    func addBorder(width: CGFloat, color: UIColor) {
            layer.borderWidth = width
            layer.borderColor = color.cgColor
            }
}
extension UIScrollView {
    func scrollsToBottom(animated: Bool) {
        let bottomOffset = CGPoint(x: contentOffset.x,
                                   y: contentSize.height - bounds.height + adjustedContentInset.bottom)
        setContentOffset(bottomOffset, animated: animated)
    }
}
extension UIColor {
    static var darkGreenOne: UIColor {
        return UIColor(red: 0.0, green: 0.5, blue: 0.0, alpha: 1.0)
    }
    
    static var lightGreenOne: UIColor {
        return UIColor(red: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
    }
    static var darkOrange: UIColor {
        return UIColor(red: 1.0, green: 0.549, blue: 0.0, alpha: 1.0)
    }
    static var lightOrange: UIColor {
        return UIColor(red: 1.0, green: 0.8, blue: 0.0, alpha: 1.0)
    }
}
