//
//  CustomSegment.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/10/23.
//


import UIKit

class CustomSegment: UISegmentedControl {
    
}
extension UIImage{
    class func getSegRect(color:CGColor, andSize size: CGSize)->UIImage{
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        let context = UIGraphicsGetCurrentContext()
        context?.setFillColor(color)
        let rectangle = CGRect(x: 0.0, y :0.0, width: size.width, height: size.height)
        context?.fill(rectangle)
        let rectangleImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return rectangleImage!
    }
    
}

extension UISegmentedControl{
    func removeBorder(){
        let background = UIImage.getSegRect(color: UIColor(red: 255, green: 255, blue: 255, alpha: 0.0).cgColor, andSize: self.bounds.size)
        self.setBackgroundImage(background, for: .normal, barMetrics: .default)
        self.setBackgroundImage(background, for: .selected, barMetrics: .default)
        self.setBackgroundImage(background, for: .highlighted, barMetrics: .default)
        
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.white],for:.normal)
        self.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:UIColor.init(white: 1, alpha: 0.5)],for:.selected)
    }
    
    func highlightSelectedSegment(){
        removeBorder()
        let lineWidth:CGFloat = self.bounds.size.width/CGFloat(self.numberOfSegments)
        let lineHight:CGFloat = 2.0
        let lineXPosition = CGFloat(selectedSegmentIndex * Int(lineWidth))
        let lineYPosition = self.bounds.size.height - 6.0
        let underLineFrame = CGRect(x: lineXPosition, y: lineYPosition, width: lineWidth, height: lineHight)
        let underLine = UIView(frame: underLineFrame)
        underLine.backgroundColor = UIColor.green
        underLine.tag = 1
        self.addSubview(underLine)
    }
    
    func underlinePosition()
    {
        guard let underLine = self.viewWithTag(1)else{return}
        let xPosition = (self.bounds.width / CGFloat(self.numberOfSegments)) * CGFloat(selectedSegmentIndex)
        
        UIView.animate(withDuration: 0.5, delay: 0.0,usingSpringWithDamping: 0.5,initialSpringVelocity: 0.8, options: .curveEaseInOut, animations: {underLine.frame.origin.x = xPosition})
    }
    
}

