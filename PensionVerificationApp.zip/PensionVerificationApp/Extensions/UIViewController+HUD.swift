//
//  UIViewController+HUD.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 19/11/23.
//

import Foundation
import NVActivityIndicatorView

extension UIViewController: NVActivityIndicatorViewable {
    
    func showHUD(message: String?) {
        let size = CGSize(width: 40, height: 40)
        
        DispatchQueue.main.async { [self] in
            startAnimating(size, message: message ?? "", type: .ballScaleRippleMultiple)
        }
    }
    
    func hideHUD() {
        DispatchQueue.main.async {
            self.stopAnimating()
        }
    }
    
}
