//
//  UserDefaults.swift
//  FinoPay
//
//  Created by Lakshmi on 12/01/24.
//

import Foundation

extension UserDefaults {
    
    private enum UserDefaultsKeys: String {
        case accessToken
        case refreshToken
        case userId
        case lastSha1CheckDate
        case customerMobileNumber
        case hasOnboarded
    }
    
    var accessToken: String {
        get {
            string(forKey: UserDefaultsKeys.accessToken.rawValue) ?? ""
        }
        
        set {
            setValue(newValue, forKey: UserDefaultsKeys.accessToken.rawValue)
        }
    }
    var refreshToken: String {
        get {
            string(forKey: UserDefaultsKeys.refreshToken.rawValue) ?? ""
        }
        
        set {
            setValue(newValue, forKey: UserDefaultsKeys.refreshToken.rawValue)
        }
    }
    var userId: Int {
        get {
            integer(forKey: UserDefaultsKeys.userId.rawValue)
        }
        
        set {
            setValue(newValue, forKey: UserDefaultsKeys.userId.rawValue)
        }
    }
    
    var lastSha1CheckDate: Double {
        get {
            double(forKey: UserDefaultsKeys.lastSha1CheckDate.rawValue)
        }
        
        set {
            setValue(newValue, forKey: UserDefaultsKeys.lastSha1CheckDate.rawValue)
        }
    }

   
    var hasOnboarded: Bool {
        get {
            bool(forKey: UserDefaultsKeys.hasOnboarded.rawValue)
        }
        
        set {
            setValue(newValue, forKey: UserDefaultsKeys.hasOnboarded.rawValue)
        }
    }
    
    func removeAccessToken() {
          removeObject(forKey: UserDefaultsKeys.accessToken.rawValue)
          synchronize()
      }

      func removeRefreshToken() {
          removeObject(forKey: UserDefaultsKeys.refreshToken.rawValue)
          synchronize()
      }

      func removeLastSha1CheckDate() {
          removeObject(forKey: UserDefaultsKeys.lastSha1CheckDate.rawValue)
          synchronize()
      }

     
      func removeHasOnboarded() {
          removeObject(forKey: UserDefaultsKeys.hasOnboarded.rawValue)
          synchronize()
      }

}
