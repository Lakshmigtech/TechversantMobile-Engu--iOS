//
//  CustomClass.swift
//  FinoPay
//
//  Created by Sarath Chandran on 20/04/23.
//

import Foundation
import UIKit

class CustomBorderTextField: UITextField {
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.white
        self.layer.rasterizationScale = true ? UIScreen.main.scale : 1
        self.layer.masksToBounds = true
    }
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        return false
    }
}
class CustomRemoveScanTextField: UITextField {
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
//            UIMenuController.shared.isMenuVisible = false
        return false
    }
}
