//
//  LoginResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 29/12/23.
//

import Foundation


struct LoginResponse: Codable {
    let detail: LoginDetail
}

// MARK: - Detail
struct LoginDetail: Codable {
    let status, message : String
    let userID: Int?
    let accessToken, refreshToken : String?
    
    
    enum CodingKeys: String, CodingKey {
        case status = "status"
        case message = "message"
        case userID = "user_id"
        case accessToken = "access_token"
        case refreshToken = "refresh_token"
    }
}
