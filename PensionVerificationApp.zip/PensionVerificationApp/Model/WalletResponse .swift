//
//  WalletResponse.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 29/08/24.
//

import Foundation

// MARK: - Welcome
struct WalletResponse: Codable {
        let status: String
        let checkoutURL: String

        enum CodingKeys: String, CodingKey {
            case status
            case checkoutURL = "checkout_url"
        }
    }
