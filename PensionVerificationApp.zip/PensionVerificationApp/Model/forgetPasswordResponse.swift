//
//  forgetPasswordResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 04/01/24.
//

import Foundation


struct forgetPasswordResponse: Codable {
    let detail: forgetPasswordDetail
}

// MARK: - Detail
struct forgetPasswordDetail: Codable {
    let status, message : String
    let uniqueToken : String?

    enum CodingKeys: String, CodingKey {
        case status, message
        case uniqueToken = "unique_token"
    }
}


