//
//  SlotAvailableResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/09/24.
//

import Foundation


struct SlotAvailableResponse: Codable {
    let detail: SlotAvailableDetail
}

// MARK: - Detail
struct SlotAvailableDetail: Codable {
    let status, tokenStatus, message: String
    let slots: [Slot]

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message, slots
    }
}

// MARK: - Slot
struct Slot: Codable {
    let id: Int
    let startTime, endTime: String

    enum CodingKeys: String, CodingKey {
        case id
        case startTime = "start_time"
        case endTime = "end_time"
    }
}
