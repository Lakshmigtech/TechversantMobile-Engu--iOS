//
//  PaymentStatusResponse.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 29/08/24.
//

import Foundation

// Define the response model to match the API response structure
struct PaymentStatusResponse: Codable {
    let status: String
    let message: String
    let session: Session

    struct Session: Codable {
        let id: String
        let customerDetails: CustomerDetails?

        struct CustomerDetails: Codable {
            let address: Address?
            let email: String?
            let name: String?
            let phone: String?

            struct Address: Codable {
                let city: String?
                let country: String?
                let line1: String?
                let line2: String?
                let postalCode: String?
                let state: String?

                private enum CodingKeys: String, CodingKey {
                    case city, country, line1, line2, postalCode = "postal_code", state
                }
            }
        }
    }
}
class JSONCodingKey: CodingKey {
    let key: String

    required init?(intValue: Int) {
            return nil
    }

    required init?(stringValue: String) {
            key = stringValue
    }

    var intValue: Int? {
            return nil
    }

    var stringValue: String {
            return key
    }
}

class JSONAny: Codable {

    let value: Any

    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
            let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
            return DecodingError.typeMismatch(JSONAny.self, context)
    }

    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
            let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
            return EncodingError.invalidValue(value, context)
    }

    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
            if let value = try? container.decode(Bool.self) {
                    return value
            }
            if let value = try? container.decode(Int64.self) {
                    return value
            }
            if let value = try? container.decode(Double.self) {
                    return value
            }
            if let value = try? container.decode(String.self) {
                    return value
            }
            if container.decodeNil() {
                    return JSONNull()
            }
            throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
            if let value = try? container.decode(Bool.self) {
                    return value
            }
            if let value = try? container.decode(Int64.self) {
                    return value
            }
            if let value = try? container.decode(Double.self) {
                    return value
            }
            if let value = try? container.decode(String.self) {
                    return value
            }
            if let value = try? container.decodeNil() {
                    if value {
                            return JSONNull()
                    }
            }
            if var container = try? container.nestedUnkeyedContainer() {
                    return try decodeArray(from: &container)
            }
            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
                    return try decodeDictionary(from: &container)
            }
            throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
            if let value = try? container.decode(Bool.self, forKey: key) {
                    return value
            }
            if let value = try? container.decode(Int64.self, forKey: key) {
                    return value
            }
            if let value = try? container.decode(Double.self, forKey: key) {
                    return value
            }
            if let value = try? container.decode(String.self, forKey: key) {
                    return value
            }
            if let value = try? container.decodeNil(forKey: key) {
                    if value {
                            return JSONNull()
                    }
            }
            if var container = try? container.nestedUnkeyedContainer(forKey: key) {
                    return try decodeArray(from: &container)
            }
            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
                    return try decodeDictionary(from: &container)
            }
            throw decodingError(forCodingPath: container.codingPath)
    }

    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
            var arr: [Any] = []
            while !container.isAtEnd {
                    let value = try decode(from: &container)
                    arr.append(value)
            }
            return arr
    }

    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
            var dict = [String: Any]()
            for key in container.allKeys {
                    let value = try decode(from: &container, forKey: key)
                    dict[key.stringValue] = value
            }
            return dict
    }

    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
            for value in array {
                    if let value = value as? Bool {
                            try container.encode(value)
                    } else if let value = value as? Int64 {
                            try container.encode(value)
                    } else if let value = value as? Double {
                            try container.encode(value)
                    } else if let value = value as? String {
                            try container.encode(value)
                    } else if value is JSONNull {
                            try container.encodeNil()
                    } else if let value = value as? [Any] {
                            var container = container.nestedUnkeyedContainer()
                            try encode(to: &container, array: value)
                    } else if let value = value as? [String: Any] {
                            var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                            try encode(to: &container, dictionary: value)
                    } else {
                            throw encodingError(forValue: value, codingPath: container.codingPath)
                    }
            }
    }

    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
            for (key, value) in dictionary {
                    let key = JSONCodingKey(stringValue: key)!
                    if let value = value as? Bool {
                            try container.encode(value, forKey: key)
                    } else if let value = value as? Int64 {
                            try container.encode(value, forKey: key)
                    } else if let value = value as? Double {
                            try container.encode(value, forKey: key)
                    } else if let value = value as? String {
                            try container.encode(value, forKey: key)
                    } else if value is JSONNull {
                            try container.encodeNil(forKey: key)
                    } else if let value = value as? [Any] {
                            var container = container.nestedUnkeyedContainer(forKey: key)
                            try encode(to: &container, array: value)
                    } else if let value = value as? [String: Any] {
                            var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                            try encode(to: &container, dictionary: value)
                    } else {
                            throw encodingError(forValue: value, codingPath: container.codingPath)
                    }
            }
    }

    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
            if let value = value as? Bool {
                    try container.encode(value)
            } else if let value = value as? Int64 {
                    try container.encode(value)
            } else if let value = value as? Double {
                    try container.encode(value)
            } else if let value = value as? String {
                    try container.encode(value)
            } else if value is JSONNull {
                    try container.encodeNil()
            } else {
                    throw encodingError(forValue: value, codingPath: container.codingPath)
            }
    }

    public required init(from decoder: Decoder) throws {
            if var arrayContainer = try? decoder.unkeyedContainer() {
                    self.value = try JSONAny.decodeArray(from: &arrayContainer)
            } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
                    self.value = try JSONAny.decodeDictionary(from: &container)
            } else {
                    let container = try decoder.singleValueContainer()
                    self.value = try JSONAny.decode(from: container)
            }
    }

    public func encode(to encoder: Encoder) throws {
            if let arr = self.value as? [Any] {
                    var container = encoder.unkeyedContainer()
                    try JSONAny.encode(to: &container, array: arr)
            } else if let dict = self.value as? [String: Any] {
                    var container = encoder.container(keyedBy: JSONCodingKey.self)
                    try JSONAny.encode(to: &container, dictionary: dict)
            } else {
                    var container = encoder.singleValueContainer()
                    try JSONAny.encode(to: &container, value: self.value)
            }
    }
}
// MARK: - AmountDetails
struct AmountDetails: Codable {
    let tip: TipClass
}

// MARK: - TipClass
struct TipClass: Codable {
}

// MARK: - PaymentIntentPaymentMethodOptions
struct PaymentIntentPaymentMethodOptions: Codable {
    let card: PurpleCard
}

// MARK: - PurpleCard
struct PurpleCard: Codable {
    let installments, mandateOptions, network: JSONNull?
    let requestThreeDSecure: String

    enum CodingKeys: String, CodingKey {
        case installments
        case mandateOptions = "mandate_options"
        case network
        case requestThreeDSecure = "request_three_d_secure"
    }
}

// MARK: - Session
struct Session: Codable {
    let id, object: String
    let afterExpiration, allowPromotionCodes: JSONNull?
    let amountSubtotal, amountTotal: Int
    let automaticTax: AutomaticTax
    let billingAddressCollection: JSONNull?
    let cancelURL: String
    let clientReferenceID, clientSecret, consent, consentCollection: JSONNull?
    let created: Int
    let currency: String
    let currencyConversion: JSONNull?
    let customFields: [JSONAny]
    let customText: CustomText
    let customer: JSONNull?
    let customerCreation: String
    let customerDetails: CustomerDetails
    let customerEmail: JSONNull?
    let expiresAt: Int
    let invoice: JSONNull?
    let invoiceCreation: InvoiceCreation
    let livemode: Bool
    let locale: JSONNull?
    let metadata: SessionMetadata
    let mode, paymentIntent: String
    let paymentLink: JSONNull?
    let paymentMethodCollection: String
    let paymentMethodConfigurationDetails: JSONNull?
    let paymentMethodOptions: SessionPaymentMethodOptions
    let paymentMethodTypes: [String]
    let paymentStatus: String
    let phoneNumberCollection: PhoneNumberCollection
    let recoveredFrom, savedPaymentMethodOptions, setupIntent, shippingAddressCollection: JSONNull?
    let shippingCost, shippingDetails: JSONNull?
    let shippingOptions: [JSONAny]
    let status: String
    let submitType, subscription: JSONNull?
    let successURL: String
    let totalDetails: TotalDetails
    let uiMode: String
    let url: JSONNull?

    enum CodingKeys: String, CodingKey {
        case id, object
        case afterExpiration = "after_expiration"
        case allowPromotionCodes = "allow_promotion_codes"
        case amountSubtotal = "amount_subtotal"
        case amountTotal = "amount_total"
        case automaticTax = "automatic_tax"
        case billingAddressCollection = "billing_address_collection"
        case cancelURL = "cancel_url"
        case clientReferenceID = "client_reference_id"
        case clientSecret = "client_secret"
        case consent
        case consentCollection = "consent_collection"
        case created, currency
        case currencyConversion = "currency_conversion"
        case customFields = "custom_fields"
        case customText = "custom_text"
        case customer
        case customerCreation = "customer_creation"
        case customerDetails = "customer_details"
        case customerEmail = "customer_email"
        case expiresAt = "expires_at"
        case invoice
        case invoiceCreation = "invoice_creation"
        case livemode, locale, metadata, mode
        case paymentIntent = "payment_intent"
        case paymentLink = "payment_link"
        case paymentMethodCollection = "payment_method_collection"
        case paymentMethodConfigurationDetails = "payment_method_configuration_details"
        case paymentMethodOptions = "payment_method_options"
        case paymentMethodTypes = "payment_method_types"
        case paymentStatus = "payment_status"
        case phoneNumberCollection = "phone_number_collection"
        case recoveredFrom = "recovered_from"
        case savedPaymentMethodOptions = "saved_payment_method_options"
        case setupIntent = "setup_intent"
        case shippingAddressCollection = "shipping_address_collection"
        case shippingCost = "shipping_cost"
        case shippingDetails = "shipping_details"
        case shippingOptions = "shipping_options"
        case status
        case submitType = "submit_type"
        case subscription
        case successURL = "success_url"
        case totalDetails = "total_details"
        case uiMode = "ui_mode"
        case url
    }
}

// MARK: - AutomaticTax
struct AutomaticTax: Codable {
    let enabled: Bool
    let liability, status: JSONNull?
}

// MARK: - CustomText
struct CustomText: Codable {
    let afterSubmit, shippingAddress, submit, termsOfServiceAcceptance: JSONNull?

    enum CodingKeys: String, CodingKey {
        case afterSubmit = "after_submit"
        case shippingAddress = "shipping_address"
        case submit
        case termsOfServiceAcceptance = "terms_of_service_acceptance"
    }
}

// MARK: - CustomerDetails
struct CustomerDetails: Codable {
    let address: Address
    let email, name: String
    let phone: JSONNull?
    let taxExempt: String
    let taxIDS: [JSONAny]

    enum CodingKeys: String, CodingKey {
        case address, email, name, phone
        case taxExempt = "tax_exempt"
        case taxIDS = "tax_ids"
    }
}

// MARK: - Address
struct Address: Codable {
    let city, country, line1, line2: String
    let postalCode, state: String

    enum CodingKeys: String, CodingKey {
        case city, country, line1, line2
        case postalCode = "postal_code"
        case state
    }
}

// MARK: - InvoiceCreation
struct InvoiceCreation: Codable {
    let enabled: Bool
    let invoiceData: InvoiceData

    enum CodingKeys: String, CodingKey {
        case enabled
        case invoiceData = "invoice_data"
    }
}

// MARK: - InvoiceData
struct InvoiceData: Codable {
    let accountTaxIDS, customFields, description, footer: JSONNull?
    let issuer: JSONNull?
    let metadata: TipClass
    let renderingOptions: JSONNull?

    enum CodingKeys: String, CodingKey {
        case accountTaxIDS = "account_tax_ids"
        case customFields = "custom_fields"
        case description, footer, issuer, metadata
        case renderingOptions = "rendering_options"
    }
}

// MARK: - SessionMetadata
struct SessionMetadata: Codable {
    let userID: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
    }
}

// MARK: - SessionPaymentMethodOptions
struct SessionPaymentMethodOptions: Codable {
    let card: FluffyCard
}

// MARK: - FluffyCard
struct FluffyCard: Codable {
    let requestThreeDSecure: String

    enum CodingKeys: String, CodingKey {
        case requestThreeDSecure = "request_three_d_secure"
    }
}

// MARK: - PhoneNumberCollection
struct PhoneNumberCollection: Codable {
    let enabled: Bool
}

// MARK: - TotalDetails
struct TotalDetails: Codable {
    let amountDiscount, amountShipping, amountTax: Int

    enum CodingKeys: String, CodingKey {
        case amountDiscount = "amount_discount"
        case amountShipping = "amount_shipping"
        case amountTax = "amount_tax"
    }
}
