//
//  ActiveDocumentUploadResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 20/03/24.
//
struct ActiveDocumentUploadResponse: Codable {
    let detail: ActiveDocumentUploadResponseDetail
}

// MARK: - Detail
struct ActiveDocumentUploadResponseDetail: Codable {
    let status, tokenStatus:String
    let  message: String
    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
    }
}
