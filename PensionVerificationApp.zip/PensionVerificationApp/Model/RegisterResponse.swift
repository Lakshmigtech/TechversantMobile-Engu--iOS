//
//  RegisterResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 03/11/23.
//

import Foundation


struct RegisterResponse: Codable {
    let detail: Detail
}

// MARK: - Detail
struct Detail: Codable {
    let status, message: String
    let token_status : String
    let userdetails: Userdetails?
}

// MARK: - Userdetails
struct Userdetails: Codable {
    let id, username, email: String
}

