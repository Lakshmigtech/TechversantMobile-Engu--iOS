//
//  DashBoardAPIResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/06/24.
//


//
//  DashBoardAPIResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/06/24.
//



/*struct DashBoardAPIResponse: Codable {
    let detail: Details
}

// MARK: - Detail
struct Details: Codable {
    let status, tokenStatus, message, fullName: String
    let profilePic: String
    let bankDetail: BankDetailUser
    let walletBalanceCurrency: String
    let walletBalanceAmount: Double  // Changed to Double
    let verificationStatus: String

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case fullName = "full_name"
        case profilePic = "profile_pic"
        case bankDetail = "bank_detail"
        case walletBalanceCurrency = "wallet_balance_currency"
        case walletBalanceAmount = "wallet_balance_amount"
        case verificationStatus = "verification_status"
    }
}

// MARK: - BankDetail
struct BankDetailUser: Codable {
    let accountHolderName: String
    let bankID: Int
    let bankCode: String
    let autoRenewal: String? // Make it optional or handle it as per API response format
    let swiftCode, bankName: String
    let bankImage: String
    let accountNumber, accountType: String

    enum CodingKeys: String, CodingKey {
        case accountHolderName = "account_holder_name"
        case bankID = "bank_id"
        case bankCode = "bank_code"
        case autoRenewal = "auto_renewal"
        case swiftCode = "swift_code"
        case bankName = "bank_name"
        case bankImage = "bank_image"
        case accountNumber = "account_number"
        case accountType = "account_type"
    }
}*/

import Foundation


struct DashBoardAPIResponse: Codable {
    let detail: Details
}

// MARK: - Detail
struct Details: Codable {
    let status, tokenStatus, message: String
    let fullName: String?
    let profilePic: String?
    let bankDetail: BankDetailUser?
    let walletBalanceCurrency: String?
    let walletBalanceAmount: Int
    let verificationStatus: String?

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case fullName = "full_name"
        case profilePic = "profile_pic"
        case bankDetail = "bank_detail"
        case walletBalanceCurrency = "wallet_balance_currency"
        case walletBalanceAmount = "wallet_balance_amount"
        case verificationStatus = "verification_status"
    }
}

// MARK: - BankDetail
struct BankDetailUser: Codable {
    let accountHolderName: String?
    let bankID: Int?
    let bankCode: String?
    let autoRenewal: Bool?
    let swiftCode, bankName: String?
    let bankImage: String?
    let accountNumber, accountType: String?

    enum CodingKeys: String, CodingKey {
        case accountHolderName = "account_holder_name"
        case bankID = "bank_id"
        case bankCode = "bank_code"
        case autoRenewal = "auto_renewal"
        case swiftCode = "swift_code"
        case bankName = "bank_name"
        case bankImage = "bank_image"
        case accountNumber = "account_number"
        case accountType = "account_type"
    }
}
