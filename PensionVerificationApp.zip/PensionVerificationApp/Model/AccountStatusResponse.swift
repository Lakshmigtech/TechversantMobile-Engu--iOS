//
//  AccountStatusResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 05/11/24.
//


import Foundation


struct AccountStatusResponse: Codable {
    let detail: StatusDetail
}

// MARK: - Detail
struct StatusDetail: Codable {
    let status, tokenStatus: String
    let userAccountDetailsSaveCompleted: Bool
    let message: String

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case userAccountDetailsSaveCompleted = "user_account_details_save_completed"
        case message
    }
}

