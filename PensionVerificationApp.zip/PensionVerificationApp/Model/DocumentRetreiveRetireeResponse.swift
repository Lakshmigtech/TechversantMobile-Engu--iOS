//
//  DocumentRetreiveRetireeResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 15/05/24.
//


import Foundation

struct DocumentRetreiveRetireeResponse: Codable {
    let detail: DocumentRetreiveRetireeDetail
}

// MARK: - Detail
struct DocumentRetreiveRetireeDetail: Codable {
    let status, tokenStatus, filePresentCheck, message: String
    let fileURLResponse: FileURLResponses

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case filePresentCheck = "file_present_check"
        case message
        case fileURLResponse = "file_url_response"
    }
}

// MARK: - FileURLResponse
struct FileURLResponses: Codable {
    let applicationFormFileURL, monthlyArrearsPaymentAppointmentFileURL, paymentAuthorizationRetirementOrDeathFileURL, clearanceFormFileURL: String
    let promotionNotificationFileURL, pensionLifeCertificateFileURL: String
    let passportPhotoFileURL: String
    let retirementNoticeFileURL, idCardFileURL: String

    enum CodingKeys: String, CodingKey {
        case applicationFormFileURL = "application_form_file_url"
        case monthlyArrearsPaymentAppointmentFileURL = "monthly_arrears_payment_appointment_file_url"
        case paymentAuthorizationRetirementOrDeathFileURL = "payment_authorization_retirement_or_death_file_url"
        case clearanceFormFileURL = "clearance_form_file_url"
        case promotionNotificationFileURL = "promotion_notification_file_url"
        case pensionLifeCertificateFileURL = "pension_life_certificate_file_url"
        case passportPhotoFileURL = "passport_photo_file_url"
        case retirementNoticeFileURL = "retirement_notice_file_url"
        case idCardFileURL = "id_card_file_url"
    }
}




