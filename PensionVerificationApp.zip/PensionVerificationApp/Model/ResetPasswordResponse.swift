//
//  ResetPasswordResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 11/01/24.
//

import Foundation

    struct ResetPasswordResponse: Codable {
        let detail: ResetPasswordDetail
    }

    // MARK: - Detail
    struct ResetPasswordDetail: Codable {
        let status, message: String
    }
