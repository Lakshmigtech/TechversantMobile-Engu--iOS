//
//  UserGovtStatus.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 04/06/24.
//

import Foundation

// MARK: - Welcome
struct UserGovtStatusResponse: Codable {
    let detail: UserGovtStatusDetail
}

// MARK: - Detail
struct UserGovtStatusDetail: Codable {
    let status, tokenStatus: String
    let userGovtVerified: Bool
    let message: String

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case userGovtVerified = "user_govt_verified"
        case message
    }
}
