//
//  LogoutResponse.swift
//  PensionVerificationApp
//
//  Created by Admin on 22/01/24.
//
import Foundation

// MARK: - Welcome
struct LogoutResponse: Codable {
    let detail: LogoutDetail
}

// MARK: - Detail
struct LogoutDetail: Codable {
    let status, tokenStatus, message: String

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
    }
}


