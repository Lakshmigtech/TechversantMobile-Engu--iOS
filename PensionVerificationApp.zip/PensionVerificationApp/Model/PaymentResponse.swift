//
//  PaymentResponse.swift
//  PensionVerificationApp
//
//  Created by Anjali CD on 13/11/24.
//

import Foundation

struct PaymentResponse: Codable {
    let detail: PaymentDetail
}

// MARK: - PaymentDetail
struct PaymentDetail: Codable {
    let status, tokenStatus, message, transferID: String

    enum CodingKeys: String, CodingKey {
        case status = "status"
        case tokenStatus = "token_status"
        case message = "message"
        case transferID = "transfer_id"
    }
}

