//
//  BankSwiftCodeResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 28/02/24.
//



import Foundation

struct SwiftCodeBankResponse: Codable {
    let detail: DetaSwiftCodeBankDetail
}

// MARK: - Detail
struct DetaSwiftCodeBankDetail: Codable {
    let status, tokenStatus, message: String
    let swiftCodeResponse: SwiftCodeResponse

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case swiftCodeResponse = "swift_code_response"
    }
}

// MARK: - SwiftCodeResponse
struct SwiftCodeResponse: Codable {
    let address, postcode, branchName, countryName: String
    let cityID, cityName, bankID, bankCode: String
    let bankName: String

    enum CodingKeys: String, CodingKey {
        case address, postcode
        case branchName = "branch_name"
        case countryName = "country_name"
        case cityID = "city_id"
        case cityName = "city_name"
        case bankID = "bank_id"
        case bankCode = "bank_code"
        case bankName = "bank_name"
    }
}
