//
//  BankDetailsResponse.swift
//  PensionVerificationApp
//
//  Created by Admin on 09/02/24.
//


import Foundation

struct BankDetailsResponse: Codable {
    let detail: BankDetailss
}

// MARK: - Detail
struct BankDetailss: Codable {
    let status, tokenStatus, message: String
    let bankDetail: BankDetail

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case bankDetail = "bank_detail"
    }
}

// MARK: - BankDetail
struct BankDetail: Codable {
    let accountNumber: String
    let id: Int
    let swiftCode, accountType: String
    let userID, bankID: Int
    let accountHolderName, bankCode: String
    let autoRenewal: Bool?

    enum CodingKeys: String, CodingKey {
        case accountNumber = "account_number"
        case id
        case swiftCode = "swift_code"
        case accountType = "account_type"
        case userID = "user_id"
        case bankID = "bank_id"
        case accountHolderName = "account_holder_name"
        case bankCode = "bank_code"
        case autoRenewal = "auto_renewal"
    }
}
