//
//  EINResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 29/05/24.
//

import Foundation

// MARK: - Welcome
struct EINResponse: Codable {
    let detail: EINDetail
}

// MARK: - Detail
struct EINDetail: Codable {
    let status, message: String
}

