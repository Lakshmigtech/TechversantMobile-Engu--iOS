//
//  DocumentRetreiveActiveResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 13/05/24.
//


import Foundation


struct DocumentRetreiveActiveResponse: Codable {
    let detail: DocumentRetreiveActiveDetail
}

// MARK: - Detail
struct DocumentRetreiveActiveDetail: Codable {
    let status, tokenStatus, filePresentCheck, message: String
    let fileURLResponse: FileURLResponse

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case filePresentCheck = "file_present_check"
        case message
        case fileURLResponse = "file_url_response"
    }
}

// MARK: - FileURLResponse
struct FileURLResponse: Codable {
    let applicationFormFileURL, promotionLetterTransferLetterFileURL, idCardFileURL: String
    let passportPhotoFileURL: String
    let clearanceFormFileURL: String

    enum CodingKeys: String, CodingKey {
        case applicationFormFileURL = "application_form_file_url"
        case promotionLetterTransferLetterFileURL = "promotion_letter_transfer_letter_file_url"
        case idCardFileURL = "id_card_file_url"
        case passportPhotoFileURL = "passport_photo_file_url"
        case clearanceFormFileURL = "clearance_form_file_url"
    }
}



