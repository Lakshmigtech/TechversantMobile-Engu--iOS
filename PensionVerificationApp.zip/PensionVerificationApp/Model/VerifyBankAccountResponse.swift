//
//  VerifyBankAccountResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/07/24.
//


import Foundation

struct VerifyBankAccountResponse: Codable {
    let detail: VerifyBankAccountDetail
}

struct VerifyBankAccountDetail: Codable {
    let status: String
    let tokenStatus: String
    let message: String
    let data: BankAccountData?  // Define a new struct for data
    
    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case data
    }
}

struct BankAccountData: Codable {
    let accountName: String
    let accountNumber: String
    
    enum CodingKeys: String, CodingKey {
        case accountName = "account_name"
        case accountNumber = "account_number"
    }
}




