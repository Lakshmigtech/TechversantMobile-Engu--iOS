//
//  VerifyOTPResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 30/11/23.
//

import Foundation

struct VerifyOTPResponse: Codable {
    let detail: VerifyOTPDetail
}

// MARK: - Detail
struct VerifyOTPDetail: Codable {
    let status, message: String?
    let userdetails: VerifyOTPUserdetails?
}

// MARK: - Userdetails
struct VerifyOTPUserdetails: Codable {
    let id, username, email: String?
}
