//
//  CreateBookingResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 24/09/24.
//

import Foundation


struct CreateBookingResponse: Codable {
    let detail: CreateBookingDetail
}
// MARK: - Detail
struct CreateBookingDetail: Codable {
    let status, tokenStatus, message: String

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
    }
}
