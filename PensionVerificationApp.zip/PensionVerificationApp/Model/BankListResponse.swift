//
//  BankListResponse.swift
//  PensionVerificationApp
//
//  Created by Admin on 25/01/24.
//



import Foundation
struct BankListResponse: Codable {
    let detail: BankListDetail
}

// MARK: - Detail
struct BankListDetail: Codable {
    let status, message, tokenStatus: String
    let banks: [Bank]
    let accountType: [AccountType]

    enum CodingKeys: String, CodingKey {
        case status, message
        case tokenStatus = "token_status"
        case banks
        case accountType = "account_type"
    }
}

// MARK: - AccountType
struct AccountType: Codable {
    let id: Int
    let type: String
}

// MARK: - Bank
struct Bank: Codable {
    let id: Int
    let name, slug, code, ussd: String
    let logo: String
}
