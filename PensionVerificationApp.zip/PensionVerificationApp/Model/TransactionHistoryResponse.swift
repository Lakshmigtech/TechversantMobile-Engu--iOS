//
//  TransactionHistoryResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 11/09/24.
//


import Foundation

struct TransactionHistoryResponse: Codable {
    let page, limit, totalCount: Int
    let transactions: [Transaction]

    enum CodingKeys: String, CodingKey {
        case page, limit
        case totalCount = "total_count"
        case transactions
    }
}

// MARK: - Transaction
struct Transaction: Codable {
    let id, amount: Int
    let transactionDate, description: String
    let stripeTransactionID: String?

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case amount = "amount"
        case transactionDate = "transaction_date"
        case description = "description"
        case stripeTransactionID = "stripe_transaction_id"
    }
}
