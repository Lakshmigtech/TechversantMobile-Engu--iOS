//
//  BookingDateRangeResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 09/09/24.
//


import Foundation

struct BookingDateRangeResponse: Codable {
    let detail: BookingDateRangeDetail
}

// MARK: - Detail
struct BookingDateRangeDetail: Codable {
    let status, tokenStatus, message: String
    let bookingDateRange: [BookingDateRange]

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case bookingDateRange = "booking_date_range"
    }
}

// MARK: - BookingDateRange
struct BookingDateRange: Codable {
    let month, year, startDay, endDay: String
    let holidays: [Holiday]

    enum CodingKeys: String, CodingKey {
        case month, year
        case startDay = "start_day"
        case endDay = "end_day"
        case holidays
    }
}

// MARK: - Holiday
struct Holiday: Codable {
    let date, name: String
    let holidayForGovernmentOffice: Bool

    enum CodingKeys: String, CodingKey {
        case date, name
        case holidayForGovernmentOffice = "holiday_for_government_office"
    }
}
