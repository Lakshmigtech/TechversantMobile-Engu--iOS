//
//  ForgetOTPVerifyResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 13/03/24.
//


import Foundation


struct ForgetOTPVerifyResponse: Codable {
    let detail: ForgetOTPVerifyDetail
}

// MARK: - Detail
struct ForgetOTPVerifyDetail: Codable {
    let status, message: String?
    let userdetails: Userdetail
}

// MARK: - Userdetails
struct Userdetail: Codable {
    let id, username, email: String?
}
