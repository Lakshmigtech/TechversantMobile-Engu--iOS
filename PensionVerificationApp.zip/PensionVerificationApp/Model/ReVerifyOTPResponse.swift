//
//  ReVerifyOTPResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 30/11/23.
//

import Foundation

struct ReVerifyOTPResponse: Codable {
    let detail: ReVerifyOTPDetail
}

// MARK: - Detail
struct ReVerifyOTPDetail: Codable {
    let status, message: String?
    let userdetails: ReVerifyOTPUserdetails?
}

// MARK: - Userdetails
struct ReVerifyOTPUserdetails: Codable {
    let id, username, email: String?
}
