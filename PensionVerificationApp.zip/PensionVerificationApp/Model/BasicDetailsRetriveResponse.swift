//
//  BasicDetailsRetriveResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 03/05/24.
//

import Foundation

struct BasicDetailsRetriveResponse: Codable {
    let detail: BasicDetailsRetriveDetail
}

// MARK: - Detail
struct BasicDetailsRetriveDetail: Codable {
    let status, tokenStatus, message: String
    let userProfileDetails: UserProfileDetailss?

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case userProfileDetails = "user_profile_details"
    }
}

// MARK: - UserProfileDetails
struct UserProfileDetailss: Codable {
    let userID: Int
    let userType, firstName, middleName, lastName: String
    let dob, sex, address, pincode: String
    let country, lga, nextOfKinName, nextOfKinEmail: String
    let nextOfKinPhoneNumber, nextOfKinAddress, nextOfKinPincode, subTreasury: String
    let dateOfAppointment, gradeLevel, occupation: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case userType = "user_type"
        case firstName = "first_name"
        case middleName = "middle_name"
        case lastName = "last_name"
        case dob, sex, address, pincode, country, lga
        case nextOfKinName = "next_of_kin_name"
        case nextOfKinEmail = "next_of_kin_email"
        case nextOfKinPhoneNumber = "next_of_kin_phone_number"
        case nextOfKinAddress = "next_of_kin_address"
        case nextOfKinPincode = "next_of_kin_pincode"
        case subTreasury = "sub_treasury"
        case dateOfAppointment = "date_of_appointment"
        case gradeLevel = "grade_level"
        case occupation
    }
}
