//
//  RetireeAccountCompletionResponse.swift
//  PensionVerificationApp
//
//  Created by Sreelekshmi M S on 28/02/24.
//

import Foundation

struct RetireeAccountCompletionResponse: Codable {
    let detail: RetireeAccountCompletionDetail
}

// MARK: - Detail
struct RetireeAccountCompletionDetail: Codable {
    let status, tokenStatus, message: String
    let userProfileDetails: UserProfileDetail?

    enum CodingKeys: String, CodingKey {
        case status
        case tokenStatus = "token_status"
        case message
        case userProfileDetails = "user_profile_details"
    }
}

// MARK: - UserProfileDetails
struct UserProfileDetail: Codable {
    let userID: Int
    let userType, firstName, middleName, lastName: String
    let dob, sex, address, pincode: String
    let country, lga, nextOfKinName, nextOfKinEmail: String
    let nextOfKinPhoneNumber, nextOfKinAddress, nextOfKinPincode, localGovernmentPensionBoard: String
    let subTreasury, dateOfAppointment, lastPromotionYear, gradeLevel: String
    let dateOfRetirement, positionHeldLastIDOrOther: String

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case userType = "user_type"
        case firstName = "first_name"
        case middleName = "middle_name"
        case lastName = "last_name"
        case dob, sex, address, pincode, country, lga
        case nextOfKinName = "next_of_kin_name"
        case nextOfKinEmail = "next_of_kin_email"
        case nextOfKinPhoneNumber = "next_of_kin_phone_number"
        case nextOfKinAddress = "next_of_kin_address"
        case nextOfKinPincode = "next_of_kin_pincode"
        case localGovernmentPensionBoard = "local_government_pension_board"
        case subTreasury = "sub_treasury"
        case dateOfAppointment = "date_of_appointment"
        case lastPromotionYear = "last_promotion_year"
        case gradeLevel = "grade_level"
        case dateOfRetirement = "date_of_retirement"
        case positionHeldLastIDOrOther = "position_held_last_id_or_other"
    }
}
