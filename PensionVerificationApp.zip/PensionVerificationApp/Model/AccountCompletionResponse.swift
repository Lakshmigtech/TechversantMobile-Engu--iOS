//
//  AccountCompletionResponse.swift
//  PensionVerificationApp
//
//  Created by Admin on 19/02/24.
//

import Foundation
struct AccountCompletionResponse: Codable {
    let detail: AccountCompletionDetail
}

// MARK: - Detail
struct AccountCompletionDetail: Codable {
    let status, message: String?
    let lgas, subTreasuries: [Lgas]?
    let gradeLevels: [GradeLevel]?
    let occupations: [Occupation]?
    let countries: [CountryElement]?
    let positions, localGovenmentPensionBoards: [LocalGovenmentPensionBoard]?

    enum CodingKeys: String, CodingKey {
        case status, message, lgas
        case subTreasuries = "sub_treasuries"
        case gradeLevels = "grade_levels"
        case occupations, countries, positions
        case localGovenmentPensionBoards = "local_govenment_pension_boards"
    }
}

// MARK: - CountryElement
struct CountryElement: Codable {
    let id: Int?
    let countryName: String?

    enum CodingKeys: String, CodingKey {
        case id
        case countryName = "country_name"
    }
}

// MARK: - GradeLevel
struct GradeLevel: Codable {
    let id: Int?
    let level: String?
}

// MARK: - Lgas
struct Lgas: Codable {
    let id: Int?
    let name, state: String?
    let country: CountryEnum
}

enum CountryEnum: String, Codable {
    case nigeria = "Nigeria"
}

// MARK: - LocalGovenmentPensionBoard
struct LocalGovenmentPensionBoard: Codable {
    let id: Int?
    let positionName: String?

    enum CodingKeys: String, CodingKey {
        case id
        case positionName = "position_name"
    }
}

// MARK: - Occupation
struct Occupation: Codable {
    let id: Int?
    let name, category: String?
}
