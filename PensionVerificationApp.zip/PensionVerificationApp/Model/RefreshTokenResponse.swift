//
//  RefrenTokenResponse.swift
//  PensionVerificationApp
//
//  Created by Lakshmi Sarath on 31/01/24.
//

import Foundation

struct RefreshTokenResponse: Codable {
    let detail: RefreshTokenResponseDetail
}

// MARK: - Detail
struct RefreshTokenResponseDetail: Codable {
    let status, message : String
    let refresh, access : String?

    enum CodingKeys: String, CodingKey {
        case status = "status"
        case message = "message"
        case access = "access"
        case refresh = "refresh"
    }
}
